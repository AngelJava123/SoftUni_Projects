package GenericBox;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Box<String> box = new Box<>();

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            String text = reader.readLine();
            box.add(text);
        }
        int[] numbers = Arrays.stream(reader.readLine().split("\\s+"))
                .mapToInt(Integer::parseInt).toArray();

        int swap1 = numbers[0];
        int swap2 = numbers[1];

        box.swap(swap1, swap2);
        System.out.println(box);
    }
}
