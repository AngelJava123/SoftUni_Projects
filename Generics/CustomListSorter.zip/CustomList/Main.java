package CustomList;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        CustomList<String> list = new CustomList<String>();

        String command = reader.readLine();
        while (!command.equals("END")) {

            String[] tokens = command.split("\\s+");

            String commandName = tokens[0];

            switch (commandName) {
                case "Add":
                    String element = tokens[1];
                    list.add(element);
                    break;
                case "Remove":
                    int index = Integer.parseInt(tokens[1]);
                    list.remove(index);
                    break;
                case "Contains":
                    String elementToContain = tokens[1];
                    System.out.println(list.contains(elementToContain));
                    break;
                case "Swap":
                    int firstIndex = Integer.parseInt(tokens[1]);
                    int secondIndex = Integer.parseInt(tokens[2]);
                    list.swap(firstIndex, secondIndex);
                    break;
                case "Greater":
                    String elementGreater = tokens[1];
                    System.out.println(list.countGreaterThan(elementGreater));
                    break;
                case "Max":
                    System.out.println(list.getMax());
                    break;
                case "Min":
                    System.out.println(list.getMin());
                    break;
                case "Print":
                    list.forEach(System.out::println);
                    break;
                case "Sort":
                    Sorter.sort(list);
                    break;
            }
            command = reader.readLine();
        }
    }
}
