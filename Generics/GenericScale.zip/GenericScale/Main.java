package GenericScale;

public class Main {
    public static void main(String[] args) {

        Scale<String> scale = new Scale<>("a", "z");
        Scale<Integer> scale2 = new Scale<Integer>(73, 25);
    }
}
