package GenericArrayCreator;

public class Main {
    public static void main(String[] args) {

        Object[] javas = ArrayCreator
                .create(String.class, 13, "Java");

        Integer[] integers = ArrayCreator
                .<Integer>create(Integer.class, 73, 69);
    }
}
