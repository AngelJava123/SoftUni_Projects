package GenericBox;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Box<Double> box = new Box<>();

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            double number = Double.parseDouble(reader.readLine());
            box.add(number);
        }
        double element = Double.parseDouble(reader.readLine());

        System.out.println(box.countGreaterThan(element));
    }
}
