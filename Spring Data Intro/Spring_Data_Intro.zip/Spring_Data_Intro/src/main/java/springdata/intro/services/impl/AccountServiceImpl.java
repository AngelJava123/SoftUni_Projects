package springdata.intro.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import springdata.intro.exception.InvalidAccountOperationException;
import springdata.intro.exception.NonExistingEntityException;
import springdata.intro.models.Account;
import springdata.intro.models.User;
import springdata.intro.repositories.AccountRepo;
import springdata.intro.services.AccountService;

import java.math.BigDecimal;
import java.util.List;

@Transactional
@Service
public class AccountServiceImpl implements AccountService {
    private AccountRepo accountRepo;

    @Autowired
    public void setAccountRepo(AccountRepo accountRepo) {
        this.accountRepo = accountRepo;
    }

    @Override
    public Account createUserAccount(User user, Account account) {
        account.setId(null);
        account.setUser(user);
        user.getAccounts().add(account);
        return accountRepo.save(account);
    }

    @Override
    public void withdrawMoney(BigDecimal amount, Long accountId) {
        Account account = accountRepo.findById(accountId).orElseThrow(() ->
                new NonExistingEntityException(
                        String.format("Entity with ID:%s does not exist.", accountId)
                ));

        if (account.getBalance().compareTo(amount) < 0) {
            throw new InvalidAccountOperationException(
                    String.format("Error withdrawing amount: %s. Insufficient amount:%s in account ID:%s."
                            , amount, account.getBalance(), accountId)
            );
        }
        account.setBalance(account.getBalance().subtract(amount));
    }

    @Override
    public void depositMoney(BigDecimal amount, Long accountId) {
        Account account = accountRepo.findById(accountId).orElseThrow(() ->
                new NonExistingEntityException(
                        String.format("Entity with ID:%s does not exist.", accountId)
                ));
        account.setBalance(account.getBalance().add(amount));
    }

    @Override
    public void transferMoney(BigDecimal amount, Long fromAccountId, Long toAccountId) {
        depositMoney(amount, toAccountId);
        withdrawMoney(amount, fromAccountId);
    }

    @Override
    public List<Account> getAllAccounts() {
        return accountRepo.findAll();
    }
}
