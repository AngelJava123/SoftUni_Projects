package springdata.intro.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import springdata.intro.models.User;

public interface UserRepo extends JpaRepository<User, Long> {
}
