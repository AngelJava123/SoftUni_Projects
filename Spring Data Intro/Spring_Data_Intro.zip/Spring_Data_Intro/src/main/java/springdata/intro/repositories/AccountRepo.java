package springdata.intro.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import springdata.intro.models.Account;

public interface AccountRepo extends JpaRepository<Account, Long> {
}
