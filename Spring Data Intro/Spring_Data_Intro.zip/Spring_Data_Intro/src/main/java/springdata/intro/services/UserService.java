package springdata.intro.services;

import springdata.intro.models.User;

public interface UserService {
    User register(User user);
}
