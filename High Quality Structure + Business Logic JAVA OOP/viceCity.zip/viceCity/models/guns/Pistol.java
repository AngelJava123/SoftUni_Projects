package viceCity.models.guns;

public class Pistol extends BaseGun{
    private static final int bulletsPerBarrel = 10;

    public Pistol(String name) {
        super(name,bulletsPerBarrel, 100);
    }

    @Override
    public int fire() {

        if (getBulletsPerBarrel() == 0 && getTotalBullets() > 0) {
            reload();
        }

        if (getBulletsPerBarrel() > 0) {
            setBulletsPerBarrel(getBulletsPerBarrel() - 1);
        }

        return 1;
    }

    private void reload() {
        setTotalBullets(getTotalBullets() - bulletsPerBarrel);
        setBulletsPerBarrel(bulletsPerBarrel);
    }
}
