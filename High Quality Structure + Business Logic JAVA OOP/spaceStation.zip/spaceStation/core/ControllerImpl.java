package spaceStation.core;

import spaceStation.models.astronauts.Astronaut;
import spaceStation.models.astronauts.Biologist;
import spaceStation.models.astronauts.Geodesist;
import spaceStation.models.astronauts.Meteorologist;
import spaceStation.models.mission.Mission;
import spaceStation.models.mission.MissionImpl;
import spaceStation.models.planets.Planet;
import spaceStation.models.planets.PlanetImpl;
import spaceStation.repositories.AstronautRepository;
import spaceStation.repositories.PlanetRepository;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static spaceStation.common.ConstantMessages.*;
import static spaceStation.common.ExceptionMessages.*;

public class ControllerImpl implements Controller {
    private AstronautRepository astronautRepository;
    private PlanetRepository planetRepository;
    private int exploredPlanets = 0;

    public ControllerImpl() {
        this.astronautRepository = new AstronautRepository();
        this.planetRepository = new PlanetRepository();
    }

    @Override
    public String addAstronaut(String type, String astronautName) {

        Astronaut astronaut;
        if (type.equals("Geodesist")) {
            astronaut = new Geodesist(astronautName);
            astronautRepository.add(astronaut);
        } else if (type.equals("Biologist")) {
            astronaut = new Biologist(astronautName);
            astronautRepository.add(astronaut);
        } else if (type.equals("Meteorologist")) {
            astronaut = new Meteorologist(astronautName);
            astronautRepository.add(astronaut);
        } else {
            throw new NullPointerException(ASTRONAUT_INVALID_TYPE);
        }

        return String.format(ASTRONAUT_ADDED, type, astronautName);
    }

    @Override
    public String addPlanet(String planetName, String... items) {

        Planet planet = new PlanetImpl(planetName);
        planet.getItems().addAll(Arrays.asList(items));

        planetRepository.add(planet);
        return String.format(PLANET_ADDED, planetName);
    }

    @Override
    public String retireAstronaut(String astronautName) {

        for (Astronaut astronaut : astronautRepository.getModels()) {
            if (astronaut.getName().equals(astronautName)) {
                astronautRepository.remove(astronaut);
                return String.format(ASTRONAUT_RETIRED, astronautName);
            }
        }
        throw new IllegalArgumentException(String.format(ASTRONAUT_DOES_NOT_EXIST, astronautName));
    }

    @Override
    public String explorePlanet(String planetName) {

        List<Astronaut> collect = astronautRepository.getModels()
                .stream()
                .filter(a -> a.getOxygen() > 60)
                .collect(Collectors.toList());

        if (collect.isEmpty()) {
            throw new IllegalArgumentException(PLANET_ASTRONAUTS_DOES_NOT_EXISTS);
        }

        int sizeBeforeMission = collect.size();
        int sizeAfterMission = 0;
        for (Planet planet : planetRepository.getModels()) {
            if (planet.getName().equals(planetName)) {
                Mission mission = new MissionImpl();
                mission.explore(planet, collect);
                sizeAfterMission = collect.size();
                exploredPlanets++;
            }
        }
        return String.format(PLANET_EXPLORED, planetName, sizeBeforeMission - sizeAfterMission);
    }

    @Override
    public String report() {
        StringBuilder builder = new StringBuilder();

        builder.append(String.format(REPORT_PLANET_EXPLORED, exploredPlanets))
                .append(System.lineSeparator())
                .append(REPORT_ASTRONAUT_INFO).append(System.lineSeparator());

        for (Astronaut astronaut : astronautRepository.getModels()) {
            builder.append(String.format(REPORT_ASTRONAUT_NAME, astronaut.getName()))
                    .append(System.lineSeparator());
            builder.append(String.format(REPORT_ASTRONAUT_OXYGEN, astronaut.getOxygen()))
                    .append(System.lineSeparator());

            if (astronaut.getBag().getItems().isEmpty()) {
                builder.append(String.format(REPORT_ASTRONAUT_BAG_ITEMS, "none"))
                        .append(System.lineSeparator());
            } else {

                Collection<String> items = astronaut.getBag().getItems();
                builder.append("Bag items: ").append(String.join(", ", items))
                        .append(System.lineSeparator());
            }
        }
        return builder.toString().trim();
    }
}
