package aquarium.repositories;

import aquarium.entities.decorations.Decoration;

import java.util.ArrayList;
import java.util.List;

public class DecorationRepository implements Repository{
    private List<Decoration> decorations;

    public DecorationRepository() {
        this.decorations = new ArrayList<>();
    }

    @Override
    public void add(Decoration decoration) {
        decorations.add(decoration);
    }

    @Override
    public boolean remove(Decoration decoration) {
        return decorations.remove(decoration);
    }

    @Override
    public Decoration findByType(String type) {
        Decoration decoration = null;

        for (Decoration decoration1: decorations) {
            if (decoration1.getClass().getSimpleName().equals(type)) {
                decoration = decoration1;
                break;
            }
        }
        return decoration;
    }
}
