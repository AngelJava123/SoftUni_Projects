package restaurant.entities.tables.interfaces;

public class Indoors extends BaseTable {
    public Indoors(int number, int size) {
        super(number, size, 3.50);
    }
}
