package restaurant.repositories.interfaces;

import java.util.List;

public interface Repository<T> {

    List<T> getAllEntities();

    void add(T entity);

}
