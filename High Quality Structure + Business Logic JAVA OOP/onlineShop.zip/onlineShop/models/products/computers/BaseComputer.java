package onlineShop.models.products.computers;

import onlineShop.common.constants.ExceptionMessages;
import onlineShop.models.products.BaseProduct;
import onlineShop.models.products.components.Component;
import onlineShop.models.products.peripherals.Peripheral;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseComputer extends BaseProduct implements Computer {
    private List<Component> components;
    private List<Peripheral> peripherals;

    public BaseComputer(int id, String manufacturer, String model, double price, double overallPerformance) {
        super(id, manufacturer, model, price, overallPerformance);
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    @Override
    public double getOverallPerformance() {
        if (this.components.isEmpty()) {
            return super.getOverallPerformance();
        }
        double sum = 0;
        for (Component component : components) {
            sum += component.getOverallPerformance();
        }

        double averageSum = sum / components.size();

        return super.getOverallPerformance() + averageSum;
    }

    @Override
    public double getPrice() {
        double sumComponents = 0;
        for (Component component : components) {
            sumComponents += component.getPrice();
        }
        double sumPeripherals = 0;
        for (Peripheral peripheral : peripherals) {
            sumComponents += peripheral.getPrice();
        }

        return super.getPrice() + sumComponents + sumPeripherals;

    }

    @Override
    public List<Component> getComponents() {
        return this.components;
    }

    @Override
    public List<Peripheral> getPeripherals() {
        return this.peripherals;
    }

    @Override
    public void addComponent(Component component) {
        for (Component component1 : components) {
            if (component1.getClass().getSimpleName().equals(component.getClass().getSimpleName())) {
                throw new IllegalArgumentException
                        (String.format(ExceptionMessages.EXISTING_COMPONENT,
                                component.getClass().getSimpleName(),
                                this.getClass().getSimpleName(), this.getId()));
            }
        }
        components.add(component);
    }

    @Override
    public Component removeComponent(String componentType) {
        if (components.isEmpty()) {
            throw new IllegalArgumentException(
                    String.format(ExceptionMessages.NOT_EXISTING_COMPONENT,
                            componentType, this.getClass().getSimpleName(), this.getId()));
        }

        Component component1 = null;
        boolean flag = false;
        for (Component component : components) {
            if (component.getClass().getSimpleName().equals(componentType)) {
                component1 = component;
                components.remove(component);
                flag = true;
                break;
            }
        }
        if (!flag) {
            throw new IllegalArgumentException(
                    String.format(ExceptionMessages.NOT_EXISTING_COMPONENT,
                            componentType, this.getClass().getSimpleName(), this.getId()));
        }
        return component1;
    }

    @Override
    public void addPeripheral(Peripheral peripheral) {
        for (Peripheral peripheral1 : peripherals) {
            if (peripheral1.getClass().getSimpleName().equals(peripheral.getClass().getSimpleName())) {
                throw new IllegalArgumentException
                        (String.format(ExceptionMessages.EXISTING_PERIPHERAL,
                                peripheral.getClass().getSimpleName(),
                                this.getClass().getSimpleName(), this.getId()));
            }
        }
        peripherals.add(peripheral);
    }

    @Override
    public Peripheral removePeripheral(String peripheralType) {
        if (peripherals.isEmpty()) {
            throw new IllegalArgumentException(
                    String.format(ExceptionMessages.NOT_EXISTING_PERIPHERAL,
                            peripheralType, this.getClass().getSimpleName(), this.getId()));
        }

        Peripheral peripheral1 = null;
        boolean flag = false;
        for (Peripheral peripheral : peripherals) {
            if (peripheral.getClass().getSimpleName().equals(peripheralType)) {
                peripheral1 = peripheral;
                peripherals.remove(peripheral);
                flag = true;
                break;
            }
        }
        if (!flag) {
            throw new IllegalArgumentException(
                    String.format(ExceptionMessages.NOT_EXISTING_PERIPHERAL,
                            peripheralType, this.getClass().getSimpleName(), this.getId()));
        }
        return peripheral1;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();

        builder.append(super.toString()).append(System.lineSeparator());
        builder.append(String.format(" Components (%d):", this.components.size())).append(System.lineSeparator());
        this.components.forEach(c -> builder.append("  ").append(c).append(System.lineSeparator()));

        double sum = 0;
        for (Peripheral peripheral : peripherals) {
            sum += peripheral.getOverallPerformance();
        }
        double averageSum = sum / peripherals.size();

        builder.append(String.format(" Peripherals (%d); Average Overall Performance (%.2f):",
                this.peripherals.size(), averageSum)).append(System.lineSeparator());
        this.peripherals.forEach(c -> builder.append("  ").append(c).append(System.lineSeparator()));

        return builder.toString().trim();
    }
}
