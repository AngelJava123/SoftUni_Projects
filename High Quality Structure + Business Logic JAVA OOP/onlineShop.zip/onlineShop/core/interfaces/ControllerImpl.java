package onlineShop.core.interfaces;

import onlineShop.common.constants.ExceptionMessages;
import onlineShop.common.constants.OutputMessages;
import onlineShop.models.products.components.*;
import onlineShop.models.products.computers.Computer;
import onlineShop.models.products.computers.DesktopComputer;
import onlineShop.models.products.computers.Laptop;
import onlineShop.models.products.peripherals.*;

import java.util.ArrayList;
import java.util.List;

public class ControllerImpl implements Controller {
    List<Computer> computers;
    List<Component> components;
    List<Peripheral> peripherals;

    public ControllerImpl() {
        this.computers = new ArrayList<>();
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    @Override
    public String addComputer(String computerType, int id, String manufacturer, String model, double price) {
        for (Computer computer : computers) {
            if (computer.getId() == id) {
                throw new IllegalArgumentException(ExceptionMessages.EXISTING_COMPUTER_ID);
            }
        }

        if (!computerType.equals("DesktopComputer") && !computerType.equals("Laptop")) {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_COMPUTER_TYPE);
        }

        Computer computer;
        switch (computerType) {
            case "DesktopComputer":
                computer = new DesktopComputer(id, manufacturer, model, price);
                computers.add(computer);
            case "Laptop":
                computer = new Laptop(id, manufacturer, model, price);
                computers.add(computer);
        }

        return String.format(OutputMessages.ADDED_COMPUTER, id);
    }

    @Override
    public String addPeripheral(int computerId, int id, String peripheralType, String manufacturer, String model, double price, double overallPerformance, String connectionType) {
        for (Peripheral peripheral : peripherals) {
            if (peripheral.getId() == id) {
                throw new IllegalArgumentException(ExceptionMessages.EXISTING_PERIPHERAL_ID);
            }
        }
        Peripheral peripheral;
        if ("Headset".equals(peripheralType)) {
            peripheral = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
        } else if ("Keyboard".equals(peripheralType)) {
            peripheral = new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType);
        } else if ("Monitor".equals(peripheralType)) {
            peripheral = new Monitor(id, manufacturer, model, price, overallPerformance, connectionType);
        } else if ("Mouse".equals(peripheralType)) {
            peripheral = new Mouse(id, manufacturer, model, price, overallPerformance, connectionType);
        } else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_PERIPHERAL_TYPE);
        }
        peripherals.add(peripheral);

        boolean exist = false;
        for (Computer computer : computers) {
            if (computer.getId() == computerId) {
                exist = true;
                computer.addPeripheral(peripheral);
            }
        }
        String result;

        if (exist) {
            result = String.format(OutputMessages.ADDED_PERIPHERAL, peripheralType, id, computerId);
        } else {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }
        return result;
    }

    @Override
    public String removePeripheral(String peripheralType, int computerId) {
        boolean exist = false;
        for (Computer computer : computers) {
            if (computer.getId() == computerId) {
                exist = true;
                computer.removePeripheral(peripheralType);
                break;
            }
        }
        if (!exist) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }

        Peripheral peripheral1 = null;
        for (Peripheral peripheral : peripherals) {
            if (peripheral.getClass().getSimpleName().equals(peripheralType)) {
                peripheral1 = peripheral;
            }
        }
        peripherals.removeIf(peripheral -> peripheral.getClass().getSimpleName().equals(peripheralType));

        assert peripheral1 != null;
        return String.format(OutputMessages.REMOVED_PERIPHERAL, peripheral1.getClass().getSimpleName(),
                peripheral1.getId());
    }

    @Override
    public String addComponent(int computerId, int id, String componentType, String manufacturer, String model, double price, double overallPerformance, int generation) {
        for (Component component : components) {
            if (component.getId() == id) {
                throw new IllegalArgumentException(ExceptionMessages.EXISTING_COMPONENT_ID);
            }
        }
        Component component;
        if ("CentralProcessingUnit".equals(componentType)) {
            component = new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance, generation);
        } else if ("Motherboard".equals(componentType)) {
            component = new Motherboard(id, manufacturer, model, price, overallPerformance, generation);
        } else if ("PowerSupply".equals(componentType)) {
            component = new PowerSupply(id, manufacturer, model, price, overallPerformance, generation);
        } else if ("RandomAccessMemory".equals(componentType)) {
            component = new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation);
        } else if ("SolidStateDrive".equals(componentType)) {
            component = new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation);
        } else if ("VideoCard".equals(componentType)){
            component = new VideoCard(id, manufacturer, model, price, overallPerformance, generation);
        } else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_COMPONENT_TYPE);
        }
        components.add(component);

        boolean exist = false;
        for (Computer computer : computers) {
            if (computer.getId() == computerId) {
                exist = true;
                computer.addComponent(component);
            }
        }
        String result;

        if (exist) {
            result = String.format("Component %s with id %d" +
                    " added successfully in computer with id %d.", componentType, id, computerId);
        } else {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }
        return result;
    }

    @Override
    public String removeComponent(String componentType, int computerId) {
        boolean exist = false;
        for (Computer computer : computers) {
            if (computer.getId() == computerId) {
                exist = true;
                computer.removeComponent(componentType);
                break;
            }
        }
        if (!exist) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }

        Component component1 = null;
        for (Component component : components) {
            if (component.getClass().getSimpleName().equals(componentType)) {
                component1 = component;
            }
        }
        components.removeIf(component -> component.getClass().getSimpleName().equals(componentType));

        assert component1 != null;
        return String.format(OutputMessages.REMOVED_COMPONENT, component1.getClass().getSimpleName(),
                component1.getId());
    }

    @Override
    public String buyComputer(int id) {
        String result = "";

        boolean exist = false;
        for (Computer computer: computers) {
            if (computer.getId() == id) {
                result = computer.toString();
                exist = true;
                computers.remove(computer);
                break;
            }
        }
        if (!exist) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }
        return result;
    }

    @Override
    public String BuyBestComputer(double budget) {

        int value = Integer.MIN_VALUE;
        Computer computer1 = null;
        for (Computer computer : computers) {
            if (computer.getOverallPerformance() > value && computer.getPrice() <= budget) {
                computer1 = computer;
            }
        }
        if (computers.isEmpty() || computer1 == null) {
            throw new IllegalArgumentException(String.format("Can't buy a computer with a budget of $%.2f.", budget));
        }
        return computer1.toString();
    }

    @Override
    public String getComputerData(int id) {
        String result = "";

        boolean exist = false;
        for (Computer computer: computers) {
            if (computer.getId() == id) {
                result = computer.toString();
                exist = true;
                break;
            }
        }
        if (!exist) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }
        return result;
    }
}
