package CounterStriker.core;

import CounterStriker.common.ExceptionMessages;
import CounterStriker.common.OutputMessages;
import CounterStriker.models.field.Field;
import CounterStriker.models.field.FieldImpl;
import CounterStriker.models.guns.Gun;
import CounterStriker.models.guns.Pistol;
import CounterStriker.models.guns.Rifle;
import CounterStriker.models.players.Player;
import CounterStriker.models.players.PlayerImpl;
import CounterStriker.repositories.GunRepository;
import CounterStriker.repositories.PlayerRepository;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ControllerImpl implements Controller {
    private GunRepository guns;
    private PlayerRepository players;
    private FieldImpl field;

    public ControllerImpl() {
        this.guns = new GunRepository();
        this.players = new PlayerRepository();
        this.field = new FieldImpl();
    }

    @Override
    public String addGun(String type, String name, int bulletsCount) {
        String toReturn = String.format(OutputMessages.SUCCESSFULLY_ADDED_GUN, name);

        if (!type.equals("Rifle") && !type.equals("Pistol")) {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_GUN_TYPE);
        }

        switch (type) {
            case "Rifle":
                Gun gun = new Rifle(name, bulletsCount);
                guns.add(gun);
            case "Pistol":
                Gun gun1 = new Pistol(name, bulletsCount);
                guns.add(gun1);
        }

        return toReturn;
    }

    @Override
    public String addPlayer(String type, String username, int health, int armor, String gunName) {
        List<Gun> foundGunName = guns.getModels()
                .stream()
                .filter(g -> g.getName().equals(gunName))
                .collect(Collectors.toList());

        if (foundGunName.isEmpty()) {
            throw new NullPointerException(ExceptionMessages.GUN_CANNOT_BE_FOUND);
        }

        if (!type.equals("Terrorist") && !type.equals("CounterTerrorist")) {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_PLAYER_TYPE);
        }

        Player player = new PlayerImpl(username, health, armor, foundGunName.get(0));
        players.add(player);
        return String.format(OutputMessages.SUCCESSFULLY_ADDED_PLAYER, username);
    }

    @Override
    public String startGame() {
        return field.start(players.getModels());
    }

    @Override
    public String report() {
        StringBuilder builder = new StringBuilder();

        List<Player> ordered = players
                .getModels()
                .stream()
                .sorted(Comparator.comparing(object -> object.getClass().getSimpleName()))
                .collect(Collectors.toList());

        List<Player> ordered1 = ordered
                .stream()
                .sorted(Comparator.comparing(Player::getHealth).reversed())
                .collect(Collectors.toList());

        List<Player> ordered2 = ordered1
                .stream()
                .sorted(Comparator.comparing(Player::getUsername))
                .collect(Collectors.toList());

        for (Player player : ordered2) {
            builder.append(player.getClass().getSimpleName())
                    .append(": ")
                    .append(player.getUsername())
                    .append(System.lineSeparator());

            builder.append("--Health: ").append(player.getHealth()).append(System.lineSeparator());
            builder.append("--Armor: ").append(player.getArmor()).append(System.lineSeparator());
            builder.append("--Gun: ").append(player.getGun().getName()).append(System.lineSeparator());
        }

        return builder.toString().trim();
    }
}
