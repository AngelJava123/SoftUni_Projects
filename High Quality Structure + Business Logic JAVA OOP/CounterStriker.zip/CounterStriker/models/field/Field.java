package CounterStriker.models.field;

import CounterStriker.models.players.Player;

import java.util.List;

public interface Field {
    String start(List<Player> players);
}
