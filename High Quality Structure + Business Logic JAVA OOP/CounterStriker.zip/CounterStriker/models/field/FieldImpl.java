package CounterStriker.models.field;

import CounterStriker.common.OutputMessages;
import CounterStriker.models.players.Player;

import java.util.List;
import java.util.stream.Collectors;

public class FieldImpl implements Field {

    @Override
    public String start(List<Player> players) {
        String result = "";

        List<Player> terrorists = players
                .stream()
                .filter(player -> player.getClass().getSimpleName().equals("Terrorist"))
                .collect(Collectors.toList());

        List<Player> counterTerrorists = players
                .stream()
                .filter(player -> player.getClass().getSimpleName().equals("CounterTerrorist"))
                .collect(Collectors.toList());

        while (true) {
            List<Player> liveCounterTerrorists = counterTerrorists
                    .stream()
                    .filter(Player::isAlive).collect(Collectors.toList());

            List<Player> liveTerrorists = terrorists
                    .stream()
                    .filter(Player::isAlive).collect(Collectors.toList());

            if (liveCounterTerrorists.isEmpty()) {
                result = OutputMessages.TERRORIST_WINS;
                break;
            } else if (liveTerrorists.isEmpty()) {
                result = OutputMessages.COUNTER_TERRORIST_WINS;
                break;
            }

            for (int i = 0; i < liveTerrorists.size(); i++) {
                liveCounterTerrorists.get(i).takeDamage(liveTerrorists.get(i).getGun().fire());
            }

            for (int i = 0; i < liveCounterTerrorists.size(); i++) {
                liveTerrorists.get(i).takeDamage(liveCounterTerrorists.get(i).getGun().fire());
            }
        }
        return result;
    }
}
