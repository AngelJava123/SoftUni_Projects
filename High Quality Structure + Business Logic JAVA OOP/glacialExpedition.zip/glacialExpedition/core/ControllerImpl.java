package glacialExpedition.core;

import glacialExpedition.models.explorers.AnimalExplorer;
import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.explorers.GlacierExplorer;
import glacialExpedition.models.explorers.NaturalExplorer;
import glacialExpedition.models.mission.Mission;
import glacialExpedition.models.mission.MissionImpl;
import glacialExpedition.models.states.State;
import glacialExpedition.models.states.StateImpl;
import glacialExpedition.repositories.ExplorerRepository;
import glacialExpedition.repositories.StateRepository;

import java.util.List;
import java.util.stream.Collectors;

import static glacialExpedition.common.ConstantMessages.*;
import static glacialExpedition.common.ExceptionMessages.*;

public class ControllerImpl implements Controller {
    private ExplorerRepository explorerRepository;
    private StateRepository stateRepository;
    private int exploredStatesCount;

    public ControllerImpl() {
        this.explorerRepository = new ExplorerRepository();
        this.stateRepository = new StateRepository();
    }


    @Override
    public String addExplorer(String type, String explorerName) {

        Explorer explorer = null;
        if (type.equals("AnimalExplorer")) {
            explorer = new AnimalExplorer(explorerName);
        } else if (type.equals("GlacierExplorer")) {
            explorer = new GlacierExplorer(explorerName);
        } else if (type.equals("NaturalExplorer")) {
            explorer = new NaturalExplorer(explorerName);
        } else {
            throw new IllegalArgumentException(EXPLORER_INVALID_TYPE);
        }

        explorerRepository.add(explorer);
        return String.format(EXPLORER_ADDED, type, explorerName);
    }

    @Override
    public String addState(String stateName, String... exhibits) {

        State state = new StateImpl(stateName);
        state.getExhibits().addAll(List.of(exhibits));
        stateRepository.add(state);
        return String.format(STATE_ADDED, stateName);
    }

    @Override
    public String retireExplorer(String explorerName) {

        Explorer explorer = explorerRepository.byName(explorerName);

        if (explorer == null) {
            throw new IllegalArgumentException(String.format(EXPLORER_DOES_NOT_EXIST, explorerName));
        }

        explorerRepository.getCollection().remove(explorer);
        return String.format(EXPLORER_RETIRED, explorerName);
    }

    @Override
    public String exploreState(String stateName) {

        List<Explorer> collect = explorerRepository
                .getCollection().stream().filter(explorer -> explorer.getEnergy() > 50)
                .collect(Collectors.toList());

        if (collect.isEmpty()) {
            throw new IllegalArgumentException(STATE_EXPLORERS_DOES_NOT_EXISTS);
        }

        State state = stateRepository.byName(stateName);
        int notRetired = collect.size();
        Mission mission = new MissionImpl();
        mission.explore(state, collect);
        int retired = collect.size();
        exploredStatesCount++;

        return String.format(STATE_EXPLORER, stateName, notRetired - retired);
    }

    @Override
    public String finalResult() {
        StringBuilder builder = new StringBuilder();

        builder.append(String.format(FINAL_STATE_EXPLORED, exploredStatesCount)).append(System.lineSeparator());
        builder.append(FINAL_EXPLORER_INFO).append(System.lineSeparator());

        for (Explorer explorer : explorerRepository.getCollection()) {
            builder.append(String.format(FINAL_EXPLORER_NAME, explorer.getName())).append(System.lineSeparator());
            builder.append(String.format(FINAL_EXPLORER_ENERGY, explorer.getEnergy())).append(System.lineSeparator());

            if (explorer.getSuitcase().getExhibits().isEmpty()) {
                builder.append("Suitcase exhibits: None").append(System.lineSeparator());
            } else {
                builder.append("Suitcase exhibits: ").append(String.join(", ", explorer.getSuitcase().getExhibits()))
                        .append(System.lineSeparator());
            }
        }
        return builder.toString().trim();
    }
}
