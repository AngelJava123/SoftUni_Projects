package glacialExpedition.models.explorers;

public class GlacierExplorer extends BaseExplorer{
    public GlacierExplorer(String name) {
        super(name, 40);
    }
}
