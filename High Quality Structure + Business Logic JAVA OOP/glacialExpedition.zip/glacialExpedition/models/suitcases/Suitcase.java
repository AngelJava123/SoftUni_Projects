package glacialExpedition.models.suitcases;

import java.util.List;

public interface Suitcase {
    List<String> getExhibits();
}
