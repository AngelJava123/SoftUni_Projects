package bakery.core;

import bakery.common.ExceptionMessages;
import bakery.common.OutputMessages;
import bakery.core.interfaces.Controller;
import bakery.entities.bakedFoods.interfaces.BakedFood;
import bakery.entities.bakedFoods.interfaces.Bread;
import bakery.entities.bakedFoods.interfaces.Cake;
import bakery.entities.drinks.interfaces.Drink;
import bakery.entities.drinks.interfaces.Tea;
import bakery.entities.drinks.interfaces.Water;
import bakery.entities.tables.interfaces.InsideTable;
import bakery.entities.tables.interfaces.OutsideTable;
import bakery.entities.tables.interfaces.Table;
import bakery.repositories.interfaces.*;

public class ControllerImpl implements Controller {
    private final FoodRepository<BakedFood> foodRepository;
    private final DrinkRepository<Drink> drinkRepository;
    private final TableRepository<Table> tableRepository;
    private double completedBills;

    public ControllerImpl(FoodRepository<BakedFood> foodRepository, DrinkRepository<Drink> drinkRepository, TableRepository<Table> tableRepository) {
        this.foodRepository = foodRepository;
        this.drinkRepository = drinkRepository;
        this.tableRepository = tableRepository;
    }

    @Override
    public String addFood(String type, String name, double price) {

        BakedFood bakedFood1 = foodRepository.getByName(name);
        if (bakedFood1 != null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_OR_DRINK_EXIST, type, name));
        }

        if (type.equals("Bread")) {
            BakedFood bakedFood = new Bread(name, price);
            foodRepository.add(bakedFood);
        } else if (type.equals("Cake")) {
            BakedFood bakedFood = new Cake(name, price);
            foodRepository.add(bakedFood);
        }
        return String.format(OutputMessages.FOOD_ADDED, name, type);
    }

    @Override
    public String addDrink(String type, String name, int portion, String brand) {
        Drink byName = drinkRepository.getByNameAndBrand(name, brand);
        if (byName != null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_OR_DRINK_EXIST, type, name));
        }
        if (type.equals("Tea")) {
            Drink drink = new Tea(name, portion, brand);
            drinkRepository.add(drink);
        } else if (type.equals("Water")) {
            Drink drink = new Water(name, portion, brand);
            drinkRepository.add(drink);
        }
        return String.format(OutputMessages.DRINK_ADDED, name, brand);

    }

    @Override
    public String addTable(String type, int tableNumber, int capacity) {
        Table byName = tableRepository.getByNumber(tableNumber);

        if (byName != null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.TABLE_EXIST, tableNumber));
        }

        if (type.equals("InsideTable")) {
            Table table = new InsideTable(tableNumber, capacity);
            tableRepository.add(table);
        } else if (type.equals("OutsideTable")) {
            Table table = new OutsideTable(tableNumber, capacity);
            tableRepository.add(table);
        }

        return String.format(OutputMessages.TABLE_ADDED, tableNumber);
    }

    @Override
    public String reserveTable(int numberOfPeople) {
        Table table = null;

        for (Table table1 : tableRepository.getAll()) {
            if (!table1.isReserved() && table1.getCapacity() >= numberOfPeople) {
                table = table1;
                break;
            }
        }

        if (table == null) {
            return String.format(OutputMessages.RESERVATION_NOT_POSSIBLE, numberOfPeople);
        }

        table.reserve(numberOfPeople);
        return String.format(OutputMessages.TABLE_RESERVED, table.getTableNumber(), numberOfPeople);

    }

    @Override
    public String orderFood(int tableNumber, String foodName) {
        Table table = tableRepository.getByNumber(tableNumber);

        if (table == null) {
            return String.format(OutputMessages.WRONG_TABLE_NUMBER, tableNumber);
        }

        BakedFood bakedFood = foodRepository.getByName(foodName);

        if (bakedFood == null) {
            return String.format(OutputMessages.NONE_EXISTENT_FOOD, foodName);
        }

        table.orderFood(bakedFood);
        return String.format(OutputMessages.FOOD_ORDER_SUCCESSFUL, tableNumber, foodName);
    }

    @Override
    public String orderDrink(int tableNumber, String drinkName, String drinkBrand) {
        Table table = tableRepository.getByNumber(tableNumber);

        if (table == null) {
            return String.format(OutputMessages.WRONG_TABLE_NUMBER, tableNumber);
        }

        Drink drink = drinkRepository.getByNameAndBrand(drinkName, drinkBrand);

        if (drink == null) {
            return String.format(OutputMessages.NON_EXISTENT_DRINK, drinkName, drinkBrand);
        }

        table.orderDrink(drink);
        return String.format(OutputMessages.DRINK_ORDER_SUCCESSFUL, tableNumber, drinkName, drinkBrand);

    }

    @Override
    public String leaveTable(int tableNumber) {
        Table table = tableRepository.getByNumber(tableNumber);
        double bill = table.getBill();
        completedBills += bill;
        table.clear();

        StringBuilder builder = new StringBuilder();
        builder.append("Table: ").append(tableNumber).append(System.lineSeparator());
        builder.append(String.format("Bill: %.2f", bill));

        return builder.toString();

    }

    @Override
    public String getFreeTablesInfo() {
        StringBuilder builder = new StringBuilder();

        for (Table table : tableRepository.getAll()) {
            if (!table.isReserved()) {
                builder.append(table.getFreeTableInfo()).append(System.lineSeparator());
            }
        }

        return builder.toString().trim();
    }

    @Override
    public String getTotalIncome() {
        return String.format("Total income: %.2flv", completedBills);
    }
}
