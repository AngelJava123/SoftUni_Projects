package catHouse.entities.cat;

public class LonghairCat extends BaseCat{
    private int kilograms;
    public LonghairCat(String name, String breed, double price) {
        super(name, breed, price);
        this.kilograms = 9;
    }

    @Override
    public void eating() {
        this.kilograms += 3;
    }

    @Override
    public int getKilograms() {
        return kilograms;
    }
}
