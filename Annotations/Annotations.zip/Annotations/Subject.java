package Annotations;

import java.lang.annotation.*;
import java.util.Arrays;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Subject {
   String[] categories();
}

@Subject(categories = {"Test", "Annotations"})
class TestClass {
   public static void main(String[] args) {

      System.out.println(Arrays.toString(TestClass.class.
              getDeclaredAnnotation(Subject.class).categories()).
              replaceAll("\\[", "").
              replaceAll("]", ""));
   }
}


