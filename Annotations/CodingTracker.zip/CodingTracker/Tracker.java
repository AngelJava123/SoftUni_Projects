package CodingTracker;
import java.util.*;
import java.util.stream.Collectors;

public class Tracker {

    @Author(name = "George")
    public static void main(String[] args) {
        Tracker.printMethodsByAuthor(Tracker.class);
    }

    @Author(name = "Peter")
    public static void printMethodsByAuthor(Class<?> cl) {

        List<Author> annotated = Arrays.stream(cl.getDeclaredMethods())
                .filter(m -> m.getAnnotation(Author.class) != null)
                .map(m -> m.getAnnotation(Author.class))
                .collect(Collectors.toList());

        annotated.forEach(a -> System.out.println("Method author is " + a.name()));
    }
}
