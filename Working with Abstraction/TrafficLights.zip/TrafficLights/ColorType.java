package TrafficLights;

public enum ColorType {
    RED,
    GREEN,
    YELLOW
}
