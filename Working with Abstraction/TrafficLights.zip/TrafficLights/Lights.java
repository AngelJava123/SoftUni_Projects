package TrafficLights;

import java.util.ArrayList;
import java.util.List;

public class Lights {

    public static String[] changeLights(String[] input) {
        List<String> output = new ArrayList<>();

        for (String light: input) {
            if (light.equals(ColorType.GREEN.toString())) {
                output.add("YELLOW");
            } else if (light.equals(ColorType.RED.toString())) {
                output.add("GREEN");
            } else if (light.equals(ColorType.YELLOW.toString())) {
                output.add("RED");
            }
        }
        return output.toArray(String[]::new);
    }
}
