package TrafficLights;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static TrafficLights.Lights.changeLights;

public class Main {
    static String[] input;

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        input = reader.readLine().split("\\s+");

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {

            input = changeLights(input);

            StringBuilder print = new StringBuilder();

            for (String light: input) {
                print.append(light).append(" ");
            }
            System.out.println(print.toString().trim());
        }
    }
}
