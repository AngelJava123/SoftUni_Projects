package HotelReservation;

public class PriceCalculator {

    public static double calculatePricePerDay(double pricePerDay, int numberOfDays, String season, String discountType) {
        double price = 0;
        double currentPrice = 0;

        HotelReservation.discountType[] values = HotelReservation.discountType.values();
        HotelReservation.season[] values1 = HotelReservation.season.values();

        currentPrice = seasonValue(pricePerDay, season, currentPrice, values1);
        currentPrice *= numberOfDays;

        price = discountValue(discountType, price, currentPrice, values);

        return currentPrice - price;
    }

    private static double discountValue(String discountType, double price, double currentPrice, discountType[] values) {
        for (HotelReservation.discountType value : values) {
            if (value.toString().equalsIgnoreCase(discountType)) {
                price = currentPrice * value.getDiscount();
                break;
            }
        }
        return price;
    }

    private static double seasonValue(double pricePerDay, String season, double currentPrice, season[] values1) {
        for (HotelReservation.season season1 : values1) {
            if (season1.toString().equalsIgnoreCase(season)) {
                currentPrice = season1.getSeasonValue() * pricePerDay;
                break;
            }
        }
        return currentPrice;
    }
}
