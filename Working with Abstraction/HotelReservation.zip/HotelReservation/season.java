package HotelReservation;

public enum season {
    AUTUMN(1),
    SPRING(2),
    WINTER(3),
    SUMMER(4);

    private final int seasonValue;


    season(int seasonValue) {
        this.seasonValue = seasonValue;
    }

    public int getSeasonValue() {
        return seasonValue;
    }
}
