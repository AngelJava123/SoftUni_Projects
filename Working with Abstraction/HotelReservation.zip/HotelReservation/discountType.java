package HotelReservation;

public enum discountType {
    VIP(0.2),
    SECONDVISIT(0.1),
    NONE(0.0);

    private final double discount;

    discountType(double discount) {
        this.discount = discount;
    }

    public double getDiscount() {
        return discount;
    }
}
