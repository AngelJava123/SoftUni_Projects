
package GreedyTimes;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        long input = Long.parseLong(scanner.nextLine());
        String[] save = scanner.nextLine().split("\\s+");

        Map<String, LinkedHashMap<String, Long>> bag = new LinkedHashMap<>();
        long gold = 0;
        long rocks = 0;
        long money = 0;

        for (int i = 0; i < save.length; i += 2) {
            String name = save[i];
            long count = Long.parseLong(save[i + 1]);

            String type = "";

            if (name.length() == 3) {
                type = "Cash";
            } else if (name.toLowerCase().endsWith("gem")) {
                type = "Gem";
            } else if (name.equalsIgnoreCase("gold")) {
                type = "Gold";
            }

            if (type.equals("")) {
                continue;
            } else if (isaBoolean(input, bag, count)) {
                continue;
            }

            switch (type) {
                case "Gem":
                    if (!bag.containsKey(type)) {
                        if (bag.containsKey("Gold")) {
                            if (isGold(bag, count)) {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    } else if (isGold(bag, count, type, "Gold")) {
                        continue;
                    }
                    break;
                case "Cash":
                    if (!bag.containsKey(type)) {
                        if (bag.containsKey("Gem")) {
                            if (isGold(bag, count)) {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    } else if (isGold(bag, count, type, "Gem")) {
                        continue;
                    }
                    break;
            }

            if (!bag.containsKey(type)) {
                bag.put((type), new LinkedHashMap<>());
            }

            if (!bag.get(type).containsKey(name)) {
                bag.get(type).put(name, 0L);
            }

            bag.get(type).put(name, bag.get(type).get(name) + count);
            if ("Gold".equals(type)) {
                gold += count;
            } else if ("Gem".equals(type)) {
                rocks += count;
            } else if ("Cash".equals(type)) {
                money += count;
            }
        }

        printResult(bag);
    }

    private static void printResult(Map<String, LinkedHashMap<String, Long>> bag) {
        for (var entry : bag.entrySet()) {
            Long sumValues = entry.getValue().values().stream().mapToLong(l -> l).sum();

            System.out.printf("<%s> $%s%n", entry.getKey(), sumValues);

            entry.getValue().entrySet().stream().sorted((e1, e2) ->
                    e2.getKey().compareTo(e1.getKey())).forEach(i ->
                    System.out.println("##" + i.getKey() + " - " + i.getValue()));

        }
    }

    private static boolean isaBoolean(long input, Map<String, LinkedHashMap<String, Long>> bag, long count) {
        return input < bag.values().stream().map(Map::values).flatMap(Collection::stream).mapToLong(e -> e).sum() + count;
    }

    private static boolean isGold(Map<String, LinkedHashMap<String, Long>> bag, long count, String type, String gold) {
        return bag.get(type).values().stream().mapToLong(e -> e).sum()
                + count > bag.get(gold).values().stream().mapToLong(e -> e).sum();
    }

    private static boolean isGold(Map<String, LinkedHashMap<String, Long>> bag, long count) {
        return count > bag.get("Gold").values().stream().mapToLong(e -> e).sum();
    }
}