package CardsWithPower;

public class Card {

    public static int cardPower(String rank, String suit) {
        int power = 0;

        Suits[] values = Suits.values();

        for (Suits value : values) {
            if (value.toString().equals(suit)) {
                power += value.suitValue;
                break;
            }
        }

        Rank[] values1 = Rank.values();

        for (Rank rank1 : values1) {
            if (rank1.toString().equals(rank)) {
                power += rank1.rankValue;
                break;
            }
        }
        return power;
    }
}
