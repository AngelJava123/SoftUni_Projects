package CardsWithPower;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static CardsWithPower.Card.cardPower;

public class Main {
    static String rank;
    static String suit;

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        rank = reader.readLine();
        suit = reader.readLine();

        int cardPower = cardPower(rank, suit);

        System.out.printf("Card name: %s of %s; Card power: %d", rank, suit, cardPower);
    }
}
