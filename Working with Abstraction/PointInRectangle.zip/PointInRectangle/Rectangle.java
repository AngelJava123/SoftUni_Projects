package PointInRectangle;

public class Rectangle {
    private final Point PointA;
    private final Point PointB;

    public Rectangle(Point pointA, Point pointB) {
        this.PointA = pointA;
        this.PointB = pointB;
    }

    public boolean Contains(Point point) {
        return point.isGreaterThanOrEqual(PointA) && point.isLessThanOrEqual(PointB);
    }
}
