package PointInRectangle;

public class Point {
    private final int X;
    private final int Y;

    public Point(int x, int y) {
       this.X = x;
       this.Y = y;
    }

    public boolean isGreaterThanOrEqual (Point p) {
        return X >= p.X && Y >= p.Y;
    }

    public boolean isLessThanOrEqual (Point p) {
        return X <= p.X && Y <= p.Y;
    }
}
