package PointInRectangle;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int[] input = Arrays.stream(reader.readLine().split("\\s+")).
                mapToInt(Integer::parseInt).toArray();

        Point pointA = new Point(input[0], input[1]);
        Point pointB = new Point(input[2], input[3]);

        Rectangle rectangle = new Rectangle(pointA, pointB);

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {

            int[] points = Arrays.stream(reader.readLine().split("\\s+")).
                    mapToInt(Integer::parseInt).toArray();

            Point p = new Point(points[0], points[1]);

            boolean isInside = rectangle.Contains(p);

            System.out.println(isInside);
        }
    }
}
