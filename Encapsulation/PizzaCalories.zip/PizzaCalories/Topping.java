package PizzaCalories;

import java.util.HashMap;
import java.util.Map;

public class Topping {
    private String toppingType;
    private double weight;

    public Topping(String toppingType, double weight) {
        setToppingType(toppingType);
        setWeight(weight);
    }

    private void setToppingType(String toppingType) {

        if (toppingType.equals("Meat") || toppingType.equals("Cheese")
                || toppingType.equals("Veggies") || toppingType.equals("Sauce")) {
            this.toppingType = toppingType;
        } else {
            throw new IllegalArgumentException("Cannot place " + toppingType + " on top of your pizza.");
        }
    }

    private void setWeight(double weight) {

        if (weight >= 1 && weight <= 50) {
            this.weight = weight;
        } else {
            throw new IllegalArgumentException(toppingType + " weight should be in the range [1..50].");
        }
    }

    public double calculateCalories () {
        Map<String, Double> param = new HashMap<>();

        param.put("Meat", 1.2);
        param.put("Cheese", 1.1);
        param.put("Sauce", 0.9);
        param.put("Veggies", 0.8);

        return (2 * weight) * param.get(toppingType);
    }
}
