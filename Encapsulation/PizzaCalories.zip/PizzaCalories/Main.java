package PizzaCalories;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        //Pizza {pizzaName} {numberOfToppings}
        String[] pizza1 = reader.readLine().split(" ");
        String pizzaName = pizza1[1];
        int numberOfToppings = Integer.parseInt(pizza1[2]);

        //Dough {flourType} {bakingTechnique} {weightInGrams}
        String[] dough1 = reader.readLine().split(" ");
        String flourType = dough1[1];
        String bakingTechnique = dough1[2];
        double weightInGrams = Double.parseDouble(dough1[3]);

        Pizza pizza;
        Dough dough;
        try {
            pizza = new Pizza(pizzaName, numberOfToppings);
            dough = new Dough(flourType, bakingTechnique, weightInGrams);
            pizza.setDough(dough);

            String toppings = reader.readLine();

            while (!toppings.equals("END")) {

                String[] topping = toppings.split(" ");
                String toppingType = topping[1];
                double weightGrams = Double.parseDouble(topping[2]);

                pizza.addTopping(new Topping(toppingType, weightGrams));

                toppings = reader.readLine();
            }

            System.out.printf("%s - %.2f", pizzaName, pizza.getOverallCalories());

        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
