package ClassBox;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        double length = Double.parseDouble(reader.readLine());
        double width = Double.parseDouble(reader.readLine());
        double height = Double.parseDouble(reader.readLine());

        Box box = null;

        try {
             box = new Box(length, width, height);

            double lateral = box.calculateLateralSurfaceArea();
            double volume = box.calculateVolume();
            double surfaceArea = box.calculateSurfaceArea();

            System.out.printf("Surface Area - %.2f%n", surfaceArea);
            System.out.printf("Lateral Surface Area - %.2f%n", lateral);
            System.out.printf("Volume – %.2f", volume);

        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }
}
