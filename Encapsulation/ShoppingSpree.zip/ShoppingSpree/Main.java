package ShoppingSpree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Map<String, Person> name = new LinkedHashMap<>();
        Map<String, Product> products = new LinkedHashMap<>();

        String[] names = reader.readLine().split(";");
        String[] productsPrice = reader.readLine().split(";");

        nameAndMoney(name, names);
        productAndCost(products, productsPrice);

        String buyProducts = reader.readLine();
        while (!buyProducts.equals("END")) {

            String name1 = buyProducts.split(" ")[0];
            String product = buyProducts.split(" ")[1];

            if (!name.isEmpty() && !product.isEmpty()) {
                name.get(name1).buyProduct(products.get(product));
            }
            buyProducts = reader.readLine();
        }
        StringBuilder sb = new StringBuilder();

        for (Map.Entry<String, Person> person : name.entrySet()) {
            if (person.getValue().getProducts().isEmpty()) {
                System.out.println(person.getKey() + " - Nothing bought");
            } else {
                System.out.print(person.getKey() + " - ");
                int count = 0;
                for (Product p : person.getValue().getProducts()) {
                    count++;
                    sb.append(p.getName());

                    if (count != person.getValue().getProducts().size()) {
                        sb.append(", ");
                    }
                }
                System.out.println(sb.toString().trim());
                sb.setLength(0);
            }
        }
    }

    private static void productAndCost(Map<String, Product> products, String[] productsPrice) {
        for (String product : productsPrice) {
            String productName = product.split("=")[0];
            double cost = Double.parseDouble(product.split("=")[1]);

            try {
                products.put(productName, new Product(productName, cost));

            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private static void nameAndMoney(Map<String, Person> products, String[] names) {
        Person person;
        for (String name : names) {
            String nameSplit = name.split("=")[0];
            double money = Double.parseDouble(name.split("=")[1]);

            try {
                person = new Person(nameSplit, money);

                products.put(nameSplit, person);

            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
