package harvestingFields;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class Main {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Field[] fields = RichSoilLand.class.getDeclaredFields();

        String command = reader.readLine();
        while (!command.equals("HARVEST")) {

            switch (command) {
                case "all":
                    for (Field field : fields) {
                        int mod = field.getModifiers();
                        print(field, mod);
                    }
                    break;
                case "protected":
                    for (Field field : fields) {
                        int mod = field.getModifiers();
                        if (Modifier.isProtected(mod)) {
                            print(field, mod);
                        }
                    }
                    break;
                case "private":
                    for (Field field : fields) {
                        int mod = field.getModifiers();
                        if (Modifier.isPrivate(mod)) {
                            print(field, mod);
                        }
                    }
                    break;
                case "public":
                    for (Field field : fields) {
                        int mod = field.getModifiers();
                        if (Modifier.isPublic(mod)) {
                            print(field, mod);
                        }
                    }
                    break;
            }
            command = reader.readLine();
        }
    }

    private static void print(Field field, int mod) {
        System.out.println(Modifier.toString(mod) + " " +
                field.getType().getSimpleName() + " " + field.getName());
    }
}
