import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        //  Class<Reflection> clazz = Reflection.class;
        //  System.out.println(clazz);
        //  System.out.println(clazz.getSuperclass());
        //  for (Object interfaces : clazz.getInterfaces()) {
        //      System.out.println(interfaces.toString());

        //      Reflection reflection = clazz.getDeclaredConstructor().newInstance();
        //      System.out.println(reflection);

        Method[] methods = Reflection.class.getDeclaredMethods();

        List<Method> getters = new ArrayList<>();
        List<Method> setters = new ArrayList<>();

        for (Method method : methods) {
            if (method.getName().contains("get")) {
                getters.add(method);
            } else if (method.getName().contains("set")) {
                setters.add(method);
            }
        }
        getters.stream().sorted(Comparator.comparing(Method::getName)).
                forEach(method -> {
                    System.out.printf("%s will return class %s%n",
                            method.getName(), method.getReturnType().getName());
                });

        setters.stream().sorted(Comparator.comparing(Method::getName)).
                forEach(method -> {
                    System.out.printf("%s and will set field of class %s%n",
                            method.getName(), method.getParameterTypes()[0].getName());
                });

      // Field[] fields = Reflection.class.getDeclaredFields();

      // List<Field> sortedFields = new ArrayList<>();

      // Arrays.stream(fields).sorted(Comparator.comparing(Field::getName))
      //         .forEach(sortedFields::add);

      // for (Field field : sortedFields) {
      //     int modifiers = field.getModifiers();
      //     if (!Modifier.isPrivate(modifiers)) {
      //         System.out.println(field.getName() + " must be private!");
      //     }

      // }
      // Method[] methods = Reflection.class.getDeclaredMethods();

      //   List<Method> getters = new ArrayList<>();
      //   List<Method> setters = new ArrayList<>();

      //   for (Method method : methods) {
      //       if (method.getName().contains("get")) {
      //           getters.add(method);
      //       } else if (method.getName().contains("set")) {
      //           setters.add(method);
      //       }
      //   }

      // List<Method> sortedGetters = new ArrayList<>();
      // List<Method> sortedSetters = new ArrayList<>();

      // getters.stream().sorted(Comparator.comparing(Method::getName)).
      //           forEach(sortedGetters::add);

      //   setters.stream().sorted(Comparator.comparing(Method::getName)).
      //           forEach(sortedSetters::add);

      // for (Method getter : sortedGetters) {
      //     int modifiers = getter.getModifiers();
      //     if (!Modifier.isPublic(modifiers)) {
      //         System.out.println(getter.getName() + " have to be public!");
      //     }
      // }
      // for (Method setter : sortedSetters) {
      //     int modifiers = setter.getModifiers();
      //     if (!Modifier.isPrivate(modifiers)) {
      //         System.out.println(setter.getName() + " have to be private!");
      //     }
      // }
    }
}
