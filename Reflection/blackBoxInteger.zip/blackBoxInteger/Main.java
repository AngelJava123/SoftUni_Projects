package blackBoxInteger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException, NoSuchMethodException,
            InvocationTargetException, IllegalAccessException, InstantiationException, NoSuchFieldException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Class<BlackBoxInt> clazz = BlackBoxInt.class;
        Constructor<BlackBoxInt> constructor = clazz.getDeclaredConstructor();
        constructor.setAccessible(true);
        BlackBoxInt blackBoxInt = constructor.newInstance();
        List<Method> methods = Arrays.asList(clazz.getDeclaredMethods());
        Field innerValue = clazz.getDeclaredField("innerValue");

        String command = reader.readLine();
        while (!command.equals("END")) {

            String[] commandData = command.split("_");

            String commandName = commandData[0];
            int value = Integer.parseInt(commandData[1]);

            Method currentMethod = methods.stream()
                    .filter(method -> method.getName().equals(commandName))
                    .findFirst().orElse(null);

            assert currentMethod != null;
            currentMethod.setAccessible(true);
            currentMethod.invoke(blackBoxInt, value);

            innerValue.setAccessible(true);
            System.out.println(innerValue.get(blackBoxInt));

            command = reader.readLine();
        }
    }
}
