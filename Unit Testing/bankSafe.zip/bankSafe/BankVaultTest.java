package bankSafe;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;

public class BankVaultTest {
    BankVault bankVault;

    @Before
    public void setUp() {
      this.bankVault = new BankVault();
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testExceptionOnUnmodifiableMap() {
        bankVault.getVaultCells().clear();
    }
    @Test
    public void testCorrectValuesOfMap() {
        Assert.assertEquals(12, bankVault.getVaultCells().size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void addItemToNonExistingCell() throws OperationNotSupportedException {
        Item item = new Item("Angel", "28");
        bankVault.addItem("test", item);
        Assert.assertNull(bankVault.getVaultCells().get("test"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCellNull() throws OperationNotSupportedException {
        Item item = new Item("Angel", "28");
        Item item1 = new Item("Gala", "54");
        bankVault.addItem("B1", item);
        Assert.assertEquals(bankVault.getVaultCells().get("B1").getItemId(), item.getItemId());
        bankVault.addItem("B1", item1);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void testIfItemExist() throws OperationNotSupportedException {
        Item item = new Item("Angel", "28");
        bankVault.addItem("B1", item);
        Assert.assertEquals(bankVault.getVaultCells().get("B1").getItemId(), item.getItemId());
        bankVault.addItem("B2", item);
    }

    @Test
    public void testReturnOdAdd() throws OperationNotSupportedException {
        Item item = new Item("Angel", "28");
        bankVault.addItem("B1", item);
        Assert.assertEquals(bankVault.getVaultCells().get("B1").getOwner(),item.getOwner());
        Assert.assertEquals(bankVault.getVaultCells().get("B1").getItemId(),item.getItemId());

    }

    @Test(expected = IllegalArgumentException.class)
    public void removeItem() {
        Item item = new Item("Angel", "28");
        Assert.assertNull(String.valueOf(bankVault.getVaultCells().get("T8")), null);
        bankVault.removeItem("T8", item);
    }

    @Test(expected = IllegalArgumentException.class)
    public void removeItemException() {
        Item item = new Item("Angel", "28");
        Assert.assertNull(bankVault.getVaultCells().get("B1"));
        bankVault.removeItem("B1", item);
    }

    @Test
    public void testPutNull() throws OperationNotSupportedException {
        Item item = new Item("Angel", "28");
        bankVault.addItem("B1", item);
        Assert.assertEquals(bankVault.getVaultCells().get("B1").getOwner(),item.getOwner());
        Assert.assertEquals(bankVault.getVaultCells().get("B1").getItemId(),item.getItemId());

        bankVault.removeItem("B1", item);
        Assert.assertNull(bankVault.getVaultCells().get("B1"));
    }

    @Test
    public void testPutNullValue() throws OperationNotSupportedException {
        Item item = new Item("Angel", "28");
        bankVault.addItem("B1", item);

        String expected = String.format("Remove item:%s successfully!", item.getItemId());
        String actual = bankVault.removeItem("B1", item);
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void testAddValue() throws OperationNotSupportedException {
        Item item = new Item("Angel", "28");

        String expected = String.format("Item:%s saved successfully!", item.getItemId());
        String actual = bankVault.addItem("B1", item);
        Assert.assertEquals(expected, actual);
    }
}