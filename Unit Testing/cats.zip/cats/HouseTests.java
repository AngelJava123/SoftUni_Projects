package cats;

import org.junit.Assert;
import org.junit.Test;

public class HouseTests {

    @Test
    public void testConstructor() {
        House house = new House("Angel", 54);
        Assert.assertEquals("Angel", house.getName());
        Assert.assertEquals(54, house.getCapacity());
        Assert.assertEquals(0, house.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void testNameNull() {
        House house = new House(null, 54);
    }

    @Test(expected = NullPointerException.class)
    public void testNameEmpty() {
        House house = new House("", 54);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCapacityBelowZero() {
        House house = new House("", -54);
    }

    @Test
    public void testAddCat() {
        House house = new House("Angel", 54);
        Cat cat = new Cat("Jessy");
        house.addCat(cat);
        Assert.assertEquals(1, house.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCatInvalid() {
        House house = new House("Angel", 1);
        Cat cat = new Cat("Jessy");
        Cat cat1 = new Cat("Tom");
        house.addCat(cat);
        house.addCat(cat1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveCatInvalid() {
        House house = new House("Angel", 4);
        Cat cat = new Cat("Jessy");
        Cat cat1 = new Cat("Tom");
        house.addCat(cat);
        house.addCat(cat1);
        house.removeCat("null");
    }

    @Test
    public void testRemoveCatInvalidSuccessful() {
        House house = new House("Angel", 4);
        Cat cat = new Cat("Jessy");
        Cat cat1 = new Cat("Tom");
        house.addCat(cat);
        house.addCat(cat1);
        Assert.assertEquals(2, house.getCount());
        house.removeCat("Tom");
        Assert.assertEquals(1, house.getCount());
    }

    @Test
    public void testCatForSell() {
        House house = new House("Angel", 4);
        Cat cat = new Cat("Jessy");
        Cat cat1 = new Cat("Tom");
        house.addCat(cat);
        house.addCat(cat1);
        Assert.assertEquals(cat1, house.catForSale("Tom"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCatForSellNull() {
        House house = new House("Angel", 4);
        Cat cat = new Cat("Jessy");
        Cat cat1 = new Cat("Tom");
        house.addCat(cat);
        house.addCat(cat1);
        house.catForSale("Patrick");
    }

    @Test
    public void testStatistics() {
        String expected = "The cat Tom is in the house Angel!";
        House house = new House("Angel", 4);
        Cat cat1 = new Cat("Tom");
        house.addCat(cat1);

        Assert.assertEquals(expected, house.statistics());
    }

    @Test
    public void testHungryCat() {
        House house = new House("Angel", 4);
        Cat cat = new Cat("Jessy");
        Cat cat1 = new Cat("Tom");
        house.addCat(cat);
        house.addCat(cat1);
        house.catForSale("Tom");
        Assert.assertFalse(cat1.isHungry());
    }
}
