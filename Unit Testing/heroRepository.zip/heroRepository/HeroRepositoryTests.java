package heroRepository;

import org.junit.Assert;
import org.junit.Test;

public class HeroRepositoryTests {

    @Test
    public void testConstructorAndHeroCreation() {
        HeroRepository heroRepository = new HeroRepository();
        Assert.assertEquals(0, heroRepository.getCount());
    }

    @Test
    public void testCountHeroes() {
        HeroRepository heroRepository = new HeroRepository();
        Assert.assertEquals(0, heroRepository.getHeroes().size());

        Hero hero = new Hero("Angel", 28);
        Hero hero1 = new Hero("Valentin", 60);
        Hero hero2 = new Hero("Krasimira", 56);

        String expected = "Successfully added hero Angel with level 28";
        Assert.assertEquals(heroRepository.create(hero), expected);

        String expected1 = "Successfully added hero Valentin with level 60";
        Assert.assertEquals(heroRepository.create(hero1), expected1);

        String expected2 = "Successfully added hero Krasimira with level 56";
        Assert.assertEquals(heroRepository.create(hero2), expected2);

        Assert.assertEquals(3, heroRepository.getHeroes().size());

    }

    @Test(expected = NullPointerException.class)
    public void nullHero() {
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.create(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDuplicateHeroes() {
        HeroRepository heroRepository = new HeroRepository();
        Hero hero = new Hero("Angel", 28);
        heroRepository.create(hero);
        heroRepository.create(hero);
    }

    @Test(expected = NullPointerException.class)
    public void testRemove() {
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.remove(null);
    }

    @Test(expected = NullPointerException.class)
    public void testRemoveEmpty() {
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.remove("");
    }

    @Test
    public void testRemoveName() {
        HeroRepository heroRepository = new HeroRepository();
        Hero hero = new Hero("Angel", 28);
        heroRepository.create(hero);
       Assert.assertTrue(heroRepository.remove("Angel"));
    }

    @Test
    public void testGetHighestLevel() {
        HeroRepository heroRepository = new HeroRepository();

        Hero hero = new Hero("Angel", 28);
        Hero hero1 = new Hero("Valentin", 60);
        Hero hero2 = new Hero("Krasimira", 56);

        heroRepository.create(hero);
        heroRepository.create(hero1);
        heroRepository.create(hero2);

        Assert.assertEquals(hero1, heroRepository.getHeroWithHighestLevel());
    }

    @Test
    public void testGetByName() {
        HeroRepository heroRepository = new HeroRepository();

        Hero hero = new Hero("Angel", 28);
        Hero hero1 = new Hero("Valentin", 60);
        Hero hero2 = new Hero("Krasimira", 56);

        heroRepository.create(hero);
        heroRepository.create(hero1);
        heroRepository.create(hero2);

        Assert.assertEquals(hero1, heroRepository.getHero("Valentin"));
    }
}
