package shopAndGoods;


import org.junit.Assert;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;

public class ShopTest {

    @Test
    public void testMapValues() {
        Shop shop = new Shop();
        Assert.assertEquals(shop.getShelves().size(), 12);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddGoodsNonExistingShelf() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Waffles", "342");
        shop.addGoods("Shelves13", goods);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddGoodsOnTakenShelf() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Waffles", "342");
        Goods goods1 = new Goods("Kinder", "726");
        shop.addGoods("Shelves12", goods);
        shop.addGoods("Shelves12", goods1);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void testAddGoodsIsAlreadyOnShelf() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Waffles", "342");
        shop.addGoods("Shelves12", goods);
        shop.addGoods("Shelves11", goods);
    }

    @Test
    public void testAddGoodsSuccessfullyOnShelf() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Waffles", "342");
        String expected = "Goods: 342 is placed successfully!";
        Assert.assertEquals(expected,shop.addGoods("Shelves12", goods));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveGoodsOnShelf() {
        Shop shop = new Shop();
        Goods goods = new Goods("Waffles", "342");
        shop.removeGoods("Shelves13", goods);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveGoodsOnShelfThatDoesNotExist() {
        Shop shop = new Shop();
        Goods goods = new Goods("Waffles", "342");
        shop.removeGoods("Shelves12", goods);
    }

    @Test
    public void testRemoveGoodsOnShelfSuccessful() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Waffles", "342");
        shop.addGoods("Shelves12", goods);
        String expected = "Goods: 342 is removed successfully!";
        Assert.assertEquals(expected, shop.removeGoods("Shelves12", goods));
        Assert.assertNull(shop.getShelves().get("Shelves12"));
    }
}