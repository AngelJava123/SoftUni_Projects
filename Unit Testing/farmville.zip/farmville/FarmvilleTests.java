package farmville;

import org.junit.Assert;
import org.junit.Test;

public class FarmvilleTests {

    @Test
    public void testConstructor() {
        Animal animal = new Animal("Cat", 25);
        Farm farm = new Farm("Angel", 45);

        Assert.assertEquals("Angel", farm.getName());
        Assert.assertEquals(45, farm.getCapacity());
        Assert.assertEquals(0, farm.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddException() {
        Farm farm = new Farm("Angel", 2);
        Animal animal = new Animal("Cat", 25);
        Animal animal1 = new Animal("Dog", 12);
        Animal animal2 = new Animal("Zebra", 32);

        farm.add(animal);
        farm.add(animal1);
        farm.add(animal2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddExistingAnimal() {
        Farm farm = new Farm("Angel", 2);
        Animal animal = new Animal("Cat", 25);
        Animal animal1 = new Animal("Cat", 23);

        farm.add(animal);
        farm.add(animal1);
    }

    @Test
    public void testRemoveAnimal() {
        Farm farm = new Farm("Angel", 4);
        Animal animal = new Animal("Cat", 25);
        Animal animal1 = new Animal("Dog", 12);
        Animal animal2 = new Animal("Zebra", 32);

        farm.add(animal);
        farm.add(animal1);
        farm.add(animal2);

        Assert.assertTrue(farm.remove("Cat"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetCapacity() {
        Farm farm = new Farm("Angel", -4);
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameNull() {
        Farm farm = new Farm(null, 4);
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameEmpty() {
        Farm farm = new Farm("", 4);
    }
}
