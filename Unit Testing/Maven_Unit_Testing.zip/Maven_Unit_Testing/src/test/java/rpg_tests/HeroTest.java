package rpg_tests;

import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import rpg_lab.Hero;
import rpg_lab.Target;
import rpg_lab.Weapon;

public class HeroTest {
    private static final String HERO_NAME = "Ragnarok";

    @Test
    public void attackGainExperienceIfTargetIsDead() {
        Weapon weaponMock = Mockito.mock(Weapon.class);
        Target targetMock = Mockito.mock(Target.class);
        Mockito.when(targetMock.isDead()).thenReturn(true);
        Mockito.when(targetMock.giveExperience()).thenReturn(100);

        Hero hero = new Hero(HERO_NAME, weaponMock);

        hero.attack(targetMock);
        Assert.assertEquals("Wrong experience", 100, hero.getExperience());
    }
}
