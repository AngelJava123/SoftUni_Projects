package rpg_tests;

import org.junit.Assert;
import org.junit.Test;
import rpg_lab.Axe;
import rpg_lab.Dummy;

public class DummyTest {

    @Test
    public void ifDummyLooseHealthIfAttacked() {
        Axe axe = new Axe(10, 10);
        Dummy dummy = new Dummy(20, 10);

        axe.attack(dummy);

        Assert.assertEquals(10, dummy.getHealth());
    }

    @Test(expected = IllegalStateException.class)
    public void ifDeadDummyThrowsExceptionIfAttacked() {
        Axe axe = new Axe(10, 10);
        Dummy dummy = new Dummy(10, 20);

        axe.attack(dummy);
        axe.attack(dummy);

        Assert.assertEquals(0, dummy.getHealth());
    }

    @Test
    public void ifDeadDummyGiveXP() {
        Axe axe = new Axe(10, 10);
        Dummy dummy = new Dummy(10, 20);

        axe.attack(dummy);

        Assert.assertEquals(20, dummy.giveExperience());
    }

    @Test(expected = IllegalStateException.class)
    public void ifAliveDummyGiveXP() {
        Axe axe = new Axe(10, 10);
        Dummy dummy = new Dummy(20, 10);

        axe.attack(dummy);

        Assert.assertEquals(10, dummy.giveExperience());


    }
}
