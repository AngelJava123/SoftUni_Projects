package halfLife;

import org.junit.Assert;
import org.junit.Test;

public class PlayerTests {

    @Test
    public void testGetCorrectUserName() {
        Player player = new Player("Angel", 28);
        Assert.assertEquals("Angel", player.getUsername());
    }

    @Test(expected = NullPointerException.class)
    public void testThrowExceptionWhenUsernameNull() {
        Player player;
        player = new Player(null, 43);
        Assert.assertNull(player.getUsername());
    }

    @Test(expected = NullPointerException.class)
    public void testEmptyUsername() {
        Player player;
        player = new Player(" ", 43);
        Assert.assertEquals(" ", player.getUsername());
    }

    @Test
    public void testGetCorrectHealth() {
        Player player = new Player("Angel", 28);
        Assert.assertEquals(28, player.getHealth());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetCorrectHealthLessThanZero() {
        Player player = new Player("Angel", -10);
        Assert.assertEquals(-10, player.getHealth());
    }

    @Test(expected = NullPointerException.class)
    public void addGunException() {
       Player player = new Player("Angel", 32);
       Gun gun = null;
       player.addGun(gun);
    }

    @Test
    public void addGun() {
        Player player = new Player("Angel", 32);
        String pistolName = "Pistol";
        Gun gun = new Gun(pistolName, 23);
        player.addGun(gun);

        Assert.assertEquals(player.getGun("Pistol"), gun);
    }

    @Test
    public void removeGun() {
        Player player = new Player("Angel", 32);
        String pistolName = "Pistol";
        Gun gun = new Gun(pistolName, 23);
        player.addGun(gun);
        Assert.assertEquals(player.getGun("Pistol"), gun);
        Assert.assertTrue(player.removeGun(gun));
    }

    @Test
    public void testListOfGuns() {
        Player player = new Player("Angel", 32);
        Gun gun = new Gun("Pistol", 32);
        Gun gun1 = new Gun("Automate", 46);
        Gun gun2 = new Gun("Solar", 12);
        Gun gun3 = new Gun("Knife", 65);

        player.addGun(gun);
        player.addGun(gun1);
        player.addGun(gun2);
        player.addGun(gun3);

        Assert.assertEquals(4, player.getGuns().size());
    }

    @Test(expected = IllegalStateException.class)
    public void testTakeDamageException() {
        Player player = new Player("Angel", 0);
        player.takeDamage(32);
    }

    @Test
    public void testTakeDamage() {
        Player player = new Player("Angel", 20);
        player.takeDamage(30);

        Assert.assertEquals(0, player.getHealth());
    }

    @Test
    public void testTakeDamageHealthMinusDamage() {
        Player player = new Player("Angel", 30);
        player.takeDamage(20);

        int result = player.getHealth();

        Assert.assertEquals(10, result);
    }

    @Test
    public void testBullets() {
        Gun gun = new Gun("Angel", 28);
        Assert.assertEquals(28, gun.getBullets());
    }
}
