package computers;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class ComputerManagerTests {

    @Test
    public void testInitialisationOfListWorkCorrect() {

        List<Computer> computerList = new ArrayList<>();

        Computer computer = new Computer("Sony", "Bravia", 500.43);
        Computer computer1 = new Computer("LG", "Oled", 1453.53);
        Computer computer2 = new Computer("Samsung", "Qled", 5002.65);

        computerList.add(computer);
        computerList.add(computer1);
        computerList.add(computer2);

        Assert.assertEquals("Sony", computerList.get(0).getManufacturer());
        Assert.assertEquals("Bravia", computerList.get(0).getModel());
        Assert.assertEquals(500.43, 500.43, computerList.get(0).getPrice());

        Assert.assertEquals(3, computerList.size());
    }

    @Test
    public void testComputerManagerConstructor() {
        ComputerManager computerManager = new ComputerManager();
        Assert.assertEquals(0, computerManager.getComputers().size());
        Assert.assertEquals(0, computerManager.getCount());
    }

    @Test
    public void testAddComputer() {
        ComputerManager computerManager = new ComputerManager();

        Computer computer = new Computer("Sony", "Bravia", 500.43);
        Computer computer1 = new Computer("LG", "Oled", 1453.53);
        Computer computer2 = new Computer("Samsung", "Qled", 5002.65);

        computerManager.addComputer(computer);
        computerManager.addComputer(computer1);
        computerManager.addComputer(computer2);

        Assert.assertEquals(computer, computerManager.getComputer("Sony", "Bravia"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testThrowExceptionWhenAddComputer() {
        ComputerManager computerManager = new ComputerManager();

        Computer computer = new Computer("Sony", "Bravia", 500.43);
        Computer computer1 = new Computer("Sony", "Bravia", 500.43);

        computerManager.addComputer(computer);
        computerManager.addComputer(computer1);
    }

    @Test
    public void testRemoveComputer() {
        ComputerManager computerManager = new ComputerManager();

        Computer computer = new Computer("Sony", "Bravia", 500.43);
        Computer computer1 = new Computer("LG", "Oled", 1453.53);

        computerManager.addComputer(computer);
        computerManager.addComputer(computer1);

        Assert.assertEquals(2, computerManager.getCount());

        computerManager.removeComputer("Sony", "Bravia");

        Assert.assertEquals(1, computerManager.getCount());

        Assert.assertEquals(computer1, computerManager.getComputer("LG", "Oled"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetComputerWhichDoesNotExist() {
        ComputerManager computerManager = new ComputerManager();

        Computer computer = new Computer("Sony", "Bravia", 500.43);

        computerManager.addComputer(computer);
        computerManager.getComputer("LG", "Oled");
    }

    @Test
    public void testGetComputersByManufacturer() {
        ComputerManager computerManager = new ComputerManager();

        List<Computer> computerList = new ArrayList<>();

        Computer computer = new Computer("Sony", "Bravia", 500.43);
        Computer computer1 = new Computer("LG", "Oled", 1453.53);
        Computer computer2 = new Computer("Samsung", "Qled", 5002.65);

        computerList.add(computer1);

        computerManager.addComputer(computer);
        computerManager.addComputer(computer1);
        computerManager.addComputer(computer2);

        List<Computer> computersToReturn = computerManager.getComputersByManufacturer("LG");
        Assert.assertEquals(computerList, computersToReturn);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidationNotNull() {
        ComputerManager computerManager = new ComputerManager();

        computerManager.addComputer(null);
    }
}