import java.util.*;
import java.util.stream.Collectors;

public class ChainblockImpl implements Chainblock {
    //записи за транзакции -> id : transaction
    private Map<Integer, Transaction> transactionsByIds;

    public ChainblockImpl() {
        this.transactionsByIds = new HashMap<>();
    }

    public int getCount() {
        return this.transactionsByIds.size();
    }

    public void add(Transaction transaction) {
        int id = transaction.getId();
        if (!this.transactionsByIds.containsKey(id)) {
            this.transactionsByIds.put(id, transaction);
        }
    }

    public boolean contains(Transaction transaction) {
        return contains(transaction.getId());
    }

    public boolean contains(int id) {

        if (this.transactionsByIds.containsKey(id)) {
            return true;
        }
        return false;
    }

    public void changeTransactionStatus(int id, TransactionStatus newStatus) {
        //да нямаме транзакция с това id
        if (!this.transactionsByIds.containsKey(id)) {
            throw new IllegalArgumentException();
        }
        //да имаме транзакция с това id
        Transaction transaction = this.transactionsByIds.get(id);
        transaction.setStatus(newStatus);
        //this.transactionsByIds.put(id, transaction);
    }

    public void removeTransactionById(int id) {
        //да нямаме транзакция с това id
        if (!this.transactionsByIds.containsKey(id)) {
            throw new IllegalArgumentException();
        }
        //да имаме транзакция с това id
        this.transactionsByIds.remove(id);
    }

    public Transaction getById(int id) {
        if (!this.transactionsByIds.containsKey(id)) {
            throw new IllegalArgumentException();
        }
        return this.transactionsByIds.get(id);
    }

    public Iterable<Transaction> getByTransactionStatus(TransactionStatus status) {
        List<Transaction> filteredTransactions = new ArrayList<>();

        for (Transaction transaction : this.transactionsByIds.values()) {
            if (transaction.getStatus() == status) {
                filteredTransactions.add(transaction);
            }
        }
        //да нямаме транзакция с дадения статус -> exception
        if (filteredTransactions.size() == 0) {
            throw new IllegalArgumentException();
        }
        //да имаме транзакция с дадения статус -> сортираме и връщаме всички транзакции с дадения статус
        filteredTransactions.sort(Comparator.comparing(Transaction::getAmount).reversed());
        return filteredTransactions;
    }

    public Iterable<String> getAllSendersWithTransactionStatus(TransactionStatus status) {
        List<Transaction> filteredTransactions = new ArrayList<>(); // транзакции с дадения статус
        getByTransactionStatus(status).forEach(filteredTransactions::add);
        //сортираме по amount (descending)
        filteredTransactions.stream()
                .sorted(Comparator.comparing(Transaction::getAmount).reversed())
                .collect(Collectors.toList());
        //взимам само senders (from)
        List<String> senders = filteredTransactions
                .stream()
                .map(Transaction::getFrom)
                .collect(Collectors.toList());
        //да нямаме транзакция с дадения статус -> exception
        if (senders.size() == 0) {
            throw new IllegalArgumentException();
        }
        //да имаме транзакция с дадения статус -> сортираме и връщаме всички senders с дадения статус
        return senders;
    }

    public Iterable<String> getAllReceiversWithTransactionStatus(TransactionStatus status) {
        List<Transaction> filteredTransactions = new ArrayList<>(); // транзакции с дадения статус
        getByTransactionStatus(status).forEach(filteredTransactions::add);
        //сортираме по amount (descending)
        filteredTransactions.stream()
                .sorted(Comparator.comparing(Transaction::getAmount).reversed())
                .collect(Collectors.toList());
        //взимам само receiver (to)
        List<String> receivers = filteredTransactions
                .stream()
                .map(Transaction::getTo)
                .collect(Collectors.toList());
        //да нямаме транзакция с дадения статус -> exception
        if (receivers.size() == 0) {
            throw new IllegalArgumentException();
        }
        //да имаме транзакция с дадения статус -> сортираме и връщаме всички receivers с дадения статус
        return receivers;
    }

    public Iterable<Transaction> getAllOrderedByAmountDescendingThenById() {
        return this.transactionsByIds.values()
                .stream()
                .sorted(Comparator.comparing(Transaction::getAmount).reversed()
                        .thenComparing(Transaction::getId)).collect(Collectors.toList());
    }

    public Iterable<Transaction> getBySenderOrderedByAmountDescending(String sender) {
        return null;
    }

    public Iterable<Transaction> getByReceiverOrderedByAmountThenById(String receiver) {
        return null;
    }

    public Iterable<Transaction> getByTransactionStatusAndMaximumAmount(TransactionStatus status, double amount) {
        return null;
    }

    public Iterable<Transaction> getBySenderAndMinimumAmountDescending(String sender, double amount) {
        return null;
    }

    public Iterable<Transaction> getByReceiverAndAmountRange(String receiver, double lo, double hi) {
        return null;
    }

    public Iterable<Transaction> getAllInAmountRange(double lo, double hi) {
        return null;
    }

    public Iterator<Transaction> iterator() {
        return null;
    }
}
