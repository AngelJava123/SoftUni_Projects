import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ChainblockImplTest extends TestCase {
    private Chainblock chainblock;
    private List<Transaction> transactionList;

    @Before
    public void setUp() {
        this.chainblock = new ChainblockImpl();
        this.transactionList = new ArrayList<>();
        prepareTransactions();
    }

    private void prepareTransactions() {
        Transaction firstTransaction = new TransactionImpl(1, TransactionStatus.SUCCESSFUL, "Desi", "Pesho", 10.90);
        Transaction secondTransaction = new TransactionImpl(2, TransactionStatus.SUCCESSFUL, "Desi", "Pesho", 10.80);
        Transaction thirdTransaction = new TransactionImpl(3, TransactionStatus.SUCCESSFUL, "Desi", "Pesho", 10.70);
        Transaction forthTransaction = new TransactionImpl(4, TransactionStatus.FAILED, "Desi", "Pesho", 10.60);

        this.transactionList.add(firstTransaction);
        this.transactionList.add(secondTransaction);
        this.transactionList.add(thirdTransaction);
        this.transactionList.add(forthTransaction);
    }

    private void fillChainblock() {
        this.transactionList.forEach(transaction -> chainblock.add(transaction));
    }

    //contains -> true (имаме такава транзакция) or false (нямаме такава транзакция)
    @Test
    public void testContains() {
        //false
        //empty
        Transaction transaction = this.transactionList.get(0);
        Assert.assertFalse(this.chainblock.contains(transaction));
        this.chainblock.add(transaction);
        Assert.assertTrue(this.chainblock.contains(transaction));
    }

    //add -> valid (добавяме id, което го няма)
    @Test
    public void testAddCorrectTransaction() {
        //0 transactions
        this.chainblock.add(transactionList.get(0));
        //1 transactions
        Assert.assertEquals(1, this.chainblock.getCount());
        this.chainblock.add(transactionList.get(1));
        //2 transactions
        Assert.assertEquals(2, this.chainblock.getCount());

    }

    //add -> invalid (добавяме съществуващо id)
    @Test
    public void testAddExistingTransaction() {
        //0 transactions
        this.chainblock.add(transactionList.get(0));
        //1 transactions
        Assert.assertEquals(1, this.chainblock.getCount());
        //опитаме да добавим транзакция със същото id
        this.chainblock.add(transactionList.get(0));
        Assert.assertEquals(1, this.chainblock.getCount());
    }

    //changeTransactionStatus -> да нямаме транзакция с такова id
    @Test(expected = IllegalArgumentException.class)
    public void testChangeStatusOnInvalidTransaction() {
        //0 transactions
        int id = this.transactionList.get(0).getId();
        this.chainblock.changeTransactionStatus(id, TransactionStatus.ABORTED);
    }

    //changeTransactionStatus -> смяна на статуса на транзакцията
    @Test
    public void testChangeStatusTransaction() {
        Transaction transaction = this.transactionList.get(0);
        //0 transactions
        this.chainblock.add(transaction);
        //1 transactions
        Assert.assertEquals(1, this.chainblock.getCount());
        //смяна на статуса
        this.chainblock.changeTransactionStatus(transaction.getId(), TransactionStatus.UNAUTHORIZED);
        //проверка дали е сменен статуса
        Assert.assertEquals(TransactionStatus.UNAUTHORIZED, transaction.getStatus());
    }

    //removeTransactionById -> да нямаме транзакция с такова id
    @Test(expected = IllegalArgumentException.class)
    public void testRemoveWithNoExistingId() {
        fillChainblock();
        //4 transactions
        Assert.assertEquals(4, chainblock.getCount());
        this.chainblock.removeTransactionById(this.chainblock.getCount() + 1);
    }

    //removeTransactionById -> премахнем успешно транзакцията
    @Test
    public void testSuccessfulRemoveById() {
        fillChainblock();
        //4 transactions
        Assert.assertEquals(4, chainblock.getCount());
        //премахваме транзакция
        int idRemovedTransaction = this.transactionList.get(2).getId();
        this.chainblock.removeTransactionById(idRemovedTransaction);
        //3 transactions
        Assert.assertEquals(3, chainblock.getCount());
        Assert.assertFalse(this.chainblock.contains(idRemovedTransaction));
    }

    //getById -> exception ако id не съществува
    @Test(expected = IllegalArgumentException.class)
    public void testGetByIdWithNoExistingId() {
        fillChainblock();
        this.chainblock.getById(this.chainblock.getCount() + 1);
    }

    //getById -> връща транзакцията с дадено id
    @Test
    public void testCorrectGetById() {
        fillChainblock();
        Transaction expected = this.transactionList.get(0);
        Transaction actual = this.chainblock.getById(expected.getId());
        Assert.assertEquals(expected, actual);
    }

    //getByTransactionStatus -> exception -> нямаме транзакция с такъв статус
    @Test(expected = IllegalArgumentException.class)
    public void testGetByInvalidStatus() {
        fillChainblock(); // Successful, Failed
        this.chainblock.getByTransactionStatus(TransactionStatus.ABORTED);

    }

    //getByTransactionStatus -> exception -> списък с транзакциите с дадения статус + сортиран
    @Test
    public void testGetByTransactionStatus() {
        fillChainblock();
        List<Transaction> successfulTransactions = this.transactionList
                .stream()
                .filter(transaction -> transaction.getStatus() == TransactionStatus.SUCCESSFUL)
                .collect(Collectors.toList()); //списък очакваните транзакции

        Iterable<Transaction> result = this.chainblock.getByTransactionStatus(TransactionStatus.SUCCESSFUL);
        Assert.assertNotNull(result);
        List<Transaction> resultTransactions = new ArrayList<>();//списък върнати транзакции
        result.forEach(resultTransactions::add);

        //броя на трансакциите е правилен
        Assert.assertEquals(successfulTransactions.size(), resultTransactions.size());
        //проверка дали всички върнати транзакции са с подадения статус
        resultTransactions.forEach(tr -> Assert.assertEquals(TransactionStatus.SUCCESSFUL, tr.getStatus()));
        //проверка дали върнатия списък е правилно сортиран (amount descending)
        Assert.assertEquals(successfulTransactions, resultTransactions);
    }

    //getAllSendersWithTransactionStatus -> ако нямаме транзакции с този статус -> ексепшън
    @Test(expected = IllegalArgumentException.class)
    public void testGetAllSendersWithNoExistingStatusTransactionStatus() {
        fillChainblock();
        this.chainblock.getAllSendersWithTransactionStatus(TransactionStatus.ABORTED);
    }

    //getAllSendersWithTransactionStatus -> връщаме списък с изпращачите със дадения статус на транзакцията
    @Test
    public void testGetAllSendersWithExistingStatusTransactionStatus() {
        fillChainblock();
        List<String> expectedSenders = this.transactionList
                .stream()
                .filter(tr -> tr.getStatus() == TransactionStatus.SUCCESSFUL)
                .map(Transaction::getFrom)
                .collect(Collectors.toList()); // очаквания списък

        Iterable<String> result = this.chainblock.getAllSendersWithTransactionStatus(TransactionStatus.SUCCESSFUL);
        Assert.assertNotNull(result);
        List<String> resultSenders = new ArrayList<>(); // списък с пращачите, който получавам
        result.forEach(resultSenders::add);

        //броя на праюачите със съответния статус
        Assert.assertEquals(expectedSenders.size(), resultSenders.size());

        //проверка на пращачите
        resultSenders.forEach(sender -> Assert.assertEquals("Desi", sender));
    }

    //getAllReceiversWithTransactionStatus -> ако нямаме транзакции с този статус -> ексепшън
    @Test(expected = IllegalArgumentException.class)
    public void testGetAllReceiversWithNoExistingStatusTransactionStatus() {
        fillChainblock();
        this.chainblock.getAllReceiversWithTransactionStatus(TransactionStatus.ABORTED);
    }

    //getAllReceiversWithTransactionStatus -> връщаме списък с получатели със дадения статус на транзакцията
    @Test
    public void testGetAllReceiversWithExistingStatusTransactionStatus() {
        fillChainblock();
        List<String> expectedReceivers = this.transactionList
                .stream()
                .filter(tr -> tr.getStatus() == TransactionStatus.SUCCESSFUL)
                .sorted(Comparator.comparing(Transaction::getAmount).reversed())
                .map(Transaction::getTo)
                .collect(Collectors.toList()); // очаквания списък

        Iterable<String> result = this.chainblock.getAllReceiversWithTransactionStatus(TransactionStatus.SUCCESSFUL);
        Assert.assertNotNull(result);
        List<String> resultReceivers = new ArrayList<>(); // списък с получатели, който получавам
        result.forEach(resultReceivers::add);

        //броя на получателите със съответния статус
        Assert.assertEquals(expectedReceivers.size(), resultReceivers.size());

        //проверка на получатели
        resultReceivers.forEach(receiver -> Assert.assertEquals("Pesho", receiver));
    }

    //getAllOrderedByAmountDescendingThenById
    @Test
    public void testGetAllOrderedByAmountDescendingThenById() {
        fillChainblock();
        List<Transaction> expectedTransactions = this.transactionList.stream()
                .sorted(Comparator.comparing(Transaction::getAmount).reversed()
                        .thenComparing(Transaction::getId))
                .collect(Collectors.toList());

        Iterable<Transaction> result = this.chainblock.getAllOrderedByAmountDescendingThenById();
        Assert.assertNotNull(result);
        List<Transaction> actual = new ArrayList<>();
        result.forEach(actual::add);

        //проверка за сортирането
        Assert.assertEquals(expectedTransactions, actual);

    }
}
