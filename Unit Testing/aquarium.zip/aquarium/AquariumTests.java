package aquarium;

import org.junit.Assert;
import org.junit.Test;

public class AquariumTests {


    @Test
    public void testConstructor() {
        Aquarium aquarium = new Aquarium("Lingol", 50);

        Assert.assertEquals("Lingol", aquarium.getName());
        Assert.assertEquals(50, aquarium.getCapacity());
        Assert.assertEquals(0, aquarium.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameNull() {
        Aquarium aquarium = new Aquarium(null, 50);
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameEmpty() {
        Aquarium aquarium = new Aquarium("", 50);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetCapacityBelowZero() {
        Aquarium aquarium = new Aquarium("Angel", -75);
    }

    @Test
    public void testAddFish() {
        Aquarium aquarium = new Aquarium("Largo", 50);
        Fish fish = new Fish("Krasimira");
        Fish fish1 = new Fish("Angel");
        Fish fish2 = new Fish("Valentin");
        Fish fish3 = new Fish("Simeon");
        aquarium.add(fish);
        aquarium.add(fish1);
        aquarium.add(fish2);
        aquarium.add(fish3);

        Assert.assertEquals(4, aquarium.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCapacityEqualToFishSize() {
        Aquarium aquarium = new Aquarium("Largo", 1);
        Fish fish = new Fish("Krasimira");
        Fish fish1 = new Fish("Angel");
        aquarium.add(fish);
        aquarium.add(fish1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIfFishIsInTheTank() {
        Aquarium aquarium = new Aquarium("Largo", 40);
        Fish fish = new Fish("Krasimira");
        aquarium.add(fish);
        aquarium.remove("Valentin");
    }

    @Test
    public void testIfFishIsRemoved() {
        Aquarium aquarium = new Aquarium("Largo", 40);
        Fish fish = new Fish("Krasimira");
        Fish fish1 = new Fish("Valentin");
        aquarium.add(fish);
        aquarium.add(fish1);
        Assert.assertEquals(2, aquarium.getCount());
        aquarium.remove("Valentin");
        Assert.assertEquals(1, aquarium.getCount());
    }

    @Test
    public void testReturnRequestedFishSuccessful() {
        Aquarium aquarium = new Aquarium("Largo", 40);
        Fish fish = new Fish("Krasimira");
        Fish fish1 = new Fish("Valentin");
        aquarium.add(fish);
        aquarium.add(fish1);
        Fish expected = aquarium.sellFish("Valentin");
        Assert.assertEquals(fish1, expected);
        Assert.assertFalse(fish1.isAvailable());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testReturnRequestedFishNull() {
        Aquarium aquarium = new Aquarium("Largo", 40);
        Fish fish = new Fish("Krasimira");
        Fish fish1 = new Fish("Valentin");
        aquarium.add(fish);
        aquarium.add(fish1);
        aquarium.sellFish("Angel");
    }

    @Test
    public void testReport() {
        Aquarium aquarium = new Aquarium("Largo", 40);
        Fish fish = new Fish("Krasimira");
        Fish fish1 = new Fish("Valentin");
        aquarium.add(fish);
        aquarium.add(fish1);

        String expected = "Fish available at Largo: Krasimira, Valentin";
        Assert.assertEquals(aquarium.report(), expected);
    }
}

