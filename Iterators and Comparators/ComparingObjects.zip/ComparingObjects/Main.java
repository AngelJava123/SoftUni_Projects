package ComparingObjects;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Person> people = new ArrayList<>();

        String input = reader.readLine();
        while (!input.equals("END")) {

            String[] data = input.split("\\s+");
            Person person = new Person(data[0], Integer.parseInt(data[1]), data[2]);

            people.add(person);

            input = reader.readLine();
        }
        int n = Integer.parseInt(reader.readLine());

        Person searchedPerson = people.get(n - 1);

        int countEquals = (int) people.stream().
                filter(p -> searchedPerson.compareTo(p) == 0).count();

        if (countEquals == 1) {
            System.out.println("No matches");
        } else {
            System.out.println(countEquals + " " +
                    (people.size() - countEquals) + " " + people.size());
        }
    }
}
