package StackIterator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String command = reader.readLine();
        Stack<Integer> stack = new Stack<>();
        while (!command.equals("END")) {

            String[] tokens = command.split("[, ]+");
            // "Push 1,2,3,4 -> ["Push", "1,2,3,4"]
            //"Pop" -> ["Pop"]
            switch (tokens[0]) {
                case "Push":
                    for (int i = 1; i < tokens.length; i++) {
                        stack.push(Integer.parseInt(tokens[i]));
                    }
                    break;
                case "Pop":
                    try {
                        stack.pop();
                    } catch (Exception e) {
                        System.out.println("No elements");
                    }
                    break;
            }
            command = reader.readLine();
        }
        for (int i = 1; i <= 2; i++) {
            for (int number : stack) {
                System.out.println(number);
            }
        }
    }
}
