package com.example.spring_data_intro_exercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataIntroExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataIntroExerciseApplication.class, args);
    }

}
