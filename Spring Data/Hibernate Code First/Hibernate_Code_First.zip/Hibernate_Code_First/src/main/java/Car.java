import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity(name = "cars")
public class Car extends Vehicle {
    private final static String type = "CAR";
    private int seats;
    @OneToOne(mappedBy = "car", cascade = CascadeType.ALL)
    private Plate_number plate;

    public Car(String model, double price, String fuelType, int seats) {
        super(type, model, price, fuelType);
        this.seats = seats;
    }

    public Car(int id, String type, String model, Double price, String fuelType, int seats) {
        super(id, type, model, price, fuelType);
        this.seats = seats;
    }

    public Car() {}

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public Plate_number getPlate() {
        return plate;
    }

    public void setPlate(Plate_number plate) {
        this.plate = plate;
    }

    @Override
    public String toString() {
        return "Car{" + super.toString() +
                "seats=" + seats +
                ", plate=" + plate +
                '}';
    }
}
