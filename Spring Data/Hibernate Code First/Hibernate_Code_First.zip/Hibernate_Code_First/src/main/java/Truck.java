import javax.persistence.Column;
import javax.persistence.Entity;

@Entity(name = "trucks")
public class Truck extends Vehicle {
    private final static String type = "TRUCK";
    @Column(name = "Load_capacity")
    private double loadCapacity;

    public Truck(String model, double price, String fuelType, double loadCapacity) {
        super(type, model, price, fuelType);
        this.loadCapacity = loadCapacity;
    }

    public Truck(int id, String type, String model, Double price, String fuelType, double loadCapacity) {
        super(id, type, model, price, fuelType);
        this.loadCapacity = loadCapacity;
    }

    public Truck() {
    }

    public double getLoadCapacity() {
        return loadCapacity;
    }

    public void setLoadCapacity(double loadCapacity) {
        this.loadCapacity = loadCapacity;
    }

    @Override
    public String toString() {
        return "Truck{" + super.toString() +
                "loadCapacity=" + loadCapacity +
                '}';
    }
}
