import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity(name = "planes")
public class Plane extends Vehicle {
    private final static String type = "PLANE";
    @Column(name = "passenger_capacity")
    private int passengerCapacity;
    @ManyToOne
    private Company company;

    public Plane(String model, double price, String fuelType, int passengerCapacity, Company company) {
        super(type, model, price, fuelType);
        this.passengerCapacity = passengerCapacity;
        this.company = company;
    }

    public Plane(int id, String type, String model, Double price, String fuelType, int passengerCapacity,Company company) {
        super(id, type, model, price, fuelType);
        this.passengerCapacity = passengerCapacity;
        this.company = company;
    }

    public Plane() {
    }

    public int getPassengerCapacity() {
        return passengerCapacity;
    }

    public void setPassengerCapacity(int passengerCapacity) {
        this.passengerCapacity = passengerCapacity;
    }

    @Override
    public String toString() {
        return "Plane{" + super.toString() +
                "passengerCapacity=" + passengerCapacity +
                '}';
    }
}
