import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;
import java.util.Set;

public class Main {
    public static void main(String[] args) {

        EntityManager em = Persistence.createEntityManagerFactory("vehicles").createEntityManager();

        em.getTransaction().begin(); //begin transaction

        // Persist cars and plate numbers
        Car car1 = new Car("Audi A8", 65000, "hybryd", 5);
        em.persist(car1);
        Plate_number car1PlateNumber = new Plate_number("CB23543RG", car1);
        car1.setPlate(car1PlateNumber);
        em.persist(car1PlateNumber);

        // Persist trucks
        Truck truck1 = new Truck("Fuso Canter", 120000, "gasoline", 5.5);
        em.persist(truck1);

        // Persist drivers
        Driver driver1 = new Driver("John Smith", Set.of(car1, truck1));
        car1.getDrivers().add(driver1);
        truck1.getDrivers().add(driver1);
        em.persist(driver1);

        // Persist company with all its planes using CascadeType.ALL
        Company company1 = new Company(232524646, "Software AD");
        Plane plane1 = new Plane("Boing", 130000, "kerosine", 120, company1);
        Plane plane2 = new Plane("Airbus", 150000, "kerosine", 150, company1);
        Plane plane3 = new Plane("Pilatus Business Aircraft", 900000, "kerosine", 80, company1);
        em.persist(plane1);
        em.persist(plane2);
        em.persist(plane3);
        company1.getPlanes().add(plane1);
        company1.getPlanes().add(plane2);
        company1.getPlanes().add(plane3);
        em.persist(company1);
        em.getTransaction().commit(); // end of transaction

        // Find different types of entities by id
        Car found = em.find(Car.class, 1);
        System.out.printf("Found car1: %s%n", found);
        Truck truck = em.find(Truck.class, 2);
        System.out.printf("Found truck1: %s%n", truck);
        Driver driver = em.find(Driver.class, 1);
        System.out.printf("Found driver1: %s%n", driver);

        // JPQL query
        em.createQuery("SELECT v FROM Vehicle v")
                .getResultList().forEach(System.out::println);

        // Type safe Criteria query
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Company> query = cb.createQuery(Company.class);
        Root<Company> Company_ = query.from(Company.class);
        ParameterExpression<String> name = cb.parameter(String.class, "name");
        query.select(Company_).where(cb.equal(Company_.get("name"), name));
        TypedQuery<Company> typedQuery = em.createQuery(query);
        Company companyFound = typedQuery.setParameter("name", "Software AD").getSingleResult();

        System.out.printf("Company '%s' planes:%n", companyFound);
        for (Plane p : companyFound.getPlanes()) {
            System.out.println("---> " + p);
        }
    }
}
