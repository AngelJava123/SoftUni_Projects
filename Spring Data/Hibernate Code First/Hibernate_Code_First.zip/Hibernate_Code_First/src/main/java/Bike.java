import javax.persistence.Entity;

@Entity(name = "bikes")
public class Bike extends Vehicle {
    private final static String type = "BIKE";

    public Bike(String model, double price, String fuelType) {
        super(type, model, price, fuelType);
    }

    public Bike(int id, String type, String model, Double price, String fuelType) {
        super(id, type, model, price, fuelType);
    }

    public Bike() {
    }

    @Override
    public String toString() {
        return "Bike{" + super.toString() +
                '}';
    }
}
