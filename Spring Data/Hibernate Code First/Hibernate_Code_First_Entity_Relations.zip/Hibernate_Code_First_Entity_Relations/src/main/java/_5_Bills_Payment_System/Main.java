package _5_Bills_Payment_System;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU_name");
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();

        User user = new User("John", "Smith", "john@abv.bg", "gre_3563RD");
        User user1 = new User("Michael", "Scot", "michael@abv.bg", "sapo36646");

        BankAccount bank_account = new BankAccount(4674, user,
                "UniCredit", "UNCR4435983748673857GTWF");

        BankAccount bank_account1 = new BankAccount(9367, user1,
                "DSK", "DSKA44355893868857FMLR");

        CreditCard creditCard1 = new CreditCard(3466, user,
                "PLATINUM", 2, 2022);

        CreditCard creditCard2 = new CreditCard(7563, user,
                "GOLD", 7, 2024);

        CreditCard creditCard3 = new CreditCard(7563, user1,
                "BASIC", 9, 2023);


        user.getBillingDetails().add(bank_account);
        user.getBillingDetails().add(creditCard1);
        user.getBillingDetails().add(creditCard2);
        user1.getBillingDetails().add(bank_account1);
        user1.getBillingDetails().add(creditCard3);

        em.persist(user);
        em.persist(user1);

        em.getTransaction().commit();
        em.close();
    }
}
