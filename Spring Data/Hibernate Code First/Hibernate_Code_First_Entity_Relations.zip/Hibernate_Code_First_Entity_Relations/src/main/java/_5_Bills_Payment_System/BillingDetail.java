package _5_Bills_Payment_System;

import javax.persistence.*;

@Entity(name = "_5_billing_details")
public class BillingDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int number;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    private User owner;

    public BillingDetail(int number, User owner) {
        this.number = number;
        this.owner = owner;
    }

    public BillingDetail() {

    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
