package _4_Hospital_Database;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Set;

@Entity(name = "_4_patients")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "last_name", nullable = false)
    private String lastName;

    private String address;

    @Column(unique = true)
    private String email;

    @Column(name = "date_of_birth", nullable = false)
    private LocalDate dateOfBirth;

    @Lob
    private byte[] picture;

    @Column(name = "medical_insurance", nullable = false)
    private boolean medicalInsurance;

    @OneToMany(cascade = CascadeType.ALL)
    private Set<Visitation> visitations;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Diagnose> diagnoses;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Medicament> medicaments;

    public Patient(String firstName, String lastName, String address, String email,
                   LocalDate dateOfBirth, byte[] picture, boolean medicalInsurance,
                   Set<Visitation> visitations, Set<Diagnose> diagnoses, Set<Medicament> medicaments) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.picture = picture;
        this.medicalInsurance = medicalInsurance;
        this.visitations = visitations;
        this.diagnoses = diagnoses;
        this.medicaments = medicaments;
    }


    public Patient() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public byte[] getPicture() {
        return picture;
    }

    public void setPicture(byte[] picture) {
        this.picture = picture;
    }

    public boolean isMedicalInsurance() {
        return medicalInsurance;
    }

    public void setMedicalInsurance(boolean medicalInsurance) {
        this.medicalInsurance = medicalInsurance;
    }

    public Set<Visitation> getVisitations() {
        return visitations;
    }

    public void setVisitations(Set<Visitation> visitations) {
        this.visitations = visitations;
    }

    public Set<Diagnose> getDiagnoses() {
        return diagnoses;
    }

    public void setDiagnoses(Set<Diagnose> diagnoses) {
        this.diagnoses = diagnoses;
    }

    public Set<Medicament> getMedicaments() {
        return medicaments;
    }

    public void setMedicaments(Set<Medicament> medicaments) {
        this.medicaments = medicaments;
    }

    @Override
    public String toString() {
        return "Patient: " +
                "id: " + id + System.lineSeparator() +
                "firstName: " + firstName + System.lineSeparator() +
                "lastName: " + lastName + System.lineSeparator() +
                "address: " + address + System.lineSeparator() +
                "email: " + email + System.lineSeparator() +
                "dateOfBirth: " + dateOfBirth + System.lineSeparator() +
                "picture: " + Arrays.toString(picture);
    }
}
