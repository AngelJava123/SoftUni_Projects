package _4_Hospital_Database;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("hospital");
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();

        patient1(em);
        patient2(em);

        em.getTransaction().commit();
        em.close();

        /* BONUS TASK: USER INTERFACE:

        System.out.println("Enter Patient's first name:");

        String firstName = reader.readLine();

        em.createQuery("SELECT p FROM _4_patients p WHERE p.firstName = :fn", Patient.class)
                .setParameter("fn", firstName).getResultList().forEach(p -> {
                    System.out.println(p.toString());

                    System.out.println("visitations:");
                    for (Visitation visitation : p.getVisitations()) {
                        System.out.println(visitation.getDate());
                        System.out.println(visitation.getComments());
                    }

                    System.out.println("diagnoses:");
                    for (Diagnose diagnose : p.getDiagnoses()) {
                        System.out.println(diagnose.getName());
                        System.out.println(diagnose.getComments());
                    }

                    System.out.println("medicaments:");
                    for (Medicament medicament : p.getMedicaments()) {
                        System.out.println(medicament.getName());
                    }
                }); */
    }

    private static void patient1(EntityManager em) {
        Visitation visitation = new Visitation(LocalDate.of(2005, 5, 12), "checkup");
        Visitation visitation2 = new Visitation(LocalDate.of(2006, 7, 2), "blood sampling");
        Visitation visitation3 = new Visitation(LocalDate.of(2007, 9, 18), "coronavirus test");

        Set<Visitation> visitationSet = new HashSet<>();

        visitationSet.add(visitation);
        visitationSet.add(visitation2);
        visitationSet.add(visitation3);

        Diagnose diagnose = new Diagnose("pneumonia cough", "cough with phlegm or pus, fever" +
                ", chills, and difficulty breathing");
        Diagnose diagnose2 = new Diagnose("Influenza (flu)",
                "Fever, Aching muscles, Chills and sweats, Headache, Shortness of breath");

        Set<Diagnose> diagnoseSet = new HashSet<>();

        diagnoseSet.add(diagnose);
        diagnoseSet.add(diagnose2);

        Medicament medicament = new Medicament("oseltamivir phosphate");
        Medicament medicament1 = new Medicament("baloxavir marboxil");
        Medicament medicament2 = new Medicament("zanamivir");

        Set<Medicament> medicaments = new HashSet<>();

        medicaments.add(medicament);
        medicaments.add(medicament1);
        medicaments.add(medicament2);

        Patient patient = new Patient("Ana", "Zelensky",
                "1113, Sofia 1113, Blvd.Tsarigradsko shose № 85, bl. 109", "ana@abv.bg",
                LocalDate.of(1967, 1, 23),
                null, true, new HashSet<>(visitationSet), new HashSet<>(diagnoseSet),
                new HashSet<>(medicaments));

        em.persist(patient);
    }

    private static void patient2(EntityManager em) {
        Visitation visitation = new Visitation(LocalDate.of(2013, 11, 26), "HIV test");
        Visitation visitation2 = new Visitation(LocalDate.of(2015, 7, 13), "urine sampling");
        Visitation visitation3 = new Visitation(LocalDate.of(2007, 10, 20), "chronic cough test");

        Set<Visitation> visitationSet = new HashSet<>();

        visitationSet.add(visitation);
        visitationSet.add(visitation2);
        visitationSet.add(visitation3);

        Diagnose diagnose = new Diagnose("HIV positive", "virus attacks the body's immune system");
        Diagnose diagnose2 = new Diagnose("Lyme disease", "ector-borne disease caused by the Borrelia bacterium");

        Set<Diagnose> diagnoseSet = new HashSet<>();

        diagnoseSet.add(diagnose);
        diagnoseSet.add(diagnose2);

        Medicament medicament = new Medicament("Ziagen");
        Medicament medicament1 = new Medicament("Emtriva");
        Medicament medicament2 = new Medicament("Epivir");

        Set<Medicament> medicaments = new HashSet<>();

        medicaments.add(medicament);
        medicaments.add(medicament1);
        medicaments.add(medicament2);

        Patient patient = new Patient("John", "Michael",
                "1111 Sofia Str.Geo Milev № 18", "john@abv.bg", LocalDate.of(1974, 7, 20),
                null, true, new HashSet<>(visitationSet), new HashSet<>(diagnoseSet),
                new HashSet<>(medicaments));

        em.persist(patient);
    }
}
