import entities.*;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Exercise_Engine implements Runnable {
    private final EntityManager entityManager;
    private final BufferedReader bufferedReader;

    public Exercise_Engine(EntityManager entityManager) {
        this.entityManager = entityManager;
        this.bufferedReader = new BufferedReader(new InputStreamReader(System.in));
    }

    @Override
    public void run() {
        System.out.println("Enter exercise number:");

        try {
            int exNum = Integer.parseInt(bufferedReader.readLine());

            switch (exNum) {
                case 2 -> changeCasing();
                case 3 -> containsEmployee();
                case 4 -> employeesWithSalaryOver50000();
                case 5 -> employeesFromDepartment();
                case 6 -> addingANewAddressAndUpdatingEmployee();
                case 7 -> addressesWithEmployeeCount();
                case 8 -> getEmployeeWithProject();
                case 9 -> findLatest10Projects();
                case 10 -> increaseSalaries();
                case 11 -> findEmployeesByFirstName();
                case 12 -> employeesMaximumSalaries();
                case 13 -> removeTowns();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
    }

    private void changeCasing() {
        entityManager.getTransaction().begin();
        Query query = entityManager.createQuery("UPDATE Town t SET t.name = UPPER(t.name) " +
                "WHERE LENGTH(t.name) <= 5 ");

        System.out.println(query.executeUpdate());

        entityManager.getTransaction().commit();
    }

    private void containsEmployee() throws IOException {

        System.out.println("Enter the first and last name of the employee:");
        String[] input = bufferedReader.readLine().split("\\s+");
        String firstName = input[0];
        String lastName = input[1];

        Long singleResult = entityManager.createQuery("SELECT count(e) FROM Employee e " +
                        "WHERE e.firstName = :f_name AND e.lastName = :l_name", Long.class).
                setParameter("f_name", firstName).setParameter("l_name", lastName)
                .getSingleResult();

        if (singleResult != 0) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }

    private void employeesWithSalaryOver50000() {

        entityManager.createQuery("SELECT e FROM Employee e WHERE e.salary > 50000", Employee.class).
                getResultStream().forEach(e -> System.out.println(e.getFirstName()));
    }

    private void employeesFromDepartment() {

        entityManager.createQuery("SELECT e FROM Employee e " +
                        "WHERE e.department.name = 'Research and Development' " +
                        "ORDER BY e.salary, e.id", Employee.class).getResultStream()
                .forEach(employee -> System.out.printf("%s %s from Research and Development - $%s%n",
                        employee.getFirstName(), employee.getLastName(), employee.getSalary()));
    }

    private void addingANewAddressAndUpdatingEmployee() throws IOException {

        System.out.println("Enter the last name of the employee:");
        String lastNameInput = bufferedReader.readLine();

        entityManager.getTransaction().begin();

        entityManager.createNativeQuery("INSERT INTO soft_uni.addresses(address_text) VALUES ('Vitoshka 15')")
                .executeUpdate();

        entityManager.getTransaction().commit();

        Integer id = entityManager.createQuery("SELECT a.id FROM Address a WHERE " +
                " a.text = 'Vitoshka 15'", Integer.class).getSingleResult();

        entityManager.getTransaction().begin();

        entityManager.createQuery("UPDATE Employee e SET e.address.id = :id WHERE " +
                        " e.lastName = :last_name").
                setParameter("id", id).setParameter("last_name", lastNameInput)
                .executeUpdate();

        entityManager.getTransaction().commit();
    }

    private void addressesWithEmployeeCount() {

        entityManager.createQuery("SELECT a  " +
                        " FROM Address a ORDER BY a.employees.size DESC", Address.class)
                .setMaxResults(10).getResultList().forEach(a -> System.out.printf("%s, %s - %d employees%n",
                        a.getText(),
                        a.getTown() == null ? "Unknown" : a.getTown().getName(),
                        a.getEmployees().size()));
    }

    private void getEmployeeWithProject() throws IOException {

        System.out.println("Enter the id of the employee:");
        int id = Integer.parseInt(bufferedReader.readLine());

        entityManager.createQuery("SELECT e FROM Employee e " +
                        "WHERE e.id = :inputID", Employee.class)
                .setParameter("inputID", id).getResultList().
                forEach(e -> {
                    System.out.printf("%s %s - %s", e.getFirstName(), e.getLastName(), e.getJobTitle());
                    System.out.println();

                    Set<String> p = new TreeSet<>();

                    for (Project project : e.getProjects()) {
                        p.add(project.getName());
                    }
                    p.forEach(System.out::println);
                });
    }

    private void findLatest10Projects() {

        entityManager.createQuery("SELECT p FROM Project p ORDER BY p.startDate DESC", Project.class)
                .setMaxResults(10)
                .getResultList()
                .stream()
                .sorted(Comparator.comparing(Project::getName))
                .forEach(p -> {
                    System.out.println("Project name: " + p.getName());
                    System.out.println("\tProject Description: " + p.getDescription());
                    System.out.println("\tProject Start Date:" + p.getStartDate());
                    System.out.println("\tProject End Date: " + p.getEndDate());
                });
    }

    private void increaseSalaries() {

        entityManager.getTransaction().begin();

        Query query = entityManager.createQuery("UPDATE Employee e SET e.salary = e.salary * 1.12" +
                " WHERE e.department.id IN (1, 2, 4, 11)");

        query.executeUpdate();

        entityManager.getTransaction().commit();

        entityManager.createQuery("SELECT e FROM Employee e WHERE e.department.id IN (1, 2, 4, 11)", Employee.class)
                .getResultList().forEach(e -> System.out.println(e.getFirstName()
                        + " " + e.getLastName() + " (" + "$" + e.getSalary() + ")"));
    }

    private void findEmployeesByFirstName() throws IOException {

        System.out.println("Enter a pattern:");

        String pattern = bufferedReader.readLine().toLowerCase();

        entityManager.createQuery("SELECT e FROM Employee e WHERE " +
                        "e.firstName LIKE lower(:pat)", Employee.class)
                .setParameter("pat", pattern + "%")
                .getResultList().forEach(e -> System.out.println(e.getFirstName() + " " + e.getLastName() + " - " +
                        e.getJobTitle() + " - " + "(" + "$" + e.getSalary() + ")"));
    }

    private void employeesMaximumSalaries() {

        entityManager.createQuery("SELECT concat(d.name,' ', max(e.salary)) " +
                        "FROM Employee e " +
                        "JOIN Department d ON e.department.id = d.id " +
                        "GROUP BY e.department.id HAVING max(e.salary) NOT BETWEEN 30000 and 70000", String.class)
                .getResultList().forEach(System.out::println);
    }

    private void removeTowns() throws IOException {

        System.out.println("Enter a town name:");

        String townName = bufferedReader.readLine();

        Integer tnId = entityManager.createQuery("SELECT t.id FROM Town t WHERE t.name = :tn", Integer.class).
                setParameter("tn", townName).getSingleResult();

        Town town = entityManager.createQuery("SELECT t FROM Town t WHERE t.name = :name", Town.class)
                .setParameter("name", townName).getSingleResult();

        List<Address> addressList = entityManager.createQuery("SELECT a FROM Address a WHERE a.town.id = :inputId"
                        , Address.class).setParameter("inputId", tnId)
                .getResultList();

        int addressesSize = addressList.size();

        entityManager.getTransaction().begin();
        addressList.forEach(entityManager::remove);
        entityManager.getTransaction().commit();

        entityManager.getTransaction().begin();
        entityManager.remove(town);
        entityManager.getTransaction().commit();

        System.out.println(addressesSize + " addresses in " + townName + " deleted");
    }
}