package xml_processing.CarDealer.services;

import javax.xml.bind.JAXBException;

public interface SaleService {
    void findAll() throws JAXBException;
}
