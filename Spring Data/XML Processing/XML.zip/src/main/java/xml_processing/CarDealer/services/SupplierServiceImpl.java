package xml_processing.CarDealer.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xml_processing.CarDealer.dto.ExportCarsFromToyotaDto;
import xml_processing.CarDealer.dto.ExportSuppliersNotImportingFromAbroadDto;
import xml_processing.CarDealer.dto.SuppliersDataDto;
import xml_processing.CarDealer.entities.Supplier;
import xml_processing.CarDealer.repositories.SupplierRepository;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SupplierServiceImpl implements SupplierService {

    private final SupplierRepository supplierRepository;

    @Autowired
    public SupplierServiceImpl(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
    }

    @Override
    @Transactional
    public void findAllSuppliersNotImportingFromAbroad() throws JAXBException {

        List<Supplier> suppliers = this.supplierRepository.findAllSuppliersNotImporting();

        List<SuppliersDataDto> collect = suppliers.
                stream().map(s -> new SuppliersDataDto(s.getId(), s.getName(), s.getParts().size()))
                .collect(Collectors.toList());

        ExportSuppliersNotImportingFromAbroadDto wrapper = new ExportSuppliersNotImportingFromAbroadDto(collect);

        JAXBContext context = JAXBContext.newInstance(ExportSuppliersNotImportingFromAbroadDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }
}
