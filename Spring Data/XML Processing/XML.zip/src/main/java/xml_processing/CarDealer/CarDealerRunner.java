package xml_processing.CarDealer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import xml_processing.CarDealer.services.*;

@Component
public class CarDealerRunner implements CommandLineRunner {

    private final SeedCarDealerService seedCarDealerService;
    private final CustomerService customerService;
    private final CarService carService;
    private final SupplierService supplierService;
    private final SaleService saleService;

    @Autowired
    public CarDealerRunner(SeedCarDealerService seedCarDealerService, CustomerService customerService, CarService carService, SupplierService supplierService, SaleService saleService) {
        this.seedCarDealerService = seedCarDealerService;
        this.customerService = customerService;
        this.carService = carService;
        this.supplierService = supplierService;
        this.saleService = saleService;
    }

    @Override
    public void run(String... args) throws Exception {

        this.seedCarDealerService.seedAll();

        this.customerService.findAllCustomersOrdered();

        this.carService.finaAllToyotaCars();

        this.supplierService.findAllSuppliersNotImportingFromAbroad();

        this.carService.findAllCarsWithTheirParts();

        this.customerService.findSalesWithCustomers();

        this.saleService.findAll();

    }
}
