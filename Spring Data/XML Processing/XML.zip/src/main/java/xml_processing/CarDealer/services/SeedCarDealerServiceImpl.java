package xml_processing.CarDealer.services;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xml_processing.CarDealer.dto.*;
import xml_processing.CarDealer.entities.*;
import xml_processing.CarDealer.repositories.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


@Service
public class SeedCarDealerServiceImpl implements SeedCarDealerService {
    private static double discount = 0;

    private final static String SUPPLIERS_PATH = "src\\main\\resources\\file\\suppliers.xml";
    private final static String PARTS_PATH = "src\\main\\resources\\file\\parts.xml";
    private final static String CARS_PATH = "src\\main\\resources\\file\\cars.xml";
    private final static String CUSTOMERS_PATH = "src\\main\\resources\\file\\customers.xml";

    private final ModelMapper modelMapper;
    private final SupplierRepository supplierRepository;
    private final PartRepository partRepository;
    private final CarRepository carRepository;
    private final CustomerRepository customerRepository;
    private final SaleRepository saleRepository;

    @Autowired
    public SeedCarDealerServiceImpl(SupplierRepository supplierRepository, PartRepository partRepository,
                                    CarRepository carRepository, CustomerRepository customerRepository,
                                    SaleRepository saleRepository) {
        this.supplierRepository = supplierRepository;
        this.partRepository = partRepository;
        this.carRepository = carRepository;
        this.customerRepository = customerRepository;
        this.saleRepository = saleRepository;
        this.modelMapper = new ModelMapper();
    }

    @Override
    public void seedSuppliers() throws FileNotFoundException, JAXBException {
        FileReader fileReader = new FileReader(SUPPLIERS_PATH);

        JAXBContext context = JAXBContext.newInstance(ImportSuppliersDto.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        ImportSuppliersDto ImportSuppliersDto = (ImportSuppliersDto) unmarshaller.unmarshal(fileReader);

        for (ImportSupplierNameAndBoolean model : ImportSuppliersDto.getSuppliers()) {
            Supplier supplier = modelMapper.map(model, Supplier.class);
            supplierRepository.save(supplier);
        }
    }

    @Override
    public void seedParts() throws FileNotFoundException, JAXBException {

        FileReader partFile = new FileReader(PARTS_PATH);

        JAXBContext context = JAXBContext.newInstance(ImportPartsDto.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        ImportPartsDto ImportPartsDto = (ImportPartsDto) unmarshaller.unmarshal(partFile);

        List<Part> collect = (ImportPartsDto).getParts().stream()
                .map(p -> this.modelMapper.map(p, Part.class))
                .map(this::setRandomSupplier)
                .collect(Collectors.toList());

        this.partRepository.saveAll(collect);
    }

    @Override
    public void seedCars() throws FileNotFoundException, JAXBException {

        FileReader fileReader = new FileReader(CARS_PATH);

        JAXBContext context = JAXBContext.newInstance(ImportCarsDto.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        ImportCarsDto ImportCarsDto = (ImportCarsDto) unmarshaller.unmarshal(fileReader);

        List<Car> carList = (ImportCarsDto).getCars().stream()
                .map(c -> this.modelMapper.map(c, Car.class))
                .map(this::addPart)
                .collect(Collectors.toList());

        this.carRepository.saveAll(carList);
    }

    @Override
    public void seedCustomers() throws FileNotFoundException, JAXBException {

        FileReader fileReader = new FileReader(CUSTOMERS_PATH);

        JAXBContext context = JAXBContext.newInstance(ImportCustomersDto.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        ImportCustomersDto importCustomersDto = (ImportCustomersDto) unmarshaller.unmarshal(fileReader);

        List<Customer> customerList = (importCustomersDto).getCustomers().stream()
                .map(c -> this.modelMapper.map(c, Customer.class))
                .collect(Collectors.toList());

        this.customerRepository.saveAll(customerList);
    }

    @Override
    public void seedSales() throws FileNotFoundException {

        final List<Car> cars = this.carRepository.findAll();

        List<Sale> sales = new LinkedList<>();

        for (Car car : cars) {
            Sale sale = new Sale();
            sale.setDiscount(getRandomDiscount());
            sale.setCar(car);
            sale.setCustomer(getRandomCustomer());
            sales.add(sale);
            if (discount == 0.05) {
                sale.setDiscount(sale.getDiscount() + discount);
            }
            discount = 0;
        }

        this.saleRepository.saveAll(sales);
    }

    private Customer getRandomCustomer() {

        long customerCount = this.customerRepository.count();

        int randomCustomerId = new Random().nextInt((int) customerCount) + 1;

        Optional<Customer> customer = this.customerRepository.findById((long) randomCustomerId);

        if (customer.get().isYoungDriver()) {
            discount += 0.05;
        }
        return customer.get();
    }

    private Double getRandomDiscount() {

        List<Double> discounts = Arrays.asList(0d, 0.05d, 0.1d, 0.15d, 0.2d, 0.3d, 0.4d, 0.5d);

        Random random = new Random();

        int index = random.nextInt(discounts.size());

        return discounts.get(index);
    }


    private Part setRandomSupplier(Part part) {

        Optional<Supplier> supplier = getRandomSupplier();

        part.setSupplier(supplier.get());

        return part;
    }

    private Optional<Supplier> getRandomSupplier() {
        long suppliersCount = this.supplierRepository.count(); // 1..5

        // 0..4
        int randomSupplierId = new Random().nextInt((int) suppliersCount) + 1;

        Optional<Supplier> supplier = this.supplierRepository.findById((long) randomSupplierId);
        return supplier;
    }

    private Car addPart(Car car) {

        IntStream.range(0, 5)
                .mapToObj(i -> getRandomPart())
                .forEach(part -> car.getParts().add(part.get()));

        return car;
    }

    private Optional<Part> getRandomPart() {

        long partCount = this.partRepository.count(); // 1..5

        // 0..4
        int randomPartId = new Random().nextInt((int) partCount) + 1;

        Optional<Part> part = this.partRepository.findById((long) randomPartId);
        return part;

    }
}
