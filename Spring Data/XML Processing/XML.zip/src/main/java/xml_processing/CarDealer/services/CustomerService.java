package xml_processing.CarDealer.services;

import javax.xml.bind.JAXBException;

public interface CustomerService {

    void findAllCustomersOrdered() throws JAXBException;

    void findSalesWithCustomers() throws JAXBException;
}
