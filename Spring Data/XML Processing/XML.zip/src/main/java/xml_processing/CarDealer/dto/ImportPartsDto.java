package xml_processing.CarDealer.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "parts")
@XmlAccessorType(XmlAccessType.FIELD)
public class ImportPartsDto {

    @XmlElement(name = "part")
    private List<ImportPartsNamePriceQuantity> parts;

    public ImportPartsDto() {
    }

    public List<ImportPartsNamePriceQuantity> getParts() {
        return parts;
    }

    public void setParts(List<ImportPartsNamePriceQuantity> parts) {
        this.parts = parts;
    }
}
