package xml_processing.CarDealer.entities;

import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cars")
@Getter
@Setter
@ToString
@RequiredArgsConstructor
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String make;
    private String model;
    private long travelledDistance;

    @ManyToMany
    @ToString.Exclude
    private List<Part> parts = new ArrayList<>();
}
