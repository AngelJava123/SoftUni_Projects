package xml_processing.CarDealer.services;

import org.springframework.stereotype.Service;
import xml_processing.CarDealer.dto.CustomerData;
import xml_processing.CarDealer.dto.ExportAllCustomersDto;
import xml_processing.CarDealer.dto.ExportCustomersWithSalesDto;
import xml_processing.CarDealer.dto.ageNameBirthDto;
import xml_processing.CarDealer.entities.Customer;
import xml_processing.CarDealer.repositories.CustomerRepository;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public void findAllCustomersOrdered() throws JAXBException {

        List<Customer> customers = this.customerRepository.findAll();

        List<ageNameBirthDto> collect = customers.
                stream().
                map(c -> new ageNameBirthDto(c.getId(), c.getName(), c.getBirthDate(), c.isYoungDriver()))
                .sorted(Comparator.comparing(ageNameBirthDto::getBirthDate).
                        thenComparing(ageNameBirthDto::isYoungDriver, Comparator.reverseOrder()))
                .collect(Collectors.toList());

        ExportAllCustomersDto wrapper = new ExportAllCustomersDto(collect);

        JAXBContext context = JAXBContext.newInstance(ExportAllCustomersDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }

    @Override
    @Transactional
    public void findSalesWithCustomers() throws JAXBException {

        List<Customer> customers = this.customerRepository.findAllCustomersWithSales();

        List<CustomerData> collect = customers.stream().map(c ->
                        new CustomerData(c.getName(), c.getSales().size(),
                                c.getSales().
                                        stream().
                                        mapToDouble(p -> p.getCar().
                                                getParts().stream().mapToDouble(cp -> cp.getPrice().
                                                        doubleValue()).sum() * p.getDiscount()).sum()))
                .sorted(Comparator.comparing(CustomerData::getSpentMoney, Comparator.reverseOrder()).
                        thenComparing(CustomerData::getBoughtCars, Comparator.reverseOrder())).
                collect(Collectors.toList());

        ExportCustomersWithSalesDto wrapper = new ExportCustomersWithSalesDto(collect);

        JAXBContext context = JAXBContext.newInstance(ExportCustomersWithSalesDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }
}
