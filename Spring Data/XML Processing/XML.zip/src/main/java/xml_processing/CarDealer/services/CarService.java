package xml_processing.CarDealer.services;

import javax.xml.bind.JAXBException;

public interface CarService {
    void finaAllToyotaCars() throws JAXBException;

    void findAllCarsWithTheirParts() throws JAXBException;
}
