package xml_processing.CarDealer.dto;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "cars")
@XmlAccessorType(XmlAccessType.FIELD)
public class ExportCarsWithPartsDto {

    @XmlElement(name = "car")
    private List<CarDataDto> cars;

    public ExportCarsWithPartsDto(List<CarDataDto> cars) {
        this.cars = cars;
    }

    public ExportCarsWithPartsDto() {
    }

    public List<CarDataDto> getCars() {
        return cars;
    }

    public void setCars(List<CarDataDto> cars) {
        this.cars = cars;
    }
}
