package xml_processing.CarDealer.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "suppliers")
@XmlAccessorType(XmlAccessType.FIELD)
public class ImportSuppliersDto {

    @XmlElement(name = "supplier")
    private List<ImportSupplierNameAndBoolean> suppliers;

    public ImportSuppliersDto() {
    }

    public ImportSuppliersDto(List<ImportSupplierNameAndBoolean> suppliers) {
        this.suppliers = suppliers;
    }

    public List<ImportSupplierNameAndBoolean> getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(List<ImportSupplierNameAndBoolean> suppliers) {
        this.suppliers = suppliers;
    }


}
