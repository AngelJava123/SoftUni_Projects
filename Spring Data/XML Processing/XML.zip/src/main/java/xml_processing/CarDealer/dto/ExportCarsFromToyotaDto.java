package xml_processing.CarDealer.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "cars")
@XmlAccessorType(XmlAccessType.FIELD)
public class ExportCarsFromToyotaDto {

    @XmlElement(name = "car")
    private List<ToyotaCarsDto> cars;

    public ExportCarsFromToyotaDto(List<ToyotaCarsDto> cars) {
        this.cars = cars;
    }

    public ExportCarsFromToyotaDto() {
    }

    public List<ToyotaCarsDto> getCars() {
        return cars;
    }

    public void setCars(List<ToyotaCarsDto> cars) {
        this.cars = cars;
    }
}
