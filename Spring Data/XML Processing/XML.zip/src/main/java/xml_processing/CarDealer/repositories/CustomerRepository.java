package xml_processing.CarDealer.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import xml_processing.CarDealer.entities.Customer;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    @Query("SELECT c FROM Customer as c WHERE SIZE(c.sales) > 0")
    List<Customer> findAllCustomersWithSales();
}
