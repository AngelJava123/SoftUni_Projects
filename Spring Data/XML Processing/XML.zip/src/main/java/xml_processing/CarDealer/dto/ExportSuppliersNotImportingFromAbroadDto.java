package xml_processing.CarDealer.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "suppliers")
@XmlAccessorType(XmlAccessType.FIELD)
public class ExportSuppliersNotImportingFromAbroadDto {

    @XmlElement(name = "supplier")
    private List<SuppliersDataDto> suppliers;

    public ExportSuppliersNotImportingFromAbroadDto(List<SuppliersDataDto> suppliers) {
        this.suppliers = suppliers;
    }

    public ExportSuppliersNotImportingFromAbroadDto() {
    }

    public List<SuppliersDataDto> getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(List<SuppliersDataDto> suppliers) {
        this.suppliers = suppliers;
    }
}
