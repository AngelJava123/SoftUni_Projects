package xml_processing.CarDealer.entities;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "sales")
@Getter
@Setter
@ToString
@RequiredArgsConstructor
public class Sale {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double discount;

    @OneToOne
    private Car car;

    @ManyToOne
    private Customer customer;
}
