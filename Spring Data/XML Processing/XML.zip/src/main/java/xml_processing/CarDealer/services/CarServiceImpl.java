package xml_processing.CarDealer.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xml_processing.CarDealer.dto.*;
import xml_processing.CarDealer.entities.Car;
import xml_processing.CarDealer.repositories.CarRepository;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public CarServiceImpl(CarRepository carRepository) {
        this.carRepository = carRepository;
        this.modelMapper = new ModelMapper();
    }

    @Override
    public void finaAllToyotaCars() throws JAXBException {

        List<Car> cars = this.carRepository.findAllCarsByMakeOrderByModelAscTravelledDistanceDesc("Toyota");

        List<ToyotaCarsDto> carExportDtos = cars
                .stream()
                .map(car -> new ToyotaCarsDto(car.getId(), car.getModel(), car.getMake(), car.getTravelledDistance()))
                .collect(Collectors.toList());

        ExportCarsFromToyotaDto wrapper = new ExportCarsFromToyotaDto(carExportDtos);

        JAXBContext context = JAXBContext.newInstance(ExportCarsFromToyotaDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }

    @Override
    @Transactional
    public void findAllCarsWithTheirParts() throws JAXBException {

        List<Car> cars = this.carRepository.findAll();

        List<CarDataDto> collect = cars.stream()
                .map(c -> new CarDataDto(c.getMake(), c.getModel(), c.getTravelledDistance(),
                        c.getParts().stream().map(p -> new PartsDto(p.getName(), p.getPrice())).
                                collect(Collectors.toList()))).collect(Collectors.toList());

        ExportCarsWithPartsDto wrapper = new ExportCarsWithPartsDto(collect);

        JAXBContext context = JAXBContext.newInstance(ExportCarsWithPartsDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }
}
