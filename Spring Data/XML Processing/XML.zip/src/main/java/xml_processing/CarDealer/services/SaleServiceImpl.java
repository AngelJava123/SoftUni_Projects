package xml_processing.CarDealer.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xml_processing.CarDealer.dto.CarData;
import xml_processing.CarDealer.dto.ExportSalesDto;
import xml_processing.CarDealer.dto.SalesData;
import xml_processing.CarDealer.entities.Sale;
import xml_processing.CarDealer.repositories.SaleRepository;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class SaleServiceImpl implements SaleService {

    private final SaleRepository saleRepository;

    @Autowired
    public SaleServiceImpl(SaleRepository saleRepository) {
        this.saleRepository = saleRepository;
    }

    @Override
    @Transactional
    public void findAll() throws JAXBException {

        List<Sale> sales = saleRepository.findAll();

        List<SalesData> data = sales
                .stream()
                .map(s -> new SalesData(
                        new CarData(
                                s.getCar().getMake(),
                                s.getCar().getModel(),
                                s.getCar().getTravelledDistance()),
                        s.getCustomer().getName(),
                        s.getDiscount(),
                        s.getCar().getParts().stream().mapToDouble(c -> c.getPrice().doubleValue()).sum()))
                .collect(Collectors.toList());

        ExportSalesDto wrapper = new ExportSalesDto(data);

        JAXBContext context = JAXBContext.newInstance(ExportSalesDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }
}
