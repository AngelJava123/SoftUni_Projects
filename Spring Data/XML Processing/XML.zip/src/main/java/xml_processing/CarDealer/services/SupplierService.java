package xml_processing.CarDealer.services;

import org.springframework.data.jpa.repository.Query;
import xml_processing.CarDealer.entities.Supplier;

import javax.xml.bind.JAXBException;
import java.util.List;

public interface SupplierService {

    void findAllSuppliersNotImportingFromAbroad() throws JAXBException;
}
