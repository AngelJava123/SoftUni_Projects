package xml_processing.ProductsShop.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xml_processing.ProductsShop.dto.*;
import xml_processing.ProductsShop.entities.User;
import xml_processing.ProductsShop.repositories.UserRepository;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void findAllWithSoldProducts() throws JAXBException {

        List<User> users = this.userRepository.findAllWithSoldProducts();

        List<UserWithNamesAndProductsDto> usersWithProducts =
                users.stream().map(u -> new UserWithNamesAndProductsDto(
                                u.getFirstName(),
                                u.getLastName(),
                                u.getSellingItems().stream().filter(p -> p.getBuyer() != null)
                                        .map(p -> new SoldProductsDto(
                                                p.getName(), p.getPrice(), p.getBuyer().getFirstName(),
                                                p.getBuyer().getLastName())).collect(Collectors.toList()))).
                        collect(Collectors.toList());

        UserWithSoldProductsDto wrapper = new UserWithSoldProductsDto(usersWithProducts);

        JAXBContext context = JAXBContext.newInstance(UserWithSoldProductsDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }

    @Override
    public void findAllUsersOrderedByNumberOfProducts() throws JAXBException {

        List<User> users = this.userRepository.findAllUsersOrderedByNumberOfProducts();

        Q4MostOuterUsersAndProductsDto wrapper = new Q4MostOuterUsersAndProductsDto(users.size(), users.
                stream().map(u -> new Q4NameAgeDto
                        (u.getFirstName(), u.getLastName(), u.getAge(), new Q4SoldProductsDto(
                                (int) u.getSellingItems().stream().filter(x -> x.getBuyer() != null).count(),
                                u.getSellingItems().stream()
                                        .filter(x -> x.getBuyer() != null)
                                        .map(p -> new Q4ProductNamePriceDto(p.getName(), p.getPrice()))
                                        .collect(Collectors.toList()))))
                .sorted(Comparator.comparing((Q4NameAgeDto x) -> -x.getSoldProducts().getProducts().size())
                        .thenComparing(Q4NameAgeDto::getLastName)) //this is sorted from query anyway
                .collect(Collectors.toList()));

        JAXBContext context = JAXBContext.newInstance(Q4MostOuterUsersAndProductsDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);

    }
}
