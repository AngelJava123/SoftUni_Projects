package xml_processing.ProductsShop.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;

@XmlRootElement(name = "product")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductNamePriceSellerDto {

    @XmlAttribute(name = "name")
    private String productName;

    @XmlAttribute(name = "price")
    private BigDecimal productPrice;

    @XmlAttribute(name = "seller")
    private String sellerName;

    public ProductNamePriceSellerDto() {
    }

    public ProductNamePriceSellerDto(String productName, BigDecimal productPrice, String sellerName) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.sellerName = sellerName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(BigDecimal productPrice) {
        this.productPrice = productPrice;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }
}
