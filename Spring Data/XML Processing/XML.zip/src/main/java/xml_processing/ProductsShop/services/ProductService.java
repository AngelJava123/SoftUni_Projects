package xml_processing.ProductsShop.services;

import javax.xml.bind.JAXBException;
import javax.xml.bind.PropertyException;

public interface ProductService {
    void getAllProductsInPriceRange() throws JAXBException;

}
