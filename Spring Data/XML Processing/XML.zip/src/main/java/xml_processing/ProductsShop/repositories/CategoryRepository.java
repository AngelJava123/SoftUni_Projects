package xml_processing.ProductsShop.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import xml_processing.ProductsShop.entities.Category;

import java.util.List;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {

    @Query("SELECT c.name, SIZE(c.products), AVG(p.price), SUM(p.price) " +
            "FROM Category c JOIN c.products p ORDER BY SIZE(c.products)")
    List<Category> findAllCategories();
}
