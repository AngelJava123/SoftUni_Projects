package xml_processing.ProductsShop.dto;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "sold-products")
@XmlAccessorType(XmlAccessType.FIELD)
public class Q4SoldProductsDto {

    @XmlAttribute(name = "count")
    private int count;

    @XmlElement(name = "product")
    private List<Q4ProductNamePriceDto> products;

    public Q4SoldProductsDto(int count, List<Q4ProductNamePriceDto> products) {
        this.count = count;
        this.products = products;
    }

    public Q4SoldProductsDto() {
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<Q4ProductNamePriceDto> getProducts() {
        return products;
    }

    public void setProducts(List<Q4ProductNamePriceDto> products) {
        this.products = products;
    }
}
