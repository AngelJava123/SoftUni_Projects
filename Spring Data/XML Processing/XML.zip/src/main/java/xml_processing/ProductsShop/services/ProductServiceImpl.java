package xml_processing.ProductsShop.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xml_processing.ProductsShop.dto.CategoriesOrderedByCountDto;
import xml_processing.ProductsShop.dto.CategoryProductsDto;
import xml_processing.ProductsShop.dto.ProductNamePriceSellerDto;
import xml_processing.ProductsShop.dto.ProductsInRangeDto;
import xml_processing.ProductsShop.entities.Product;
import xml_processing.ProductsShop.repositories.ProductRepository;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
        this.modelMapper = new ModelMapper();
    }

    @Override
    public void getAllProductsInPriceRange() throws JAXBException {

        List<Product> productList = this.productRepository.
                findAllByPriceGreaterThanAndPriceLessThanAndBuyerIsNullOrderByPriceAsc
                        (BigDecimal.valueOf(500), BigDecimal.valueOf(1000));

        List<ProductNamePriceSellerDto> dto = productList.
                stream().
                map(p -> new ProductNamePriceSellerDto(
                        p.getName(),
                        p.getPrice(),
                        p.getSeller().getFullName()
                )).collect(Collectors.toList());

        ProductsInRangeDto wrapper = new ProductsInRangeDto(dto);

        JAXBContext context = JAXBContext.newInstance(ProductsInRangeDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }
}
