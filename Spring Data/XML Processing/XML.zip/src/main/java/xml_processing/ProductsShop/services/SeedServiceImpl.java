package xml_processing.ProductsShop.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xml_processing.ProductsShop.dto.*;
import xml_processing.ProductsShop.entities.Category;
import xml_processing.ProductsShop.entities.Product;
import xml_processing.ProductsShop.entities.User;
import xml_processing.ProductsShop.repositories.CategoryRepository;
import xml_processing.ProductsShop.repositories.ProductRepository;
import xml_processing.ProductsShop.repositories.UserRepository;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SeedServiceImpl implements SeedService {

    private static final String USERS_PATH = "src\\main\\resources\\File\\users.xml";
    private static final String PRODUCTS_PATH = "src\\main\\resources\\File\\products.xml";
    private static final String CATEGORIES_PATH = "src\\main\\resources\\File\\categories.xml";

    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public SeedServiceImpl(UserRepository userRepository, CategoryRepository categoryRepository,
                           ProductRepository productRepository) {
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
        this.modelMapper = new ModelMapper();
    }

    @Override
    public void seedUsers() throws FileNotFoundException, JAXBException {

        FileReader userPath = new FileReader(USERS_PATH);

        JAXBContext context = JAXBContext.newInstance(ImportUsersDto.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        ImportUsersDto importUsersDto = (ImportUsersDto) unmarshaller.unmarshal(userPath);

        for (UserDto model : importUsersDto.getUser()) {
            User user = modelMapper.map(model, User.class);
            userRepository.save(user);
        }
    }

    @Override
    public void seedCategories() throws FileNotFoundException, JAXBException {

        FileReader categoryPath = new FileReader(CATEGORIES_PATH);

        JAXBContext context = JAXBContext.newInstance(ImportCategoriesDto.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        ImportCategoriesDto importCategoriesDto = (ImportCategoriesDto) unmarshaller.unmarshal(categoryPath);

        importCategoriesDto.getName().stream().
                map(model -> modelMapper.map(model, Category.class)).
                forEachOrdered(this.categoryRepository::save);
    }

    @Override
    public void seedProducts() throws FileNotFoundException, JAXBException {

        FileReader categoryPath = new FileReader(PRODUCTS_PATH);

        JAXBContext context = JAXBContext.newInstance(ImportProductsDto.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        ImportProductsDto importProductsDto = (ImportProductsDto) unmarshaller.unmarshal(categoryPath);

        List<Product> productList = (importProductsDto).getProducts().stream()
                .map(product -> this.modelMapper.map(product, Product.class))
                .map(this::setRandomSeller)
                .map(this::setRandomBuyer)
                .map(this::setRandomCategories)
                .collect(Collectors.toList());

        this.productRepository.saveAll(productList);
    }

    private Product setRandomCategories(Product product) {
        Random random = new Random();
        long categoriesDbCount = this.categoryRepository.count();

        int count = random.nextInt((int) categoriesDbCount);

        Set<Category> categories = new HashSet<>();
        for (int i = 0; i < count; i++) {
            int randomId = random.nextInt((int) categoriesDbCount) + 1;

            Optional<Category> randomCategory = this.categoryRepository.findById((long) randomId);

            categories.add(randomCategory.get());
        }

        product.setCategories(categories);
        return product;
    }

    private Product setRandomBuyer(Product product) {
        if (product.getPrice().compareTo(BigDecimal.valueOf(944)) > 0) {
            return product;
        }

        Optional<User> buyer = getRandomUser();

        product.setBuyer(buyer.get());

        return product;
    }

    private Product setRandomSeller(Product product) {

        Optional<User> seller = getRandomUser();

        product.setSeller(seller.get());

        return product;
    }

    private Optional<User> getRandomUser() {
        long usersCount = this.userRepository.count(); // 1..5

        // 0..4
        int randomUserId = new Random().nextInt((int) usersCount) + 1;

        Optional<User> seller = this.userRepository.findById((long) randomUserId);
        return seller;
    }

}
