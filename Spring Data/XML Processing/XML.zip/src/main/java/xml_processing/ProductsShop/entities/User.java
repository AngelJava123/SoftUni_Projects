package xml_processing.ProductsShop.entities;

import lombok.*;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "users")
@Getter
@Setter
@ToString
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    private Integer age;

    @ManyToMany(fetch = FetchType.EAGER)
    @ToString.Exclude
    private Set<User> friend;

    @OneToMany(targetEntity = Product.class, mappedBy = "seller", fetch = FetchType.EAGER)
    @ToString.Exclude
    private List<Product> sellingItems;

    @OneToMany(targetEntity = Product.class, mappedBy = "buyer", fetch = FetchType.EAGER)
    @ToString.Exclude
    private List<Product> itemsBought;

    public User() {
        this.friend = new HashSet<>();
        this.sellingItems = new ArrayList<>();
        this.itemsBought = new ArrayList<>();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User user)) return false;
        return id == user.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public String getFullName() {
        if (this.getFirstName() == null) {
            return this.lastName;
        }
        return this.firstName + " " + this.lastName;
    }
}
