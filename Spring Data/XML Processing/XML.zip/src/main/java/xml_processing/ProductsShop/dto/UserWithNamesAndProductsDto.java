package xml_processing.ProductsShop.dto;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "user")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserWithNamesAndProductsDto {

    @XmlAttribute(name = "first-name")
    private String firstName;

    @XmlAttribute(name = "last-name")
    private String lastName;

    @XmlElementWrapper(name = "sold-products")
    @XmlElement(name = "product")
    private List<SoldProductsDto> products;

    public UserWithNamesAndProductsDto(String firstName, String lastName, List<SoldProductsDto> products) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.products = products;
    }

    public UserWithNamesAndProductsDto() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<SoldProductsDto> getProducts() {
        return products;
    }

    public void setProducts(List<SoldProductsDto> products) {
        this.products = products;
    }
}
