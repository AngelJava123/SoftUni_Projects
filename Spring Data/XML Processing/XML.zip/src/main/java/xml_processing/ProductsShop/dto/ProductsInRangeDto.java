package xml_processing.ProductsShop.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "products")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductsInRangeDto {

    @XmlElement(name = "product")
    private List<ProductNamePriceSellerDto> products;

    public ProductsInRangeDto() {
    }

    public ProductsInRangeDto(List<ProductNamePriceSellerDto> products) {
        this.products = products;
    }

    public List<ProductNamePriceSellerDto> getProduct() {
        return products;
    }

    public void setProduct(List<ProductNamePriceSellerDto> product) {
        this.products = product;
    }
}
