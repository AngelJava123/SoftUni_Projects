package xml_processing.ProductsShop.dto;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class Q4MostOuterUsersAndProductsDto {

    @XmlAttribute(name = "count")
    private int count;

    @XmlElement(name = "user")
    private List<Q4NameAgeDto> users;

    public Q4MostOuterUsersAndProductsDto(int count, List<Q4NameAgeDto> users) {
        this.count = count;
        this.users = users;
    }

    public Q4MostOuterUsersAndProductsDto() {
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<Q4NameAgeDto> getUsers() {
        return users;
    }

    public void setUsers(List<Q4NameAgeDto> users) {
        this.users = users;
    }
}
