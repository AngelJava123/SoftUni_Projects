package xml_processing.ProductsShop.services;

import javax.xml.bind.JAXBException;

public interface CategoryService {

    void findAllCategories() throws JAXBException;
}
