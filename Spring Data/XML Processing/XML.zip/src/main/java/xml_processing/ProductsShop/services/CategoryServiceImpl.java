package xml_processing.ProductsShop.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xml_processing.ProductsShop.dto.CategoriesOrderedByCountDto;
import xml_processing.ProductsShop.dto.CategoryProductsDto;
import xml_processing.ProductsShop.repositories.CategoryRepository;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;

    @Autowired
    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    @Transactional
    public void findAllCategories() throws JAXBException {

        List<CategoryProductsDto> categories = categoryRepository.findAll()
                .stream()
                .map(c -> new CategoryProductsDto(c.getName(), c.getProducts().size(),
                        c.getProducts().size() == 0 ? 0 : //check for no products case because of average()
                                c.getProducts().stream()
                                        .mapToDouble(p -> p.getPrice().doubleValue()).average().getAsDouble(),
                        c.getProducts().stream().mapToDouble(p -> p.getPrice().doubleValue()).sum()))
                .sorted(Comparator.comparingInt(x -> -x.getProductsCount()))
                .collect(Collectors.toList());

        CategoriesOrderedByCountDto wrapper = new CategoriesOrderedByCountDto(categories);

        JAXBContext context = JAXBContext.newInstance(CategoriesOrderedByCountDto.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, System.out);
    }
}
