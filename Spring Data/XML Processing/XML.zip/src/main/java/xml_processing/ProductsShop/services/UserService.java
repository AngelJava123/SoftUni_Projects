package xml_processing.ProductsShop.services;

import javax.xml.bind.JAXBException;

public interface UserService {
    void findAllWithSoldProducts() throws JAXBException;

    void findAllUsersOrderedByNumberOfProducts() throws JAXBException;
}
