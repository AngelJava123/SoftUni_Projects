package project.json.entity;

public enum Role {
    USER, ADMIN
}
