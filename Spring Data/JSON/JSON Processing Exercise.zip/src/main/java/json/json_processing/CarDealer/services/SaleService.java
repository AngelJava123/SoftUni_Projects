package json.json_processing.CarDealer.services;

public interface SaleService {
    void findAllSalesWithDiscount();
}
