package json.json_processing.CarDealer.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.json_processing.CarDealer.dto.ImportCarsDto;
import json.json_processing.CarDealer.dto.ImportCustomerDto;
import json.json_processing.CarDealer.dto.ImportPartsDto;
import json.json_processing.CarDealer.dto.ImportSuppliersDto;
import json.json_processing.CarDealer.entities.*;
import json.json_processing.CarDealer.repositories.*;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class SeedCarDealerServiceImpl implements SeedCarDealerService {
    private static double discount = 0;

    private final static String SUPPLIERS_PATH = "src\\main\\resources\\files\\suppliers.json";
    private final static String PARTS_PATH = "src\\main\\resources\\files\\parts.json";
    private final static String CARS_PATH = "src\\main\\resources\\files\\cars.json";
    private final static String CUSTOMERS_PATH = "src\\main\\resources\\files\\customers.json";

    private final Gson gson;
    private final ModelMapper modelMapper;
    private final SupplierRepository supplierRepository;
    private final PartRepository partRepository;
    private final CarRepository carRepository;
    private final CustomerRepository customerRepository;
    private final SaleRepository saleRepository;

    @Autowired
    public SeedCarDealerServiceImpl(SupplierRepository supplierRepository, PartRepository partRepository,
                                    CarRepository carRepository, CustomerRepository customerRepository,
                                    SaleRepository saleRepository) {
        this.supplierRepository = supplierRepository;
        this.partRepository = partRepository;
        this.carRepository = carRepository;
        this.customerRepository = customerRepository;
        this.saleRepository = saleRepository;
        this.gson = new GsonBuilder().setPrettyPrinting().setDateFormat("yyyy-MM-dd'T'hh:mm:ss").create();
        this.modelMapper = new ModelMapper();
    }

    @Override
    public void seedSuppliers() throws FileNotFoundException {
        FileReader fileReader = new FileReader(SUPPLIERS_PATH);
        ImportSuppliersDto[] suppliers = gson.fromJson(fileReader, ImportSuppliersDto[].class);

        List<Supplier> supplierList = Arrays
                .stream(suppliers)
                .map(s -> this.modelMapper.map(s, Supplier.class))
                .collect(Collectors.toList());

        this.supplierRepository.saveAll(supplierList);
    }

    @Override
    public void seedParts() throws FileNotFoundException {

        FileReader partFile = new FileReader(PARTS_PATH);
        ImportPartsDto[] parts = gson.fromJson(partFile, ImportPartsDto[].class);

        List<Part> partList = Arrays
                .stream(parts)
                .map(p -> this.modelMapper.map(p, Part.class))
                .map(this::setRandomSupplier)
                .collect(Collectors.toList());

        this.partRepository.saveAll(partList);

    }

    @Override
    public void seedCars() throws FileNotFoundException {

        FileReader fileReader = new FileReader(CARS_PATH);
        ImportCarsDto[] cars = gson.fromJson(fileReader, ImportCarsDto[].class);

        List<Car> carList = Arrays
                .stream(cars)
                .map(c -> this.modelMapper.map(c, Car.class))
                .map(this::addPart)
                .collect(Collectors.toList());

        this.carRepository.saveAll(carList);

    }

    @Override
    public void seedCustomers() throws FileNotFoundException {

        FileReader fileReader = new FileReader(CUSTOMERS_PATH);
        ImportCustomerDto[] customers = gson.fromJson(fileReader, ImportCustomerDto[].class);

        List<Customer> customerList = Arrays.stream(customers)
                .map(c -> this.modelMapper.map(c, Customer.class))
                .collect(Collectors.toList());



        this.customerRepository.saveAll(customerList);
    }

    @Override
    public void seedSales() throws FileNotFoundException {

        final List<Car> cars = this.carRepository.findAll();

        List<Sale> sales = new LinkedList<>();

        for (Car car : cars) {
            Sale sale = new Sale();
            sale.setDiscount(getRandomDiscount());
            sale.setCar(car);
            sale.setCustomer(getRandomCustomer());
            sales.add(sale);
            if (discount == 0.05) {
                sale.setDiscount(sale.getDiscount() + discount);
            }
            discount = 0;
        }

        this.saleRepository.saveAll(sales);
    }

    private Customer getRandomCustomer() {

        long customerCount = this.customerRepository.count();

        int randomCustomerId = new Random().nextInt((int) customerCount) + 1;

        Optional<Customer> customer = this.customerRepository.findById((long) randomCustomerId);

        if (customer.get().isYoungDriver()) {
            discount += 0.05;
        }
        return customer.get();
    }

    private Double getRandomDiscount() {

        List<Double> discounts = Arrays.asList(0d, 0.05d, 0.1d, 0.15d, 0.2d, 0.3d, 0.4d, 0.5d);

        Random random = new Random();

        int index = random.nextInt(discounts.size());

        return discounts.get(index);
    }


    private Part setRandomSupplier(Part part) {

        Optional<Supplier> supplier = getRandomSupplier();

        part.setSupplier(supplier.get());

        return part;
    }

    private Optional<Supplier> getRandomSupplier() {
        long suppliersCount = this.supplierRepository.count(); // 1..5

        // 0..4
        int randomSupplierId = new Random().nextInt((int) suppliersCount) + 1;

        Optional<Supplier> supplier = this.supplierRepository.findById((long) randomSupplierId);
        return supplier;
    }

    private Car addPart(Car car) {

        IntStream.range(0, 5)
                .mapToObj(i -> getRandomPart())
                .forEach(part -> car.getParts().add(part.get()));

        return car;
    }

    private Optional<Part> getRandomPart() {

        long partCount = this.partRepository.count(); // 1..5

        // 0..4
        int randomPartId = new Random().nextInt((int) partCount) + 1;

        Optional<Part> part = this.partRepository.findById((long) randomPartId);
        return part;

    }
}
