package json.json_processing.ProductsShop.services;

public interface UserService {
    void findProductWithBuyer();

    void findByUserOrderByCount();
}
