package json.json_processing.ProductsShop.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.json_processing.ProductsShop.dto.*;
import json.json_processing.ProductsShop.entities.User;
import json.json_processing.ProductsShop.entities.UsersWithSoldProducts;
import json.json_processing.ProductsShop.repositories.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final Gson gson;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
        this.modelMapper = new ModelMapper();
    }

    @Override
    @Transactional
    public void findProductWithBuyer() {

        Set<User> userList = this.userRepository.findProductWithBuyer();

        List<UsersWithSoldProducts> usersWithSoldProductsStream =
                userList.stream().map(user -> modelMapper.map
                        (user, UsersWithSoldProducts.class)).collect(Collectors.toList());

        System.out.println(this.gson.toJson(usersWithSoldProductsStream));
    }

    @Override
    public void findByUserOrderByCount() {

        final List<UserFirstLastNamesAgeAndSoldProductsNameAndPriceDto> users = this.userRepository
                .findByUserOrderByCount()
                .stream()
                .map(user -> {
                    final UserFirstLastNamesAgeAndSoldProductsNameAndPriceDto userDto =
                            this.modelMapper.map(user, UserFirstLastNamesAgeAndSoldProductsNameAndPriceDto.class);

                    final SoldProductsDto soldProductsDto = new SoldProductsDto();

                    soldProductsDto.setSoldProducts(user
                            .getSellingItems()
                            .stream()
                            .filter(sale -> sale.getBuyer() != null)
                            .map(sale -> this.modelMapper.map(sale, ProductNameAndPriceDto.class))
                            .collect(Collectors.toSet()));

                    soldProductsDto.setCount(soldProductsDto.getSoldProducts().size());

                    userDto.setSoldProducts(soldProductsDto);

                    return userDto;
                })
                .sorted((u1, u2) -> {
                    int cmp = u2.getSoldProducts().getCount() - u1.getSoldProducts().getCount();
                    if (cmp == 0) {
                        cmp = u1.getLastName().compareTo(u2.getLastName());
                    }
                    return cmp;
                })
                .collect(Collectors.toList());

        final UsersWithSalesListDto usersWithSalesListDto = new UsersWithSalesListDto();
        usersWithSalesListDto.setUsers(users);
        usersWithSalesListDto.setUsersCount(users.size());

        System.out.println(this.gson.toJson(usersWithSalesListDto));
    }
}
