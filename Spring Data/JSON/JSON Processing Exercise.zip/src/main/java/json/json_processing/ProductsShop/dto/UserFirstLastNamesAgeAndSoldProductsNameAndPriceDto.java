package json.json_processing.ProductsShop.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class UserFirstLastNamesAgeAndSoldProductsNameAndPriceDto implements Serializable {
    private String firstName;

    private String lastName;

    private Integer age;

    private SoldProductsDto soldProducts;
}
