package json.json_processing.ProductsShop.dto;

import java.util.List;

public class UserProductsCountDto {
    private String firstName;
    private String lastName;
    private Integer age;
    private List<ProductsDto> sellingItems;

    public UserProductsCountDto(String firstName, String lastName, Integer age, List<ProductsDto> sellingItems) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.sellingItems = sellingItems;
    }

    public UserProductsCountDto() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public List<ProductsDto> getSellingItems() {
        return sellingItems;
    }

    public void setSellingItems(List<ProductsDto> sellingItems) {
        this.sellingItems = sellingItems;
    }
}
