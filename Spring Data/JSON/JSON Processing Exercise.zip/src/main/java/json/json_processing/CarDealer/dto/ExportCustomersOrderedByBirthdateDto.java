package json.json_processing.CarDealer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.Set;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class ExportCustomersOrderedByBirthdateDto {
    private Long id;

    private String name;

    private Date birthDate;

    private boolean isYoungDriver;

    private Set<SaleExportDto> sales;

    public ExportCustomersOrderedByBirthdateDto(Long id, String name, Date birthDate, boolean isYoungDriver, Set<SaleExportDto> sales) {
        this.id = id;
        this.name = name;
        this.birthDate = birthDate;
        this.isYoungDriver = isYoungDriver;
        this.sales = sales;
    }
}
