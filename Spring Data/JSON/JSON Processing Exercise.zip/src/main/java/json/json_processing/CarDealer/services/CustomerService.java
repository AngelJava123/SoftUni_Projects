package json.json_processing.CarDealer.services;

public interface CustomerService {

    void findAllOrderByBirthDateAsc();

    void findAllCustomersAndTheirCars();
}
