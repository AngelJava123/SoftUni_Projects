package json.json_processing.CarDealer.repositories;

import json.json_processing.CarDealer.dto.CustomersAndCarsDto;
import json.json_processing.CarDealer.entities.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    @Query("SELECT c FROM Customer c ORDER BY c.birthDate ASC")
    List<Customer> findAllOrderByBirthDate();

    @Query("SELECT new json.json_processing.CarDealer.dto.CustomersAndCarsDto" +
            "(c.name, SIZE(c.sales), SUM(p.price * s.discount))" +
            " FROM Customer c JOIN c.sales s JOIN s.car ca JOIN ca.parts p WHERE" +
            " SIZE(c.sales) > 0" +
            " GROUP BY c.name ORDER BY SUM(p.price) DESC, SIZE(c.sales) DESC")
    List<CustomersAndCarsDto> findAllCustomersAndTheirCars();
}
