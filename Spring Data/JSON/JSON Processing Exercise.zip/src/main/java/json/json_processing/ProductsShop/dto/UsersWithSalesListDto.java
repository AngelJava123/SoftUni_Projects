package json.json_processing.ProductsShop.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
@ToString
public class UsersWithSalesListDto {
    private Integer usersCount;

    private List<UserFirstLastNamesAgeAndSoldProductsNameAndPriceDto> users;

    public UsersWithSalesListDto() {
        users = new ArrayList<>();
    }
}
