package json.json_processing.CarDealer.dto;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CustomersAndCarsDto {
    private String fullName;
    private int boughtCars;
    private BigDecimal spentMoney;

    public CustomersAndCarsDto(String fullName, int boughtCars, double spentMoney) {
        this.fullName = fullName;
        this.boughtCars = boughtCars;
        this.spentMoney = new BigDecimal(spentMoney).setScale(2, RoundingMode.HALF_UP);
    }

    public CustomersAndCarsDto() {
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getBoughtCars() {
        return boughtCars;
    }

    public void setBoughtCars(int boughtCars) {
        this.boughtCars = boughtCars;
    }

    public BigDecimal getSpentMoney() {
        return spentMoney;
    }

    public void setSpentMoney(BigDecimal spentMoney) {
        this.spentMoney = spentMoney;
    }
}
