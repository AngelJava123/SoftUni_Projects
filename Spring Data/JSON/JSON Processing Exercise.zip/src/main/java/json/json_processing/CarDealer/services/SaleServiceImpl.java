package json.json_processing.CarDealer.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.json_processing.CarDealer.dto.PlainCarDto;
import json.json_processing.CarDealer.dto.SaleDiscountDto;
import json.json_processing.CarDealer.repositories.SaleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SaleServiceImpl implements SaleService {

    private final SaleRepository saleRepository;
    private final Gson gson;

    @Autowired
    public SaleServiceImpl(SaleRepository saleRepository) {
        this.saleRepository = saleRepository;
        this.gson = new GsonBuilder().setPrettyPrinting().setDateFormat("yyyy-MM-dd'T'hh:mm:ss").create();

    }

    @Override
    @Transactional
    public void findAllSalesWithDiscount() {

        List<SaleDiscountDto> collect = this.saleRepository.findAll()
                .stream().map(s -> new SaleDiscountDto(
                        new PlainCarDto(
                                s.getCar().getMake(),
                                s.getCar().getModel(),
                                s.getCar().getTravelledDistance()),
                        s.getCustomer().getName(),
                        s.getDiscount(),
                        s.getCar().getParts().stream().mapToDouble(c -> c.getPrice().doubleValue()).sum())).
                collect(Collectors.toList());

        System.out.println(this.gson.toJson(collect));
    }
}
