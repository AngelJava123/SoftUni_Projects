package json.json_processing.ProductsShop.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.json_processing.ProductsShop.dto.CategoriesWithProductsDto;
import json.json_processing.ProductsShop.entities.Product;
import json.json_processing.ProductsShop.dto.ProductsInRangeDto;
import json.json_processing.ProductsShop.repositories.ProductRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {


    private final ProductRepository productRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;


    @Autowired
    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        this.modelMapper = new ModelMapper();
    }

    @Override
    public void findProductsInRange() {

        Set<Product> products = this.productRepository.findProductsInRange();

        List<ProductsInRangeDto> productsInRangeDtos = products.stream().
                map(product -> new ProductsInRangeDto(product.getName(),
                        product.getPrice(), product.getSeller().getFirstName(),
                        product.getSeller().getLastName())).collect(Collectors.toList());

        System.out.println(this.gson.toJson(productsInRangeDtos));
    }

    @Override
    public void findAllCategoriesWithProducts() {

        Set<CategoriesWithProductsDto> categoriesWithProductsDtos =
                this.productRepository.findCategoriesWithProductsCount();

        System.out.println(gson.toJson(categoriesWithProductsDtos));
    }
}
