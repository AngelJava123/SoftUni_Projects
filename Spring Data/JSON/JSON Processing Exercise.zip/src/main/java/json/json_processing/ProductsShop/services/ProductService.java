package json.json_processing.ProductsShop.services;

public interface ProductService {

    void findProductsInRange();

    void findAllCategoriesWithProducts();
}
