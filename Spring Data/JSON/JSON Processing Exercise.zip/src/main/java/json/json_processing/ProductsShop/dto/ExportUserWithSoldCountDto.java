package json.json_processing.ProductsShop.dto;

public class ExportUserWithSoldCountDto {
    private String firstName;
    private String lastName;
    private Integer age;

    public ExportUserWithSoldCountDto() {
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
