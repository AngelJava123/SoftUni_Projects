package json.json_processing.CarDealer.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.json_processing.CarDealer.dto.CarExportDto;
import json.json_processing.CarDealer.dto.CarsWithPartsDto;
import json.json_processing.CarDealer.entities.Car;
import json.json_processing.CarDealer.repositories.CarRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final ModelMapper modelMapper;
    private final Gson gson;

    public CarServiceImpl(CarRepository carRepository) {
        this.carRepository = carRepository;
        this.modelMapper = new ModelMapper();
        this.gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'hh:mm:ss")
                .setPrettyPrinting()
                .create();
    }

    @Override
    public void findAllCarsByMakeOrderByModelAscTravelledDistanceDesc() {

        List<Car> cars = this.carRepository.findAllCarsByMakeOrderByModelAscTravelledDistanceDesc("Toyota");

        List<CarExportDto> carExportDtos = cars
                .stream()
                .map(car -> this.modelMapper.map(car, CarExportDto.class))
                .collect(Collectors.toList());

        System.out.println(this.gson.toJson(carExportDtos));
    }

    @Override
    @Transactional
    public void findCarsWithParts() {

        List<Car> carList = this.carRepository.findAll();

        List<CarsWithPartsDto> carsWithPartsDtos = carList
                .stream()
                .map(car -> this.modelMapper.map(car, CarsWithPartsDto.class))
                .collect(Collectors.toList());

        System.out.println(this.gson.toJson(carsWithPartsDtos));
    }
}
