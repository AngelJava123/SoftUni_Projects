package json.json_processing.CarDealer.services;

public interface SupplierService {
    void findAllSuppliersNotImportingFromAbroad();
}
