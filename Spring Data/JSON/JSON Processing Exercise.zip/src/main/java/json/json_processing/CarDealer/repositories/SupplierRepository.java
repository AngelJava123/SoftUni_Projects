package json.json_processing.CarDealer.repositories;

import json.json_processing.CarDealer.dto.ExportSupplierDto;
import json.json_processing.CarDealer.entities.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier, Long> {

    @Query("SELECT new json.json_processing.CarDealer.dto.ExportSupplierDto" +
            "(s.id, s.name, size(s.parts)) FROM Supplier s WHERE s.isImporter = false")
    List<ExportSupplierDto> findAllSuppliersNotImportingFromAbroad();
}
