package json.json_processing.ProductsShop;

import json.json_processing.ProductsShop.services.CategoryService;
import json.json_processing.ProductsShop.services.ProductService;
import json.json_processing.ProductsShop.services.SeedService;
import json.json_processing.ProductsShop.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ProductsShopRunner implements CommandLineRunner {

    private final SeedService seedService;
    private final ProductService productService;
    private final UserService userService;
    private final CategoryService categoryService;

    @Autowired
    public ProductsShopRunner(SeedService seedService, ProductService productService, UserService userService, CategoryService categoryService) {
        this.seedService = seedService;
        this.productService = productService;
        this.userService = userService;
        this.categoryService = categoryService;
    }

    @Override
    public void run(String... args) throws Exception {

        // this.seedService.seedUsers();
        // this.seedService.seedCategories();
        // this.seedService.seedProducts();

        // this.productService.findProductsInRange();

        // this.userService.findProductWithBuyer();

        // this.productService.findAllCategoriesWithProducts();

        // this.userService.findByUserOrderByCount();
    }
}
