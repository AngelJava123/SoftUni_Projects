package json.json_processing.CarDealer.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.json_processing.CarDealer.dto.CustomersAndCarsDto;
import json.json_processing.CarDealer.dto.ExportCustomersOrderedByBirthdateDto;
import json.json_processing.CarDealer.entities.Customer;
import json.json_processing.CarDealer.repositories.CustomerRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
        this.gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'hh:mm:ss").setPrettyPrinting().create();
        this.modelMapper = new ModelMapper();
    }

    @Override
    @Transactional
    public void findAllOrderByBirthDateAsc() {

        List<Customer> customerList = this.customerRepository.findAllOrderByBirthDate();

        List<Customer> sorted = customerList.stream().sorted((l, r) -> {

            if (l.getBirthDate() == r.getBirthDate()) {
                return Boolean.compare(l.isYoungDriver(), r.isYoungDriver());
            }
            return 0;
        }).collect(Collectors.toList());

        List<ExportCustomersOrderedByBirthdateDto> exportCustomersOrderedByBirthdateDtos =
                sorted.stream().map(customer -> modelMapper.map
                        (customer, ExportCustomersOrderedByBirthdateDto.class)).collect(Collectors.toList());

        System.out.println(this.gson.toJson(exportCustomersOrderedByBirthdateDtos));
    }

    @Override
    public void findAllCustomersAndTheirCars() {

        List<CustomersAndCarsDto> customersAndCarsDtos = this.customerRepository.findAllCustomersAndTheirCars();

        System.out.println(this.gson.toJson(customersAndCarsDtos));
    }
}
