package json.json_processing.ProductsShop.services;

import org.springframework.stereotype.Service;

@Service
public class CategoryServiceImpl implements CategoryService {
}
