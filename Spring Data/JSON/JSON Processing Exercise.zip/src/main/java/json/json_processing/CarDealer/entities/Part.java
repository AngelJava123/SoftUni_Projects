package json.json_processing.CarDealer.entities;

import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Set;

@Entity
@Table(name = "parts")
@Getter
@Setter
@ToString
@RequiredArgsConstructor
public class Part {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private BigDecimal price;
    private Integer quantity;

    @ManyToOne
    private Supplier supplier;

    @ManyToMany(mappedBy = "parts")
    @ToString.Exclude
    private Set<Car> cars;
}
