package json.json_processing.CarDealer.dto;

import com.google.gson.annotations.SerializedName;

public class SaleDiscountDto {
    private PlainCarDto car;
    private String customerName;

    @SerializedName("Discount")
    private Double discount;

    private Double price;

    private Double priceWithDiscount;

    public SaleDiscountDto() {}

    public SaleDiscountDto(PlainCarDto car, String customerName, Double discount, Double price) {
        this.car = car;
        this.customerName = customerName;
        this.discount = discount;
        this.price = price;
        this.priceWithDiscount = price * discount;
    }

    public PlainCarDto getCar() {
        return car;
    }

    public void setCar(PlainCarDto car) {
        this.car = car;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getPriceWithDiscount() {
        return priceWithDiscount;
    }

    public void setPriceWithDiscount(Double priceWithDiscount) {
        this.priceWithDiscount = priceWithDiscount;
    }
}
