package json.json_processing.CarDealer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@Getter
@Setter
public class SaleExportDto {

    private CarExportDto car;

    public SaleExportDto(CarExportDto car) {
        this.car = car;
    }
}

