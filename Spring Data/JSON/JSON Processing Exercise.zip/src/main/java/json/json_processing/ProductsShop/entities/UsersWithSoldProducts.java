package json.json_processing.ProductsShop.entities;

import java.util.List;

public class UsersWithSoldProducts {
    private String firstName;
    private String lastName;
    private List<ProductsSold> itemsBought;

    public UsersWithSoldProducts(String firstName, String lastName, List<ProductsSold> itemsBought) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.itemsBought = itemsBought;
    }

    public UsersWithSoldProducts() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<ProductsSold> getItemsBought() {
        return itemsBought;
    }

    public void setItemsBought(List<ProductsSold> itemsBought) {
        this.itemsBought = itemsBought;
    }
}
