package json.json_processing.CarDealer.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.json_processing.CarDealer.dto.ExportSupplierDto;
import json.json_processing.CarDealer.repositories.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierServiceImpl implements SupplierService {

    private final SupplierRepository supplierRepository;
    private final Gson gson;

    @Autowired
    public SupplierServiceImpl(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
        this.gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'hh:mm:ss").setPrettyPrinting().create();

    }

    @Override
    public void findAllSuppliersNotImportingFromAbroad() {

        List<ExportSupplierDto> supplierDtoList = this.supplierRepository.findAllSuppliersNotImportingFromAbroad();

        System.out.println(this.gson.toJson(supplierDtoList));
    }
}
