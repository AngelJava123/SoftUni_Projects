package json.json_processing.ProductsShop.services;

public interface CategoryService {
}
