package json.json_processing.ProductsShop.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.json_processing.ProductsShop.dto.CategoryDto;
import json.json_processing.ProductsShop.dto.ProductsDto;
import json.json_processing.ProductsShop.dto.UserDto;
import json.json_processing.ProductsShop.entities.*;
import json.json_processing.ProductsShop.repositories.CategoryRepository;
import json.json_processing.ProductsShop.repositories.ProductRepository;
import json.json_processing.ProductsShop.repositories.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SeedServiceImpl implements SeedService {

    private static final String USERS_PATH = "src\\main\\resources\\files\\users.json";
    private static final String PRODUCTS_PATH = "src\\main\\resources\\files\\products.json";
    private static final String CATEGORIES_PATH = "src\\main\\resources\\files\\categories.json";

    private final Gson gson;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;


    @Autowired
    public SeedServiceImpl(UserRepository userRepository, CategoryRepository categoryRepository, ProductRepository productRepository) {
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
        this.modelMapper = new ModelMapper();
        this.userRepository = userRepository;
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    @Override
    public void seedUsers() throws FileNotFoundException {

        FileReader userPath = new FileReader(USERS_PATH);
        UserDto[] users = gson.fromJson(userPath, UserDto[].class);

        List<User> userList = Arrays.stream(users)
                .map(user -> this.modelMapper.map(user, User.class))
                .collect(Collectors.toList());

        this.userRepository.saveAll(userList);
    }

    @Override
    public void seedCategories() throws FileNotFoundException {

        FileReader categoryPath = new FileReader(CATEGORIES_PATH);
        CategoryDto[] categoryDtos = gson.fromJson(categoryPath, CategoryDto[].class);

        List<Category> userList = Arrays.stream(categoryDtos)
                .map(category -> this.modelMapper.map(category, Category.class))
                .collect(Collectors.toList());

        this.categoryRepository.saveAll(userList);
    }

    @Override
    public void seedProducts() throws FileNotFoundException {

        FileReader productPath = new FileReader(PRODUCTS_PATH);
        ProductsDto[] productsDtos = gson.fromJson(productPath, ProductsDto[].class);

        List<Product> userList = Arrays.stream(productsDtos)
                .map(product -> this.modelMapper.map(product, Product.class))
                .map(this::setRandomSeller)
                .map(this::setRandomBuyer)
                .map(this::setRandomCategories)
                .collect(Collectors.toList());


        this.productRepository.saveAll(userList);
    }

    private Product setRandomCategories(Product product) {
        Random random = new Random();
        long categoriesDbCount = this.categoryRepository.count();

        int count = random.nextInt((int) categoriesDbCount);

        Set<Category> categories = new HashSet<>();
        for (int i = 0; i < count; i++) {
            int randomId = random.nextInt((int) categoriesDbCount) + 1;

            Optional<Category> randomCategory = this.categoryRepository.findById((long) randomId);

            categories.add(randomCategory.get());
        }

        product.setCategories(categories);
        return product;
    }

    private Product setRandomBuyer(Product product) {
        if (product.getPrice().compareTo(BigDecimal.valueOf(944)) > 0) {
            return product;
        }

        Optional<User> buyer = getRandomUser();

        product.setBuyer(buyer.get());

        return product;
    }

    private Product setRandomSeller(Product product) {

        Optional<User> seller = getRandomUser();

        product.setSeller(seller.get());

        return product;
    }

    private Optional<User> getRandomUser() {
        long usersCount = this.userRepository.count(); // 1..5

        // 0..4
        int randomUserId = new Random().nextInt((int) usersCount) + 1;

        Optional<User> seller = this.userRepository.findById((long) randomUserId);
        return seller;
    }

}
