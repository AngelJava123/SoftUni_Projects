package json.json_processing.CarDealer.dto;

public class ImportSuppliersDto {

    private String name;

    private boolean isImporter;

    public ImportSuppliersDto(String name, boolean isImporter) {
        this.name = name;
        this.isImporter = isImporter;
    }

    public ImportSuppliersDto() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isImporter() {
        return isImporter;
    }

    public void setImporter(boolean importer) {
        isImporter = importer;
    }
}
