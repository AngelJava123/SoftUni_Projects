package json.json_processing.ProductsShop.repositories;

import json.json_processing.ProductsShop.dto.CategoriesWithProductsDto;
import json.json_processing.ProductsShop.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query(value = "SELECT * FROM products p JOIN users u ON p.seller_id = u.id " +
            "WHERE p.price BETWEEN 500 AND 1000 AND p.buyer_id IS NULL " +
            "ORDER BY p.price ASC;", nativeQuery = true)
    Set<Product> findProductsInRange();

    @Query("SELECT new json.json_processing.ProductsShop.dto.CategoriesWithProductsDto" +
            "(c.name, size(p.categories), AVG(p.price), SUM(p.price)) " +
            "FROM Product p JOIN p.categories c GROUP BY c")
    Set<CategoriesWithProductsDto> findCategoriesWithProductsCount();
}
