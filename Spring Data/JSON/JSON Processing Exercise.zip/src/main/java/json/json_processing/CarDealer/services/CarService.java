package json.json_processing.CarDealer.services;

public interface CarService {
    void findAllCarsByMakeOrderByModelAscTravelledDistanceDesc();

    void findCarsWithParts();
}
