package dto.services;

import dto.entities.Employee;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    List<Employee> getAllEmployees();

    List<Employee> getAllManagers();

    List<Employee> getAllEmployeesBornBefore(LocalDate date);

    Optional<Employee> getEmployeeById(Long id);

    Employee addEmployee(Employee employee);

    Employee updateEmployee(Employee employee);

    Optional<Employee> deleteEmployee(Long id);

    long getEmployeeCount();
}
