package dto.services;

import dto.entities.Address;
import dto.repositories.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class AddressServiceImpl implements AddressService {
    private final AddressRepository addressRepository;

    @Autowired
    public AddressServiceImpl(AddressRepository addressRepository) {
        this.addressRepository = addressRepository;
    }

    @Override
    public List<Address> getAllAddress() {
        return addressRepository.findAll();
    }

    @Override
    public Optional<Address> getAddressById(Long id) {
        return addressRepository.findById(id);
    }

    @Override
    @Transactional
    public Address addAddress(Address address) {

        address.setId(null);
        return addressRepository.save(address);
    }

    @Override
    @Transactional
    public Address updateAddress(Address address) {
        getAddressById(address.getId());
        return addressRepository.save(address);
    }

    @Override
    @Transactional
    public Optional<Address> deleteAddress(Long id) {
        Optional<Address> removed = getAddressById(id);
        addressRepository.deleteById(id);
        return removed;
    }

    @Override
    public long getAddressCount() {
        return addressRepository.count();
    }
}
