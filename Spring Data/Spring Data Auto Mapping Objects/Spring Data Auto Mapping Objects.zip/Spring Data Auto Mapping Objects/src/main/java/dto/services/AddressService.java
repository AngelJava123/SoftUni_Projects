package dto.services;

import dto.entities.Address;

import java.util.List;
import java.util.Optional;

public interface AddressService {
    List<Address> getAllAddress();

    Optional<Address> getAddressById(Long id);

    Address addAddress(Address address);

    Address updateAddress(Address address);

    Optional<Address> deleteAddress(Long id);

    long getAddressCount();
}
