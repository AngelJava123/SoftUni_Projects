package dto.services;

import dto.entities.Employee;
import dto.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;

    @Autowired
    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }


    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public List<Employee> getAllManagers() {
        return employeeRepository.getManagers();
    }

    @Override
    public List<Employee> getAllEmployeesBornBefore(LocalDate date) {
        return employeeRepository.findAllByBirthdayBeforeOrderBySalaryDesc(date);
    }

    @Override
    public Optional<Employee> getEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    @Override
    @Transactional
    public Employee addEmployee(Employee employee) {

        employee.setId(null);

        if (employee.getManager() != null) {
            employee.getManager().getSubordinates().add(employee);
        }
        return employeeRepository.save(employee);
    }

    @Override
    @Transactional
    public Employee updateEmployee(Employee employee) {
        Optional<Employee> existing = getEmployeeById(employee.getId());
        Employee updated = employeeRepository.save(employee);

        if (existing.get().getManager() != null && !existing.get().getManager().equals(employee.getManager())) {
            existing.get().getManager().getSubordinates().remove(existing);
        }
        if (updated.getManager() != null && !updated.getManager().equals(existing.get().getManager())) {
            updated.getManager().getSubordinates().add(updated);
        }
        return updated;
    }

    @Override
    @Transactional
    public Optional<Employee> deleteEmployee(Long id) {
        Optional<Employee> removed = getEmployeeById(id);
        if (removed.get().getManager() != null) {
            removed.get().getManager().getSubordinates().remove(removed);
        }
        employeeRepository.deleteById(id);
        return removed;
    }

    @Override
    public long getEmployeeCount() {

        return employeeRepository.count();
    }
}
