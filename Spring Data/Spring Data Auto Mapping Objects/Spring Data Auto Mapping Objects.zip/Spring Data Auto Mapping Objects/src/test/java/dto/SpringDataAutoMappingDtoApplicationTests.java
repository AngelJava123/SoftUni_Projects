package dto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataAutoMappingDtoApplicationTests {

    @Test
    void contextLoads() {
    }

}
