package gameStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftUniGameStroreDtoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoftUniGameStroreDtoApplication.class, args);
    }

}
