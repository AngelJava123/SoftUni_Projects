package gameStore.services;

import gameStore.models.UserLoginDto;
import gameStore.models.UserRegisterDto;

import java.io.IOException;

public interface UserService {
    void registerUser(UserRegisterDto userRegisterDto);

    void loginUser(UserLoginDto userLoginDto);

    void logout();

    void findAllGamesByUser() throws IOException;
}
