package gameStore.services;

import gameStore.models.GameAddDto;

import java.math.BigDecimal;

public interface GameService {
    void addGame(GameAddDto gameAddDto);

    void editGame(Long gameId, BigDecimal price, Double size);

    void deleteGame(long parseLong);

    void findAll();

    void findByTitle(String command);
}
