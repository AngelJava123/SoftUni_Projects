package gameStore.services;

import gameStore.models.*;
import gameStore.repositories.GameRepository;
import gameStore.repositories.UserRepository;
import gameStore.util.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private User loggedInUser;
    private final GameRepository gameRepository;
    private final BufferedReader reader;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, ValidationUtil validationUtil, GameRepository gameRepository) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.gameRepository = gameRepository;
        this.reader = new BufferedReader(new InputStreamReader(System.in));
    }


    @Override
    public void registerUser(UserRegisterDto userRegisterDto) {

        if (!userRegisterDto.getPassword().equals(userRegisterDto.getConfirmPassword())) {
            System.out.println("Wrong confirm password");
            return;
        }
        Set<ConstraintViolation<UserRegisterDto>> violations = validationUtil.getViolations(userRegisterDto);

        if (!violations.isEmpty()) {
            violations.stream().map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
            return;
        }

        User user = modelMapper.map(userRegisterDto, User.class);

        userRepository.save(user);
    }

    @Override
    public void loginUser(UserLoginDto userLoginDto) {
        Set<ConstraintViolation<UserLoginDto>> violations = validationUtil.getViolations(userLoginDto);

        if (!violations.isEmpty()) {
            violations.stream().map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
            return;
        }

        User user = userRepository.findByEmailAndPassword(
                        userLoginDto.getEmail(), userLoginDto.getPassword())
                .orElse(null);

        if (user == null) {
            System.out.println("Incorrect username / password");
            return;
        }

        loggedInUser = user;
        System.out.println("Successfully logged in " + user.getFullName());
    }

    @Override
    public void logout() {

        if (loggedInUser == null) {
            System.out.println("Cannot log out. No user was logged in");
        } else {
            String name = loggedInUser.getFullName();
            loggedInUser = null;
            System.out.println("User " + name + " successfully logged out");
        }
    }

    @Override
    public void findAllGamesByUser() throws IOException {

        User user = this.userRepository.findByFullName(loggedInUser.getFullName());

        if (user == null) {
            System.out.println("There is no logged in user");
            return;
        }

        System.out.println("Enter the game/s title/s you would like to purchase");
        String[] purchase = reader.readLine().split("\\s+");

        for (String game : purchase) {
            Game gamePurchase = this.gameRepository.findByTitle(game);
            user.getGames().add(gamePurchase);
        }

        System.out.println("Game has been successfully purchased");

        Set<GamesByLoggedUser> dtos = user.getGames()
                .stream()
                .map(game -> modelMapper.map(game, GamesByLoggedUser.class))
                .collect(Collectors.toSet());

        System.out.println("Owned Games:");
        dtos.forEach(System.out::println);

    }
}
