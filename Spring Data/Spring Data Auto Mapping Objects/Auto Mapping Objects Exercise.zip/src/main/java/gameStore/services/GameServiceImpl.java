package gameStore.services;

import gameStore.models.AllGamesView;
import gameStore.models.Game;
import gameStore.models.GameAddDto;
import gameStore.models.GameDetailsView;
import gameStore.repositories.GameRepository;
import gameStore.util.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class GameServiceImpl implements GameService {

    private final GameRepository gameRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;

    public GameServiceImpl(GameRepository gameRepository, ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.gameRepository = gameRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public void addGame(GameAddDto gameAddDto) {
        Set<ConstraintViolation<GameAddDto>> violations = validationUtil.getViolations(gameAddDto);

        if (!violations.isEmpty()) {
            violations.stream().map(ConstraintViolation::getMessage).
                    forEach(System.out::println);
            return;
        }

        Game game = modelMapper.map(gameAddDto, Game.class);
        this.gameRepository.save(game);

        System.out.println("Added " + gameAddDto.getTitle());
    }

    @Override
    public void editGame(Long gameId, BigDecimal price, Double size) {
        Game game = gameRepository.findById(gameId)
                .orElse(null);

        if (game == null) {
            System.out.println("Id is not correct");
            return;
        }
        game.setPrice(price);
        game.setSize(size);
        game.setId(gameId);

        gameRepository.save(game);
        System.out.println("Edited " + game.getTitle());
    }

    @Override
    public void deleteGame(long parseLong) {
        Game game = gameRepository.findById(parseLong)
                .orElse(null);

        if (game == null) {
            System.out.println("Id is not correct");
            return;
        }
        this.gameRepository.deleteById(parseLong);
        System.out.println("Deleted " + game.getTitle());
    }

    @Override
    public void findAll() {

        List<Game> games = this.gameRepository.findAll();

        if (games.isEmpty()) {
            System.out.println("There are no games");
            return;
        }

        List<AllGamesView> dtos = games
                .stream()
                .map(game -> modelMapper.map(game, AllGamesView.class))
                .collect(Collectors.toList());

        dtos.forEach(System.out::println);
    }

    @Override
    public void findByTitle(String name) {

        Game game = this.gameRepository.findByTitle(name);

        if (game == null) {
            System.out.println("There is no game with that title");
            return;
        }

        GameDetailsView gameDetailsView = modelMapper.map(game, GameDetailsView.class);

        System.out.println(gameDetailsView.toString());

    }
}
