package gameStore.models;

import java.math.BigDecimal;

public class GameDetailsView {
    private String title;
    private BigDecimal price;
    private String description;
    private String releaseDate;

    public GameDetailsView(String title, BigDecimal price, String description, String releaseDate) {
        this.title = title;
        this.price = price;
        this.description = description;
        this.releaseDate = releaseDate;
    }

    public GameDetailsView() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Title: ").append(title).append(System.lineSeparator());
        sb.append("Price: ").append(price).append(System.lineSeparator());
        sb.append("Description: ").append(description).append(System.lineSeparator());
        sb.append("ReleaseDate: ").append(releaseDate);
        return sb.toString();
    }
}
