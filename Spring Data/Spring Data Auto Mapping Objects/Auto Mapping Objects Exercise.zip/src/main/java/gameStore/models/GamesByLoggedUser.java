package gameStore.models;

public class GamesByLoggedUser {
    private String title;

    public GamesByLoggedUser(String title) {
        this.title = title;
    }

    public GamesByLoggedUser() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(title).append(System.lineSeparator());
        return sb.toString();
    }
}
