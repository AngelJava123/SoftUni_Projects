package com.example.advquerying;

import com.example.advquerying.entities.Size;
import com.example.advquerying.services.IngredientService;
import com.example.advquerying.services.ShampooService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Set;

@Component
public class Runner implements CommandLineRunner {

    private final ShampooService shampooService;
    private final IngredientService ingredientService;

    public Runner(ShampooService shampooService, IngredientService ingredientService) {
        this.shampooService = shampooService;
        this.ingredientService = ingredientService;
    }

    @Override
    public void run(String... args) {

        this._01_Select_Shampoos_by_Size();
        this._02_Select_Shampoos_by_Size_or_Label();
        this._03_Select_Shampoos_by_Price();
        this._04_Select_Ingredients_by_Name();
        this._05_Select_Ingredients_by_Names();
        this._06_Count_Shampoos_by_Price();
        this._07_Select_Shampoos_by_Ingredients();
        this._08_Select_Shampoos_by_Ingredients_Count();
        this._09_Delete_Ingredients_by_Name();
        this._10_Update_Ingredients_by_Price();
        this._11_Update_Ingredients_by_Names();
    }

    private void _11_Update_Ingredients_by_Names() {

        this.ingredientService.updateByName(Set.of("Lavender", "Herbs", "Wild Rose"));
    }

    private void _10_Update_Ingredients_by_Price() {

        this.ingredientService.increasePriceBy10Percent();
    }

    private void _09_Delete_Ingredients_by_Name() {

        this.ingredientService.deleteByName("Apple");
    }

    private void _08_Select_Shampoos_by_Ingredients_Count() {

        this.shampooService.findAllShampoosByIngredientsLessThan(2)
                .forEach(s -> System.out.println(s.getBrand()));
    }

    private void _07_Select_Shampoos_by_Ingredients() {

        this.shampooService.findAllByIngredients(Set.of("Berry", "Mineral-Collagen"))
                .forEach(s -> System.out.println(s.getBrand()));
    }

    private void _06_Count_Shampoos_by_Price() {

        System.out.println(this.shampooService.countAllShampoos(BigDecimal.valueOf(8.50)));
    }

    private void _05_Select_Ingredients_by_Names() {

        this.ingredientService.findAllByNameInOrderByPriceAsc(Set.of("Lavender", "Herbs", "Apple"))
                .forEach(i -> System.out.println(i.getName()));
    }

    private void _04_Select_Ingredients_by_Name() {

        this.ingredientService.findAllByNameStartingWith("M")
                .forEach(i -> System.out.println(i.getName()));
    }

    private void _03_Select_Shampoos_by_Price() {

        this.shampooService.findAllByPriceGreaterThanOrderByPriceDesc(BigDecimal.valueOf(5))
                .forEach(s -> System.out.println(s.getBrand() + " " + s.getSize().name() + " " + s.getPrice()));
    }

    private void _02_Select_Shampoos_by_Size_or_Label() {

        this.shampooService.findAllBySizeOrLabelIdOrderByPriceAsc(Size.MEDIUM, 10L)
                .forEach(s -> System.out.println(s.getBrand() + " " + s.getSize().name() + " " + s.getPrice()));

    }

    private void _01_Select_Shampoos_by_Size() {

        this.shampooService.findAllBySizeOrderById(Size.MEDIUM)
                .forEach(s -> System.out.println(s.getBrand() + " " + s.getSize().name() + " " + s.getPrice()));
    }
}
