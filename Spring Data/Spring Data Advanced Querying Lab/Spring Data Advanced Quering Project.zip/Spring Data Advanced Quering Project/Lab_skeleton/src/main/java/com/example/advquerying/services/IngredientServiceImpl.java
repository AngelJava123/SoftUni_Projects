package com.example.advquerying.services;


import com.example.advquerying.entities.Ingredient;
import com.example.advquerying.repositories.IngredientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class IngredientServiceImpl implements IngredientService {


    private final IngredientRepository ingredientRepository;

    @Autowired
    public IngredientServiceImpl(IngredientRepository ingredientRepository) {
        this.ingredientRepository = ingredientRepository;
    }

    @Override
    public List<Ingredient> findAllByNameInOrderByPriceAsc(Set<String> lavender) {

        return this.ingredientRepository.findAllByNameInOrderByPriceAsc(lavender);
    }

    @Override
    public List<Ingredient> findAllByNameStartingWith(String m) {

        return this.ingredientRepository.findAllByNameStartingWith(m);
    }

    @Override
    public void deleteByName(String apple) {

        this.ingredientRepository.deleteByName(apple);
    }

    @Override
    public void increasePriceBy10Percent() {

        this.ingredientRepository.increaseIngredientsPriceBy10Percent();
    }

    @Override
    public void updateByName(Set<String> lavender) {

        this.ingredientRepository.updateByName(lavender);
    }
}
