package com.example.advquerying.services;

import com.example.advquerying.entities.Shampoo;
import com.example.advquerying.entities.Size;
import com.example.advquerying.repositories.ShampooRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Service
public class ShampooServiceImpl implements ShampooService {

    private final ShampooRepository shampooRepository;

    @Autowired
    public ShampooServiceImpl(ShampooRepository shampooRepository) {
        this.shampooRepository = shampooRepository;
    }

    @Override
    public List<Shampoo> findAllBySizeOrderById(Size size) {

        return this.shampooRepository.findAllBySizeOrderById(size);
    }

    @Override
    public List<Shampoo> findAllBySizeOrLabelIdOrderByPriceAsc(Size size, long id) {

        return this.shampooRepository.findAllBySizeOrLabelIdOrderByPriceAsc(size, id);
    }

    @Override
    public List<Shampoo> findAllByPriceGreaterThanOrderByPriceDesc(BigDecimal value) {

        return this.shampooRepository.findAllByPriceGreaterThanOrderByPriceDesc(value);
    }

    @Override
    public int countAllShampoos(BigDecimal valueOf) {

        return this.shampooRepository.countAllShampoosWithPriceLessThan(valueOf);
    }

    @Override
    public Set<Shampoo> findAllByIngredients(Set<String> berry) {


        return this.shampooRepository.findAllByIngredientsContaining(berry);
    }

    @Override
    public List<Shampoo> findAllShampoosByIngredientsLessThan(int i) {


        return this.shampooRepository.findAllShampoosByIngredientsLessThan(i);
    }
}
