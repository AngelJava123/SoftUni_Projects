package com.example.advquerying.entities;
public enum Size {
    SMALL, MEDIUM, LARGE
}
