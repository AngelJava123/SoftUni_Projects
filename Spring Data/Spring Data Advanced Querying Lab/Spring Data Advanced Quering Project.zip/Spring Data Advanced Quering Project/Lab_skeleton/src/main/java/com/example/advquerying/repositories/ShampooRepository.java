package com.example.advquerying.repositories;

import com.example.advquerying.entities.Shampoo;
import com.example.advquerying.entities.Size;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Repository
public interface ShampooRepository extends JpaRepository<Shampoo, Long> {

    List<Shampoo> findAllBySizeOrderById(Size size);

    List<Shampoo> findAllBySizeOrLabelIdOrderByPriceAsc(Size medium, Long id);

    List<Shampoo> findAllByPriceGreaterThanOrderByPriceDesc(BigDecimal price);

    @Query("SELECT COUNT(s) FROM Shampoo s WHERE s.price < :valueOf")
    int countAllShampoosWithPriceLessThan(BigDecimal valueOf);

    @Query("SELECT DISTINCT s FROM Shampoo s JOIN s.ingredients i WHERE i.name IN :berry")
    Set<Shampoo> findAllByIngredientsContaining(Set<String> berry);

    @Query("SELECT s FROM Shampoo s WHERE s.ingredients.size < :i")
    List<Shampoo> findAllShampoosByIngredientsLessThan(int i);

}
