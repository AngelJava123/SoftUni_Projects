package com.example.advquerying.repositories;

import com.example.advquerying.entities.Ingredient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Repository
public interface IngredientRepository extends JpaRepository<Ingredient, Long> {

    List<Ingredient> findAllByNameStartingWith(String m);

    List<Ingredient> findAllByNameInOrderByPriceAsc(Set<String> lavender);

    @Transactional
    @Modifying
    @Query("DELETE FROM Ingredient i WHERE i.name = :name")
    void deleteByName(String name);

    @Transactional
    @Modifying
    @Query("UPDATE Ingredient i SET i.price = i.price * 1.1")
    void increaseIngredientsPriceBy10Percent();

    @Transactional
    @Modifying
    @Query("UPDATE Ingredient i SET i.price = i.price * 1.1 WHERE i.name IN :lavender")
    void updateByName(Set<String> lavender);
}
