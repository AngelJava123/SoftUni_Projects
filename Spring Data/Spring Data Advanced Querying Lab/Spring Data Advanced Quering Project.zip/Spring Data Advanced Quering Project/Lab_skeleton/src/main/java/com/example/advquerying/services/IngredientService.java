package com.example.advquerying.services;


import com.example.advquerying.entities.Ingredient;

import java.util.List;
import java.util.Set;

public interface IngredientService {

    List<Ingredient> findAllByNameInOrderByPriceAsc(Set<String> lavender);

    List<Ingredient> findAllByNameStartingWith(String m);

    void deleteByName(String name);

    void increasePriceBy10Percent();

    void updateByName(Set<String> lavender);
}
