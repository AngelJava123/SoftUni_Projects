package softuni.exam.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.domain.dto.ImportPlayersDto;
import softuni.exam.domain.entities.Picture;
import softuni.exam.domain.entities.Player;
import softuni.exam.domain.entities.Team;
import softuni.exam.repository.PictureRepository;
import softuni.exam.repository.PlayerRepository;
import softuni.exam.repository.TeamRepository;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional
public class PlayerServiceImpl implements PlayerService {
    private final Path path =
            Path.of("src", "main", "resources", "files", "json", "players.json");

    private final PlayerRepository playerRepository;
    private final PictureRepository pictureRepository;
    private final TeamRepository teamRepository;
    private final Gson gson;
    private final javax.validation.Validator validator;
    private final ModelMapper modelMapper;

    public PlayerServiceImpl(PlayerRepository playerRepository, PictureRepository pictureRepository, TeamRepository teamRepository) {
        this.playerRepository = playerRepository;
        this.pictureRepository = pictureRepository;
        this.teamRepository = teamRepository;

        this.gson = new GsonBuilder().setPrettyPrinting().create();
        this.modelMapper = new ModelMapper();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();
    }

    @Override
    public String importPlayers() throws IOException {

        String json = this.readPlayersJsonFile();

        ImportPlayersDto[] playersDtos = this.gson.fromJson(json, ImportPlayersDto[].class);

        return Arrays.stream(playersDtos)
                .map(this::importPlayer)
                .collect(Collectors.joining("\n"));
    }

    private String importPlayer(ImportPlayersDto importPlayersDto) {
        Set<ConstraintViolation<ImportPlayersDto>> errors =
                this.validator.validate(importPlayersDto);

        if (!errors.isEmpty()) {
            return "Invalid Player";
        }

        Player player = this.modelMapper.map(importPlayersDto, Player.class);
        Optional<Picture> picture = this.pictureRepository.findByUrl(importPlayersDto.getPicture().getUrl());

        if (picture.isEmpty()) {
            return "Invalid Player";
        } else {
            player.setPicture(picture.get());
        }

        Optional<Team> team = this.teamRepository.findByName(importPlayersDto.getTeam().getName());

        if (team.isEmpty()) {
            return "Invalid Player";
        } else {
            player.setTeam(team.get());
        }

        this.playerRepository.save(player);

        return "Successfully imported Player " + player + " " +
                player.getFirstName() + " " + player.getLastName();
    }

    @Override
    public boolean areImported() {
        return this.playerRepository.count() > 0;
    }

    @Override
    public String readPlayersJsonFile() throws IOException {
        return Files.readString(path);
    }

    @Override
    @Transactional
    public String exportPlayersWhereSalaryBiggerThan() {

        String teamName = "North Hub";

        List<Player> playerList = this.playerRepository.findPlayersByTeamNameOrderById(teamName);

        StringBuilder builder = new StringBuilder("Team: " + teamName);
        for (Player player : playerList) {
            builder.append("     ").append(player.toString()).append(System.lineSeparator());
        }
        return builder.toString().trim();
    }

    @Override
    @Transactional
    public String exportPlayersInATeam() {

        List<Player> playerList = this.playerRepository.findPlayersBySalaryGreaterThanOrderBySalaryDesc(BigDecimal.valueOf(100000));

        StringBuilder builder = new StringBuilder();
        for (Player player : playerList) {
            builder.append("Player name: ").append(player.getFirstName()).append(" ").
                    append(player.getLastName()).append(System.lineSeparator());
            builder.append("     ").append("Number: ").append(player.getNumber()).append(System.lineSeparator());
            builder.append("     ").append("Salary: ").append(player.getSalary()).append(System.lineSeparator());
            builder.append("     ").append("Team: ").append(player.getTeam().getName());

        }
        return builder.toString().trim();
    }
}
