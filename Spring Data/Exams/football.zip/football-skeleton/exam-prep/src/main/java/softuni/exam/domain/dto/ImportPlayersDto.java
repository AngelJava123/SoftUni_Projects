package softuni.exam.domain.dto;

import javax.validation.constraints.*;
import java.math.BigDecimal;

public class ImportPlayersDto {

    @NotNull
    private String firstName;

    @NotNull
    @Size(min = 3, max = 15)
    private String lastName;

    @NotNull
    @Min(1)
    @Max(99)
    private Integer number;

    @NotNull
    @PositiveOrZero
    private BigDecimal salary;

    @NotNull
    private String position;

    @NotNull
    private TeamData team;

    @NotNull
    private PictureData picture;

    public ImportPlayersDto() {
    }

    public ImportPlayersDto(String firstName, String lastName,
                            Integer number, BigDecimal salary, String position, TeamData team, PictureData picture) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.number = number;
        this.salary = salary;
        this.position = position;
        this.team = team;
        this.picture = picture;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public TeamData getTeam() {
        return team;
    }

    public void setTeam(TeamData team) {
        this.team = team;
    }

    public PictureData getPicture() {
        return picture;
    }

    public void setPicture(PictureData picture) {
        this.picture = picture;
    }
}
