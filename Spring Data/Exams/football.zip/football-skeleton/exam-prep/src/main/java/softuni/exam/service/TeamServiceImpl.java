package softuni.exam.service;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.domain.dto.ImportTeamsDto;
import softuni.exam.domain.dto.TeamData;
import softuni.exam.domain.entities.Picture;
import softuni.exam.domain.entities.Team;
import softuni.exam.repository.PictureRepository;
import softuni.exam.repository.TeamRepository;


import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;


@Service
@Transactional
public class TeamServiceImpl implements TeamService {
    private final Path path =
            Path.of("src", "main", "resources", "files", "xml", "teams.xml");

    private final TeamRepository teamRepository;
    private final Unmarshaller unmarshaller;
    private final ModelMapper modelMapper;
    private final javax.validation.Validator validator;
    private final PictureRepository pictureRepository;

    @Autowired
    public TeamServiceImpl(TeamRepository teamRepository, PictureRepository pictureRepository) throws JAXBException {
        this.teamRepository = teamRepository;
        this.pictureRepository = pictureRepository;

        JAXBContext jaxbContext = JAXBContext.newInstance(ImportTeamsDto.class);
        this.unmarshaller = jaxbContext.createUnmarshaller();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public String importTeams() throws JAXBException, FileNotFoundException {
        ImportTeamsDto teamsDto = (ImportTeamsDto) this.unmarshaller.unmarshal(
                new FileReader(path.toAbsolutePath().toString()));

        return teamsDto
                .getTeams()
                .stream()
                .map(this::importTeam)
                .collect(Collectors.joining("\n"));
    }

    private String importTeam(TeamData teamData) {
        Set<ConstraintViolation<TeamData>> errors =
                this.validator.validate(teamData);

        if (!errors.isEmpty()) {
            return "Invalid Team";
        }

        Team team = this.modelMapper.map(teamData, Team.class);
        Optional<Picture> picture = this.pictureRepository.findByUrl(teamData.getPicture().getUrl());

        team.setPicture(picture.get());

        this.teamRepository.save(team);

        return "Successfully imported Team " + team + " - " + team.getPicture().getUrl();
    }

    @Override
    public boolean areImported() {
        return this.teamRepository.count() > 0;
    }

    @Override
    public String readTeamsXmlFile() throws IOException {
        return Files.readString(path);
    }
}
