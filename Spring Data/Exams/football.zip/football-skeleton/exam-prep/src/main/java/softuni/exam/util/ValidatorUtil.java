package softuni.exam.util;



public interface ValidatorUtil {

    <E> boolean isValid(E entity);

}
