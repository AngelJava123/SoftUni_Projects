package softuni.exam.domain.entities;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "pictures")
public class Picture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String url;

    @OneToMany(mappedBy = "picture")
    private Set<Team> pictures;

    @OneToMany(mappedBy = "picture")
    private Set<Player> player;

    public Picture(Integer id, String url, Set<Team> pictures, Set<Player> player) {
        this.id = id;
        this.url = url;
        this.pictures = pictures;
        this.player = player;
    }

    public Picture(String url, Set<Team> pictures, Set<Player> player) {
        this.url = url;
        this.pictures = pictures;
        this.player = player;
    }

    public Picture() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Set<Team> getPictures() {
        return pictures;
    }

    public void setPictures(Set<Team> pictures) {
        this.pictures = pictures;
    }

    public Set<Player> getPlayer() {
        return player;
    }

    public void setPlayer(Set<Player> player) {
        this.player = player;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Picture)) return false;
        Picture picture = (Picture) o;
        return id.equals(picture.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
