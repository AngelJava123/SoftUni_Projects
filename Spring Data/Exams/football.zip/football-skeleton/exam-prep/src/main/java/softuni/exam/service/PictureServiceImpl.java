package softuni.exam.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.domain.dto.ImportPicturesDto;
import softuni.exam.domain.dto.PictureNameDto;
import softuni.exam.domain.entities.Picture;
import softuni.exam.repository.PictureRepository;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.stream.Collectors;


@Service
public class PictureServiceImpl implements PictureService {

    private final Path path =
            Path.of("src", "main", "resources", "files", "xml", "pictures.xml");

    private final PictureRepository pictureRepository;
    private final Unmarshaller unmarshaller;
    private final ModelMapper modelMapper;
    private final javax.validation.Validator validator;

    @Autowired
    public PictureServiceImpl(PictureRepository pictureRepository) throws JAXBException {
        this.pictureRepository = pictureRepository;

        JAXBContext jaxbContext = JAXBContext.newInstance(ImportPicturesDto.class);
        this.unmarshaller = jaxbContext.createUnmarshaller();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public String importPictures() throws FileNotFoundException, JAXBException {

        ImportPicturesDto picturesDto = (ImportPicturesDto) this.unmarshaller.unmarshal(
                new FileReader(path.toAbsolutePath().toString()));

        return picturesDto
                .getPictures()
                .stream()
                .map(this::importPicture)
                .collect(Collectors.joining("\n"));
    }

    private String importPicture(PictureNameDto pictureNameDto) {
        Set<ConstraintViolation<PictureNameDto>> errors =
                this.validator.validate(pictureNameDto);

        if (!errors.isEmpty()) {
            return "Invalid picture";
        }

        Picture picture = this.modelMapper.map(pictureNameDto, Picture.class);

        this.pictureRepository.save(picture);

        return "Successfully imported picture " + picture;
    }

    @Override
    public boolean areImported() {
        return this.pictureRepository.count() > 0;
    }

    @Override
    public String readPicturesXmlFile() throws IOException {
        return Files.readString(path);
    }
}
