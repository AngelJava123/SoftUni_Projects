package exam.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import exam.model.dto.ImportCustomersDto;
import exam.model.dto.ImportLaptopsDto;
import exam.model.entities.Customer;
import exam.model.entities.Laptop;
import exam.model.entities.Shop;
import exam.model.entities.Town;
import exam.repository.LaptopRepository;
import exam.repository.ShopRepository;
import exam.service.LaptopService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class LaptopServiceImpl implements LaptopService {
    private final Path path = Path.of("src\\main\\resources\\files\\json\\laptops.json");

    private final LaptopRepository laptopRepository;
    private final ShopRepository shopRepository;
    private final Gson gson;
    private final Validator validator;
    private final ModelMapper modelMapper;

    public LaptopServiceImpl(LaptopRepository laptopRepository, ShopRepository shopRepository) {
        this.laptopRepository = laptopRepository;
        this.shopRepository = shopRepository;

        this.gson = new GsonBuilder()
                .setPrettyPrinting()
                .create();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.laptopRepository.count() > 0;
    }

    @Override
    public String readLaptopsFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importLaptops() throws IOException {
        String json = this.readLaptopsFileContent();

        ImportLaptopsDto[] laptopsDtos = this.gson.fromJson(json, ImportLaptopsDto[].class);

        return Arrays.stream(laptopsDtos)
                .map(this::importLaptop)
                .collect(Collectors.joining("\n"));
    }

    private String importLaptop(ImportLaptopsDto importLaptopsDto) {
        Set<ConstraintViolation<ImportLaptopsDto>> errors =
                this.validator.validate(importLaptopsDto);

        if (!errors.isEmpty()) {
            return "Invalid Laptop";
        }

        Optional<Laptop> customerOptional = this.laptopRepository.findByMacAddress(importLaptopsDto.getMacAddress());

        if (customerOptional.isPresent()) {
            return "Invalid Laptop";
        }

        Optional<Shop> shopOptional = this.shopRepository.findByName(importLaptopsDto.getShop().getName());

        Laptop laptop = this.modelMapper.map(importLaptopsDto, Laptop.class);

        laptop.setShop(shopOptional.get());

        this.laptopRepository.save(laptop);

        return "Successfully imported Laptop " + laptop.getMacAddress() + " - "
                + String.format("%,2f", laptop.getCpuSpeed()) + " - " + laptop.getRam() + " - " + laptop.getStorage();
    }

    @Override
    @Transactional
    public String exportBestLaptops() {

        List<Laptop> laptopList = this.laptopRepository.findAllOrdered();

        StringBuilder builder = new StringBuilder();

        for (Laptop laptop : laptopList) {
            builder.append("Laptop - ").append(laptop.getMacAddress()).append(System.lineSeparator())
                    .append("*Cpu speed - ").append(String.format("%.2f", laptop.getCpuSpeed())).append(System.lineSeparator())
                    .append("**Ram - ").append(laptop.getRam()).append(System.lineSeparator())
                    .append("***Storage - ").append(laptop.getStorage()).append(System.lineSeparator())
                    .append("****Price - ").append(String.format("%.2f", laptop.getPrice())).append(System.lineSeparator())
                    .append("#Shop name - ").append(laptop.getShop().getName()).append(System.lineSeparator())
                    .append("##Town - ").append(laptop.getShop().getTown().getName()).append(System.lineSeparator());
            builder.append(System.lineSeparator());
        }
        return builder.toString().trim();
    }
}
