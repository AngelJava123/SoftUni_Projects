package exam.service.impl;

import exam.model.dto.ImportShopsDto;
import exam.model.dto.ShopData;
import exam.model.entities.Shop;
import exam.model.entities.Town;
import exam.repository.ShopRepository;
import exam.repository.TownRepository;
import exam.service.ShopService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ShopServiceImpl implements ShopService {
    private final Path path = Path.of("src\\main\\resources\\files\\xml\\shops.xml");

    private final ShopRepository shopRepository;
    private final TownRepository townRepository;
    private final Unmarshaller unmarshaller;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public ShopServiceImpl(ShopRepository shopRepository, TownRepository townRepository) throws JAXBException {
        this.shopRepository = shopRepository;
        this.townRepository = townRepository;

        JAXBContext context = JAXBContext.newInstance(ImportShopsDto.class);
        this.unmarshaller = context.createUnmarshaller();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.shopRepository.count() > 0;
    }

    @Override
    public String readShopsFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importShops() throws JAXBException, FileNotFoundException {
        ImportShopsDto shopsDto = (ImportShopsDto) this.unmarshaller.unmarshal(
                new FileReader(path.toAbsolutePath().toString()));

        return shopsDto
                .getShops()
                .stream()
                .map(this::importShop)
                .collect(Collectors.joining("\n"));
    }

    private String importShop(ShopData shopData) {
        Set<ConstraintViolation<ShopData>> errors =
                this.validator.validate(shopData);

        if (!errors.isEmpty()) {
            return "Invalid shop";
        }

        Optional<Shop> shopOptional = this.shopRepository.findByName(shopData.getName());

        if (shopOptional.isPresent()) {
            return "Invalid shop";
        }

        Optional<Town> townOptional = this.townRepository.findByName(shopData.getTownName().getName());

        Shop shop = this.modelMapper.map(shopData, Shop.class);

        shop.setTown(townOptional.get());

        this.shopRepository.save(shop);

        return "Successfully imported Shop " + shop.getName() + " - " + shop.getIncome();
    }
}
