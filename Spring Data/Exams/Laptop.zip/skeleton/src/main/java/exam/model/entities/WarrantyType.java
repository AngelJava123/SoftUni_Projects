package exam.model.entities;

public enum WarrantyType {
    BASIC, PREMIUM, LIFETIME
}
