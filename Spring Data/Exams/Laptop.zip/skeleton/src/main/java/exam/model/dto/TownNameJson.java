package exam.model.dto;

public class TownNameJson {

    private String name;

    public TownNameJson() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
