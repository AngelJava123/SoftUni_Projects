package exam.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import exam.model.dto.ImportCustomersDto;
import exam.model.entities.Customer;
import exam.model.entities.Town;
import exam.repository.CustomerRepository;
import exam.repository.TownRepository;
import exam.service.CustomerService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {
    private final Path path = Path.of("src\\main\\resources\\files\\json\\customers.json");

    private final CustomerRepository customerRepository;
    private final TownRepository townRepository;
    private final Gson gson;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository, TownRepository townRepository) {
        this.customerRepository = customerRepository;
        this.townRepository = townRepository;

        this.gson = new GsonBuilder()
                .setDateFormat("dd/MM/yyyy")
                .setPrettyPrinting()
                .create();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.customerRepository.count() > 0;
    }

    @Override
    public String readCustomersFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importCustomers() throws IOException {
        String json = this.readCustomersFileContent();

        ImportCustomersDto[] customersDtos = this.gson.fromJson(json, ImportCustomersDto[].class);

        return Arrays.stream(customersDtos)
                .map(this::importCustomer)
                .collect(Collectors.joining("\n"));
    }

    private String importCustomer(ImportCustomersDto importCustomersDto) {
        Set<ConstraintViolation<ImportCustomersDto>> errors =
                this.validator.validate(importCustomersDto);

        if (!errors.isEmpty()) {
            return "Invalid Customer";
        }

        Optional<Customer> customerOptional = this.customerRepository.findByEmail(importCustomersDto.getEmail());

        if (customerOptional.isPresent()) {
            return "Invalid Customer";
        }

        Optional<Town> townOptional = this.townRepository.findByName(importCustomersDto.getTown().getName());

        Customer customer = this.modelMapper.map(importCustomersDto, Customer.class);

        customer.setTown(townOptional.get());

        this.customerRepository.save(customer);

        return "Successfully imported Customer " + customer.getFirstName() + " " + customer.getLastName()
                + " - " + customer.getEmail();
    }
}
