package softuni.exam.instagraphlite.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.instagraphlite.models.dto.ImportUsersDto;
import softuni.exam.instagraphlite.models.entities.Picture;
import softuni.exam.instagraphlite.models.entities.User;
import softuni.exam.instagraphlite.repository.PictureRepository;
import softuni.exam.instagraphlite.repository.UserRepository;
import softuni.exam.instagraphlite.service.UserService;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private final Path path = Path.of("src\\main\\resources\\files\\users.json");

    private final UserRepository userRepository;
    private final PictureRepository pictureRepository;
    private final Gson gson;
    private final Validator validator;
    private final ModelMapper modelMapper;

    public UserServiceImpl(UserRepository userRepository, PictureRepository pictureRepository) {
        this.userRepository = userRepository;
        this.pictureRepository = pictureRepository;

        this.gson = new GsonBuilder()
                .setPrettyPrinting()
                .create();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.userRepository.count() > 0;
    }

    @Override
    public String readFromFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importUsers() throws IOException {
        String json = this.readFromFileContent();

        ImportUsersDto[] usersDtos = this.gson.fromJson(json, ImportUsersDto[].class);

        return Arrays.stream(usersDtos)
                .map(this::importUser)
                .collect(Collectors.joining("\n"));
    }

    private String importUser(ImportUsersDto importUsersDto) {
        Set<ConstraintViolation<ImportUsersDto>> errors =
                this.validator.validate(importUsersDto);

        if (!errors.isEmpty()) {
            return "Invalid User";
        }

        Optional<User> userOptional = this.userRepository.findByUsername(importUsersDto.getUsername());

        if (userOptional.isPresent()) {
            return "Invalid User";
        }

        Optional<Picture> pictureOptional = this.pictureRepository.findByPath(importUsersDto.getProfilePicture());

        if (pictureOptional.isEmpty()) {
            return "Invalid User";
        }

        User user = this.modelMapper.map(importUsersDto, User.class);

        user.setPicture(pictureOptional.get());

        this.userRepository.save(user);

        return "Successfully imported User: " + user.getUsername();

    }

    @Override
    @Transactional
    public String exportUsersWithTheirPosts() {

        List<User> userList = this.userRepository.findAllUsers();

        StringBuilder builder = new StringBuilder();

        for (User user : userList) {
            builder.append(user.toString()).append(System.lineSeparator());
        }
        return builder.toString();
    }
}
