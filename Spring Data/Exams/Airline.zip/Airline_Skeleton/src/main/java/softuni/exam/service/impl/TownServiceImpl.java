package softuni.exam.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ImportTownsDto;
import softuni.exam.models.entities.Town;
import softuni.exam.repository.TownRepository;
import softuni.exam.service.TownService;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class TownServiceImpl implements TownService {
    private final Path path = Path.of("src\\main\\resources\\files\\json\\towns.json");

    private final TownRepository townRepository;
    private final Gson gson;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public TownServiceImpl(TownRepository townRepository) {
        this.townRepository = townRepository;

        this.gson = new GsonBuilder()
                .setPrettyPrinting()
                .create();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.townRepository.count() > 0;
    }

    @Override
    public String readTownsFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importTowns() throws IOException {
        String json = this.readTownsFileContent();

        ImportTownsDto[] townsDtos = this.gson.fromJson(json, ImportTownsDto[].class);

        return Arrays.stream(townsDtos)
                .map(this::importTown)
                .collect(Collectors.joining("\n"));
    }

    private String importTown(ImportTownsDto importTownsDto) {
        Set<ConstraintViolation<ImportTownsDto>> errors =
                this.validator.validate(importTownsDto);

        if (!errors.isEmpty()) {
            return "Invalid Town";
        }

        Optional<Town> townOptional = this.townRepository.findByName(importTownsDto.getName());

        if (townOptional.isPresent()) {
            return "Invalid Town";
        }

        Town town = this.modelMapper.map(importTownsDto, Town.class);
        this.townRepository.save(town);

        return "Successfully imported Town " + town.getName() + " - " + town.getPopulation();
    }
}
