package softuni.exam.models.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "planes")
@XmlAccessorType(XmlAccessType.FIELD)
public class ImportPlanesDto {

    @XmlElement(name = "plane")
    private List<PlaneDataDto> planes;

    public ImportPlanesDto() {
    }

    public List<PlaneDataDto> getPlanes() {
        return planes;
    }

    public void setPlanes(List<PlaneDataDto> planes) {
        this.planes = planes;
    }
}
