package softuni.exam.models.entities;

import javax.persistence.*;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "towns")
public class Town {

    @Id
    @GeneratedValue
    private Integer id;

    private String name;

    private Integer population;

    @Column(columnDefinition = "TEXT")
    private String guide;

    @OneToMany(mappedBy = "towns")
    private Set<Passenger> passenger;

    @OneToMany(mappedBy = "fromTown")
    private Set<Ticket> ticket;

    @OneToMany(mappedBy = "toTown")
    private Set<Ticket> ticket2;

    public Town() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPopulation() {
        return population;
    }

    public void setPopulation(Integer population) {
        this.population = population;
    }

    public String getGuide() {
        return guide;
    }

    public void setGuide(String guide) {
        this.guide = guide;
    }

    public Set<Passenger> getPassenger() {
        return passenger;
    }

    public void setPassenger(Set<Passenger> passenger) {
        this.passenger = passenger;
    }

    public Set<Ticket> getTicket() {
        return ticket;
    }

    public void setTicket(Set<Ticket> ticket) {
        this.ticket = ticket;
    }

    public Set<Ticket> getTicket2() {
        return ticket2;
    }

    public void setTicket2(Set<Ticket> ticket2) {
        this.ticket2 = ticket2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Town)) return false;
        Town town = (Town) o;
        return Objects.equals(id, town.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
