package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ImportPlanesDto;
import softuni.exam.models.dto.PlaneDataDto;
import softuni.exam.models.entities.Plane;
import softuni.exam.repository.PlaneRepository;
import softuni.exam.service.PlaneService;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class PlaneServiceImpl implements PlaneService {
    private final Path path = Path.of("src\\main\\resources\\files\\xml\\planes.xml");

    private final PlaneRepository planeRepository;
    private final Unmarshaller unmarshaller;
    private final Validator validator;
    private final ModelMapper modelMapper;

    public PlaneServiceImpl(PlaneRepository planeRepository) throws JAXBException {
        this.planeRepository = planeRepository;

        JAXBContext context = JAXBContext.newInstance(ImportPlanesDto.class);
        this.unmarshaller = context.createUnmarshaller();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.planeRepository.count() > 0;
    }

    @Override
    public String readPlanesFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importPlanes() throws FileNotFoundException, JAXBException {
        ImportPlanesDto planesDto = (ImportPlanesDto) this.unmarshaller.unmarshal(
                new FileReader(path.toAbsolutePath().toString()));

        return planesDto
                .getPlanes()
                .stream()
                .map(this::importPlane)
                .collect(Collectors.joining("\n"));
    }

    private String importPlane(PlaneDataDto planeDataDto) {
        Set<ConstraintViolation<PlaneDataDto>> errors =
                this.validator.validate(planeDataDto);

        if (!errors.isEmpty()) {
            return "Invalid Plane";
        }

        Optional<Plane> optionalPlane = this.planeRepository.findByRegisterNumber(planeDataDto.getRegisterNumber());

        if (optionalPlane.isPresent()) {
            return "Invalid Plane";
        }

        Plane plane = this.modelMapper.map(planeDataDto, Plane.class);

        this.planeRepository.save(plane);

        return "Successfully imported Plane " + plane.getRegisterNumber();
    }
}
