package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ImportTicketsDto;
import softuni.exam.models.dto.TicketDataDto;
import softuni.exam.models.entities.Passenger;
import softuni.exam.models.entities.Plane;
import softuni.exam.models.entities.Ticket;
import softuni.exam.models.entities.Town;
import softuni.exam.repository.PassengerRepository;
import softuni.exam.repository.PlaneRepository;
import softuni.exam.repository.TicketRepository;
import softuni.exam.repository.TownRepository;
import softuni.exam.service.TicketService;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class TicketServiceImpl implements TicketService {
    private final Path path = Path.of("src\\main\\resources\\files\\xml\\tickets.xml");

    private final TicketRepository ticketRepository;
    private final TownRepository townRepository;
    private final PassengerRepository passengerRepository;
    private final PlaneRepository planeRepository;
    private final Unmarshaller unmarshaller;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public TicketServiceImpl(TicketRepository ticketRepository, TownRepository townRepository, PassengerRepository passengerRepository, PlaneRepository planeRepository) throws JAXBException {
        this.ticketRepository = ticketRepository;
        this.townRepository = townRepository;
        this.passengerRepository = passengerRepository;
        this.planeRepository = planeRepository;

        JAXBContext context = JAXBContext.newInstance(ImportTicketsDto.class);
        this.unmarshaller = context.createUnmarshaller();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();

        this.modelMapper.addConverter(ctx -> LocalDateTime.parse(ctx.getSource(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                String.class, LocalDateTime.class);
    }

    @Override
    public boolean areImported() {
        return this.ticketRepository.count() > 0;
    }

    @Override
    public String readTicketsFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importTickets() throws FileNotFoundException, JAXBException {
        ImportTicketsDto ticketsDto = (ImportTicketsDto) this.unmarshaller.unmarshal(
                new FileReader(path.toAbsolutePath().toString()));

        return ticketsDto
                .getTickets()
                .stream()
                .map(this::importTicket)
                .collect(Collectors.joining("\n"));
    }

    private String importTicket(TicketDataDto ticketDataDto) {
        Set<ConstraintViolation<TicketDataDto>> errors =
                this.validator.validate(ticketDataDto);

        if (!errors.isEmpty()) {
            return "Invalid Ticket";
        }

        Optional<Town> fromTown = this.townRepository.findByName(ticketDataDto.getFromTown().getName());
        Optional<Town> toTown = this.townRepository.findByName(ticketDataDto.getToTown().getName());
        Optional<Passenger> passenger = this.passengerRepository.findByEmail(ticketDataDto.getPassengers().getEmail());
        Optional<Plane> plane = this.planeRepository.findByRegisterNumber(ticketDataDto.getPlane().getRegisterNumber());

        Ticket ticket = this.modelMapper.map(ticketDataDto, Ticket.class);

        ticket.setFromTown(fromTown.get());
        ticket.setToTown(toTown.get());
        ticket.setPassengers(passenger.get());
        ticket.setPlane(plane.get());

        this.ticketRepository.save(ticket);

        return "Successfully imported Ticket " + ticket.getFromTown() + " - " + ticket.getToTown();
    }
}
