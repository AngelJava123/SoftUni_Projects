package softuni.exam.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ImportPassengersDto;
import softuni.exam.models.entities.Passenger;
import softuni.exam.models.entities.Town;
import softuni.exam.repository.PassengerRepository;
import softuni.exam.repository.TownRepository;
import softuni.exam.service.PassengerService;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class PassengerServiceImpl implements PassengerService {
    private final Path path = Path.of("src\\main\\resources\\files\\json\\passengers.json");

    private final PassengerRepository passengerRepository;
    private final TownRepository townRepository;
    private final Gson gson;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public PassengerServiceImpl(PassengerRepository passengerRepository, TownRepository townRepository) {
        this.passengerRepository = passengerRepository;
        this.townRepository = townRepository;
        this.gson = new GsonBuilder()
                .setPrettyPrinting()
                .create();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.passengerRepository.count() > 0;
    }

    @Override
    public String readPassengersFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importPassengers() throws IOException {
        String json = this.readPassengersFileContent();

        ImportPassengersDto[] passengersDtos = this.gson.fromJson(json, ImportPassengersDto[].class);

        return Arrays.stream(passengersDtos)
                .map(this::importPassenger)
                .collect(Collectors.joining("\n"));
    }

    private String importPassenger(ImportPassengersDto importPassengersDto) {
        Set<ConstraintViolation<ImportPassengersDto>> errors =
                this.validator.validate(importPassengersDto);

        if (!errors.isEmpty()) {
            return "Invalid Passenger";
        }

        Optional<Passenger> passengerOptional = this.passengerRepository.findByEmail(importPassengersDto.getEmail());

        if (passengerOptional.isPresent()) {
            return "Invalid Passenger";
        }

        Optional<Town> town = this.townRepository.findByName(importPassengersDto.getTown());

        Passenger passenger = this.modelMapper.map(importPassengersDto, Passenger.class);

        passenger.setTowns(town.get());

        this.passengerRepository.save(passenger);

        return "Successfully imported Passenger " + passenger.getLastName() + " - " + passenger.getEmail();
    }

    @Override
    @Transactional
    public String getPassengersOrderByTicketsCountDescendingThenByEmail() {

        List<Passenger> passengerList = this.passengerRepository.findPassengersOrderByTicketsCountDescendingThenByEmail();

        StringBuilder builder = new StringBuilder();

        for (Passenger passenger : passengerList) {
            builder.append(passenger.toString()).append(System.lineSeparator());
        }

        return builder.toString().trim();
    }
}
