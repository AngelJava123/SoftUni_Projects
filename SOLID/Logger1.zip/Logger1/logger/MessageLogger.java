package Logger1.logger;

public class MessageLogger extends AbstractLogger {

}
