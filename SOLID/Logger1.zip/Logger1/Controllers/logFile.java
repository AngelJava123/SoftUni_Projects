package Logger1.Controllers;

import Logger1.interfaces.File;

public class logFile implements File {
    private StringBuilder builder;

    public logFile() {
        this.builder = new StringBuilder();
    }

    @Override
    public void write(String text) {
        this.builder.append(text);
    }

    @Override
    public int getSize() {
        int sum = 0;

        for (int i = 0; i < this.builder.length(); i++) {
           char symbol = this.builder.charAt(i);
           if (Character.isAlphabetic(symbol)) {
               sum += symbol;
           }
        }
        return sum;
    }
}
