package Logger1.enums;

public enum ReportLevel {
    INFO,
    WARNING,
    ERROR,
    CRITICAL,
    FATAL;
}
