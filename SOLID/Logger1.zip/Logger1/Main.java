package Logger1;

import Logger1.Controllers.AppenderWorkshop;
import Logger1.Controllers.LayoutWorkshop;
import Logger1.enums.ReportLevel;
import Logger1.interfaces.Appender;
import Logger1.interfaces.AppenderFactory;
import Logger1.interfaces.LayoutFactory;
import Logger1.logger.Logger;
import Logger1.logger.MessageLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int n = Integer.parseInt(reader.readLine());

        AppenderFactory appenderFactory = new AppenderWorkshop();
        LayoutFactory layoutFactory = new LayoutWorkshop();

        Logger logger = new MessageLogger();

        while (n-- > 0) {
            String[] tokens = reader.readLine().split("\\s+");

            ReportLevel reportLevel = tokens.length == 3
                    ? ReportLevel.valueOf(tokens[2].toUpperCase())
                    : ReportLevel.INFO;

            Appender appender = appenderFactory.produce(tokens[0], reportLevel, layoutFactory.produce(tokens[1]));

            logger.addAppender(appender);
        }

        String input = reader.readLine();

        while (!input.equals("END")) {

            String[] tokens = input.split("\\|");

            ReportLevel reportLevel = ReportLevel.valueOf(tokens[0]);
            String date = tokens[1];
            String message = tokens[2];

            switch (reportLevel) {
                case INFO -> logger.logInfo(date, message);
                case WARNING -> logger.logWarning(date, message);
                case ERROR -> logger.logError(date, message);
                case CRITICAL -> logger.logCritical(date, message);
                case FATAL -> logger.logFatal(date, message);
                default -> throw new IllegalStateException("Unknown enum value for " + reportLevel);
            }

            input = reader.readLine();
        }

        System.out.println(logger.toString());
    }
}
