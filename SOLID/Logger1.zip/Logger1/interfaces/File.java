package Logger1.interfaces;

public interface File {
    void write(String text);
    int getSize();
}
