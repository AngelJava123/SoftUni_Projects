package Logger1.interfaces;

public interface LayoutFactory {
    Layout produce(String type);
}
