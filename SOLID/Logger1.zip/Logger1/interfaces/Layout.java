package Logger1.interfaces;

import Logger1.enums.ReportLevel;

public interface Layout {
    String format(String fata, ReportLevel reportLevel, String message);
    String getType();
}
