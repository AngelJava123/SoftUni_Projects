package Vehicles2;

import java.text.DecimalFormat;

public class Car extends Vehicle {

    public Car(Double fuelQuantity, Double fuelConsumption) {
        super(fuelQuantity, fuelConsumption + 0.9);
    }

    @Override
    public String drive(Double distanceToTravel) {
        if (fuelConsumption * distanceToTravel < fuelQuantity) {
            fuelQuantity -= fuelConsumption * distanceToTravel;
            String s = distanceToTravel.toString();
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String result = decimalFormat.format(Double.valueOf(s));
            return "Car travelled " + result + " km";
        }
        return "Car needs refueling";
    }

    @Override
    public void refuel(Double refuelQuantity) {
        fuelQuantity += refuelQuantity;
    }

    @Override
    public Double getFuelQuantity() {
        return fuelQuantity;
    }
}
