package Vehicles2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] car = reader.readLine().split(" ");
        String[] truck = reader.readLine().split(" ");
        //String[] bus = reader.readLine().split(" ");

        Double fuelCar = Double.parseDouble(car[1]);
        Double littersCar = Double.parseDouble(car[2]);
        // Double tankCar = Double.parseDouble(car[3]);

        Double fuelTruck = Double.parseDouble(truck[1]);
        Double littersTruck = Double.parseDouble(truck[2]);
        // Double tankTruck = Double.parseDouble(truck[3]);

        //  Double fuelBus = Double.parseDouble(bus[1]);
        //  Double littersBus = Double.parseDouble(bus[2]);
        //  Double tankBus = Double.parseDouble(bus[3]);

        Vehicle vehicle = new Car(fuelCar, littersCar);
        Vehicle vehicle1 = new Truck(fuelTruck, littersTruck);
        //Vehicle vehicle2 = new Bus(fuelBus, littersBus);

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            String[] data = reader.readLine().split(" ");

            String commandType = data[0];
            String vehicleType = data[1];
            Double fuel = Double.parseDouble(data[2]);

            if (commandType.equals("Drive")) {
                if (vehicleType.equals("Car")) {
                    System.out.println(vehicle.drive(fuel));
                } else if (vehicleType.equals("Truck")) {
                    System.out.println(vehicle1.drive(fuel));
                }
            } else if (commandType.equals("Refuel")) {
                if (vehicleType.equals("Car")) {
                    vehicle.refuel(fuel);
                } else if (vehicleType.equals("Truck")) {
                    vehicle1.refuel(fuel);
                }
            }
        }
        System.out.printf("Car: %.2f%n", vehicle.getFuelQuantity());
        System.out.printf("Truck: %.2f", vehicle1.getFuelQuantity());
    }
}
