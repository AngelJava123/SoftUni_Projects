package Vehicles2;

abstract class Vehicle {
    Double fuelQuantity;
    Double fuelConsumption;

    public Vehicle(Double fuelQuantity, Double fuelConsumption) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
    }

    String drive(Double distanceToTravel) {
        return null;
    }

    void refuel(Double refuelQuantity) {
    }

    Double getFuelQuantity() {
        return null;
    }
}
