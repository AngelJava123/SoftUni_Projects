package Vehicles;

public interface Vehicle {
    String drive(Double distanceToTravel);
    void refuel(Double refuelQuantity);
    Double getFuelQuantity();
}
