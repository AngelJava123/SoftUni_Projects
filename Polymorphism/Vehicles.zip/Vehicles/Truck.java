package Vehicles;

import java.text.DecimalFormat;

public class Truck implements Vehicle{
    private Double fuelQuantity;
    private Double fuelConsumption;

    public Truck(Double fuelQuantity, Double fuelConsumption) {
        setFuelQuantity(fuelQuantity);
        setFuelConsumption(fuelConsumption);
    }

    public void setFuelQuantity(Double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    public void setFuelConsumption(Double fuelConsumption) {
        this.fuelConsumption = fuelConsumption + 1.6;
    }

    @Override
    public String drive(Double distanceToTravel) {
        if (fuelConsumption * distanceToTravel < fuelQuantity) {
            fuelQuantity -= fuelConsumption * distanceToTravel;
            String s = distanceToTravel.toString();
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String result = decimalFormat.format(Double.valueOf(s));
            return "Truck travelled " + result + " km";
        }
        return "Truck needs refueling";
    }

    @Override
    public void refuel(Double refuelQuantity) {
        fuelQuantity += (refuelQuantity * 95) / 100;
    }

    public Double getFuelQuantity() {
        return fuelQuantity;
    }
}
