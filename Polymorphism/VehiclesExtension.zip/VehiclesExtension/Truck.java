package VehiclesExtension;

import java.text.DecimalFormat;

public class Truck extends Vehicle {

    public Truck(double fuelQuantity, double fuelConsumption, double tankTruck) {
        super(fuelQuantity, fuelConsumption + 1.6, tankTruck);
    }

    @Override
    public String drive(double distanceToTravel) {
        if (fuelConsumption * distanceToTravel < fuelQuantity) {
            fuelQuantity -= fuelConsumption * distanceToTravel;
            String s = String.valueOf(distanceToTravel);
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String result = decimalFormat.format(Double.valueOf(s));
            return "Truck travelled " + result + " km";
        }
        return "Truck needs refueling";
    }

    @Override
    public void refuel(double refuelQuantity) {
        fuelQuantity += (refuelQuantity * 95) / 100;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }
}
