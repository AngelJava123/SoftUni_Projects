package VehiclesExtension;

import java.text.DecimalFormat;

public class Bus extends Vehicle{
    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity);
    }

    @Override
    public String drive(double distanceToTravel) {
        if (fuelConsumption * distanceToTravel < fuelQuantity) {
            fuelQuantity -= fuelConsumption * distanceToTravel;
            String s = String.valueOf(distanceToTravel);
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String result = decimalFormat.format(Double.valueOf(s));
            return "Bus travelled " + result + " km";
        }
        return "Bus needs refueling";
    }

    @Override
    public void refuel(double refuelQuantity) {
        fuelQuantity += refuelQuantity;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }
}
