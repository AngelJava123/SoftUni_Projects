package VehiclesExtension;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] car = reader.readLine().split(" ");
        String[] truck = reader.readLine().split(" ");
        String[] bus = reader.readLine().split(" ");

        double fuelCar = Double.parseDouble(car[1]);
        double littersCar = Double.parseDouble(car[2]);
        double tankCar = Double.parseDouble(car[3]);

        double fuelTruck = Double.parseDouble(truck[1]);
        double littersTruck = Double.parseDouble(truck[2]);
        double tankTruck = Double.parseDouble(truck[3]);

        double fuelBus = Double.parseDouble(bus[1]);
        double littersBus = Double.parseDouble(bus[2]);
        double tankBus = Double.parseDouble(bus[3]);

        Vehicle vehicle = new Car(fuelCar, littersCar, tankCar);
        Vehicle vehicle1 = new Truck(fuelTruck, littersTruck, tankTruck);
        Vehicle vehicle2 = new Bus(fuelBus, littersBus, tankBus);

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            String[] data = reader.readLine().split(" ");

            String commandType = data[0];
            String vehicleType = data[1];
            double fuel = Double.parseDouble(data[2]);

            if (commandType.equals("Drive")) {
                if (vehicleType.equals("Car")) {
                    System.out.println(vehicle.drive(fuel));
                } else if (vehicleType.equals("Truck")) {
                    System.out.println(vehicle1.drive(fuel));
                } else if (vehicleType.equals("Bus")) {
                    vehicle2.setFuelConsumption(vehicle2.fuelConsumption + 1.4);
                    System.out.println(vehicle2.drive(fuel));
                    vehicle2.setFuelConsumption(vehicle2.fuelConsumption - 1.4);
                }
            } else if (commandType.equals("Refuel")) {
                if (fuel <= 0) {
                    System.out.println("Fuel must be a positive number");
                    continue;
                }
                if (vehicleType.equals("Car")) {
                    if (fuel > vehicle.getTankCapacity()) {
                        System.out.println("Cannot fit fuel in tank");
                    } else {
                        vehicle.refuel(fuel);
                    }
                } else if (vehicleType.equals("Truck")) {
                    if (fuel > vehicle1.getTankCapacity()) {
                        System.out.println("Cannot fit fuel in tank");
                    } else {
                        vehicle1.refuel(fuel);
                    }
                } else if (vehicleType.equals("Bus")) {
                    if (fuel > vehicle2.getTankCapacity()) {
                        System.out.println("Cannot fit fuel in tank");
                    } else {
                        vehicle2.refuel(fuel);
                    }
                }
            } else if (commandType.equals("DriveEmpty")) {
                System.out.println(vehicle2.drive(fuel));
            }
        }
        System.out.printf("Car: %.2f%n", vehicle.getFuelQuantity());
        System.out.printf("Truck: %.2f%n", vehicle1.getFuelQuantity());
        System.out.printf("Bus: %.2f", vehicle2.getFuelQuantity());
    }
}
