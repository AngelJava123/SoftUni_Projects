package VehiclesExtension;

import java.text.DecimalFormat;

public class Car extends Vehicle {

    public Car(double fuelQuantity, double fuelConsumption, double tankCar) {
        super(fuelQuantity, fuelConsumption + 0.9, tankCar);
    }

    @Override
    public String drive(double distanceToTravel) {
        if (fuelConsumption * distanceToTravel < fuelQuantity) {
            fuelQuantity -= fuelConsumption * distanceToTravel;
            String s = String.valueOf(distanceToTravel);
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String result = decimalFormat.format(Double.valueOf(s));
            return "Car travelled " + result + " km";
        }
        return "Car needs refueling";
    }

    @Override
    public void refuel(double refuelQuantity) {
        fuelQuantity += refuelQuantity;
    }

    @Override
    public double getFuelQuantity() {
        return fuelQuantity;
    }
}
