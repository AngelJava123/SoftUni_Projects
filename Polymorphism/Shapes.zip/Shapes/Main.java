package Shapes;

public class Main {
    public static void main(String[] args) {
        Shape shape = new Rectangle(20.4, 13.1);
        Shape shape1 = new Circle(12.3);


    }
}
