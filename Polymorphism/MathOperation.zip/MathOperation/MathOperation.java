package MathOperation;

public class MathOperation {


    public int add(int one, int two) {
        return one + two;
    }

    public int add(int one, int two, int three) {
        return add(add(one, two), three);
    }

    public int add(int one, int two, int three, int four) {
        return add(add(one, two, three), four);
    }
}
