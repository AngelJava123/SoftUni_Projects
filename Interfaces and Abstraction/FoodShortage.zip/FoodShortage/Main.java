package FoodShortage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int n = Integer.parseInt(reader.readLine());

        Map<String, Buyer> people = new HashMap<>();

        while (n-- > 0) {
            String[] input = reader.readLine().split(" ");

            if (input.length == 4) {
                String name = input[0];
                int age = Integer.parseInt(input[1]);
                String id = input[2];
                String birthDate = input[3];

                Citizen citizen = new Citizen(name, age, id, birthDate);
                people.put(name, citizen);
            } else if (input.length == 3) {
                String name = input[0];
                int age = Integer.parseInt(input[1]);
                String group = input[2];

                Rebel rebel = new Rebel(name, age, group);
                people.put(name, rebel);
            }
        }
        String name = reader.readLine();
        while (!name.equals("End")) {

            if (people.containsKey(name)) {
                people.get(name).buyFood();
            }

            name = reader.readLine();
        }
        int totalFood = 0;
        for (Map.Entry<String, Buyer> person : people.entrySet()) {
            totalFood += person.getValue().getFood();
        }
        System.out.println(totalFood);
    }
}
