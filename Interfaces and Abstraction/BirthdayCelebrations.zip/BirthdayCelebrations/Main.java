package BirthdayCelebrations;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Birthable> data = new ArrayList<>();

        String input = reader.readLine();
        while (!input.equals("End")) {

            String[] inputData = input.split(" ");
            String keyWord = inputData[0];

            if (keyWord.equals("Citizen")) {
                String name = inputData[1];
                int age = Integer.parseInt(inputData[2]);
                String id = inputData[3];
                String birthDate = inputData[4];

                Citizen citizen = new Citizen(name, age, id, birthDate);
                data.add(citizen);
            } else if (keyWord.equals("Pet")) {
                String name = inputData[1];
                String birthDate = inputData[2];

                Pet pet = new Pet(name, birthDate);
                data.add(pet);
            }

            input = reader.readLine();
        }

        String year = reader.readLine();

        boolean contains = false;

        for (Birthable birthable: data) {
            if (birthable.getBirthDate().endsWith(year)) {
                System.out.println(birthable.getBirthDate());
                contains = true;
            }
        }
        if (!contains) {
            System.out.println("<no output>");
        }
    }
}
