package CollectionHierarchy;

public interface AddRemovable {
    String remove();
}
