package CollectionHierarchy;

public interface MyList {
    int getUsed();
}
