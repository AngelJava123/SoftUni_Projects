package CollectionHierarchy;

public class AddCollection extends Collection implements Addable {

    @Override
    public int add(String string) {
        items.add(string);
        return this.items.size()-1;
    }
}
