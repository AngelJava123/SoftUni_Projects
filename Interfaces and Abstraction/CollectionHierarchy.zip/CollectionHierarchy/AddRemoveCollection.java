package CollectionHierarchy;

public class AddRemoveCollection extends Collection implements Addable, AddRemovable{

    @Override
    public String remove() {
        return items.remove(items.size()-1);
    }

    @Override
    public int add(String string) {
        items.add(0, string);
        return 0;
    }
}
