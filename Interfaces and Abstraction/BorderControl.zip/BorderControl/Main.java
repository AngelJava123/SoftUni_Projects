package BorderControl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Identifiable> identifiables = new ArrayList<>();

        String command = reader.readLine();
        while (!command.equals("End")) {

            if (command.split(" ").length == 3) {
                String name = command.split(" ")[0];
                int age = Integer.parseInt(command.split(" ")[1]);
                String id = command.split(" ")[2];

                Citizen citizen = new Citizen(name, age, id);
                identifiables.add(citizen);

            } else if (command.split(" ").length == 2) {
                String model = command.split(" ")[0];
                String id = command.split(" ")[1];

                Robot robot = new Robot(model, id);
                identifiables.add(robot);
            }
            command = reader.readLine();
        }

        String lastDigits = reader.readLine();

        for (Identifiable identifiable: identifiables) {
            if (identifiable.getId().endsWith(lastDigits)) {
                System.out.println(identifiable.getId());
            }
        }
    }
}
