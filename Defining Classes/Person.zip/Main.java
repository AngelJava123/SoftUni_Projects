import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Person> personalInfo = new ArrayList<>();

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            String[] input = reader.readLine().split("\\s+");

            String name = input[0];
            int age = Integer.parseInt(input[1]);

            Person person = new Person(name, age);
            personalInfo.add(person);
        }
        Set<String> result = new TreeSet<>();

        for (Person name : personalInfo) {
            if (name.getAge() > 30) {
                result.add(String.format("%s - %d", name.getName(), name.getAge()));
            }
        }
        result.forEach(System.out::println);
    }
}
