package cafe;

import java.util.ArrayList;
import java.util.List;

public class Cafe {
    private String name;
    private int capacity;
    private List<Employee> employees;

    public Cafe(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.employees = new ArrayList<>();
    }

    //•	Method addEmployee(Employee employee) – adds an entity to the data if there is room for him/her.
    public void addEmployee(Employee employee) {
        if (employees.size() < capacity) {
            employees.add(employee);
        }
    }

    //•	Method removeEmployee(String name) – removes an employee by given name, if such exists, and returns bool.
    public boolean removeEmployee(String name) {

        for (Employee employee : employees) {
            if (employee.getName().equals(name)) {
                employees.remove(employee);
                return true;
            }
        }
        return false;
    }

    //•	Method getOldestEmployee() – returns the oldest employee.
    public Employee getOldestEmployee() {
        Employee employee = null;
        int age = Integer.MIN_VALUE;

        for (Employee employee1 : employees) {
            if (employee1.getAge() > age) {
                employee = employee1;
                age = employee1.getAge();
            }
        }
        return employee;
    }

    //•	Method getEmployee(string name) – returns the employee with the given name.
    public Employee getEmployee(String name) {
        Employee employeeToReturn = null;

        for (Employee employee : employees) {
            if (employee.getName().equals(name)) {
                employeeToReturn = employee;
            }
        }
        return employeeToReturn;
    }

    //•	Getter getCount() – returns the number of employees.
    public int getCount() {
        return employees.size();
    }

    public String report() {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("Employees working at Cafe %s:", name)).append(System.lineSeparator());

        for (Employee employee : employees) {
            sb.append(employee).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }
}
