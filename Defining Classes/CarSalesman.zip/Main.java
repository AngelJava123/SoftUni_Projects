import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<CarSalesman> cars = new ArrayList<>();
        Map<String, CarEngine> engines = new LinkedHashMap<>();

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            String[] input = reader.readLine().split("\\s+");

            //Engine: <Model> <Power> <Displacement> <Efficiency>

            String model = input[0];
            String power = input[1];

            if (input.length == 2) {
                engines.put(model, new CarEngine(model, power));
            } else if (input.length == 3) {
                if (Character.isLetter(input[2].charAt(0))) {
                    String efficiency = input[2];
                    engines.put(model, new CarEngine(model, power, efficiency));
                } else {
                    int displacement = Integer.parseInt(input[2]);
                    engines.put(model, new CarEngine(model, power, displacement));
                }
            } else if (input.length == 4) {
                int displacement = Integer.parseInt(input[2]);
                String efficiency = input[3];
                engines.put(model, new CarEngine(model, power, displacement, efficiency));
            }
        }
        int n1 = Integer.parseInt(reader.readLine());
        while (n1-- > 0) {
            String[] input = reader.readLine().split("\\s+");

            String model = input[0];
            String engine = input[1];

            if (input.length == 2) {
                cars.add(new CarSalesman(model, engine));
            } else if (input.length == 3) {
                if (Character.isLetter(input[2].charAt(0))) {
                    String color = input[2];
                    cars.add(new CarSalesman(model, engine, color));
                } else {
                    int weight = Integer.parseInt(input[2]);
                    cars.add(new CarSalesman(model, engine, weight));
                }
            } else if (input.length == 4) {
                int weight = Integer.parseInt(input[2]);
                String color = input[3];
                cars.add(new CarSalesman(model, engine, weight, color));
            }
        }
        for (CarSalesman element: cars) {
            String model = element.getEngine();

            if (engines.containsKey(model)) {
                System.out.println(element.getModel() + ":");
                System.out.println(model + ":");
                System.out.println("Power: " + engines.get(model).getPower());
                if (Objects.equals(engines.get(model).getDisplacement(), String.valueOf(0))) {
                    System.out.println("Displacement: n/a");
                } else {
                    System.out.println("Displacement: " + engines.get(model).getDisplacement());
                }
                System.out.println("Efficiency: " + engines.get(model).getEfficiency());
                if (element.getWeight() == 0) {
                    System.out.println("Weight: n/a");
                } else {
                    System.out.println("Weight: " + element.getWeight());
                }
                System.out.println("Color: " + element.getColor());
            }
        }
    }
}
