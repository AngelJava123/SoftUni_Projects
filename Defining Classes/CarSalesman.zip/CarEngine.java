public class CarEngine {
    private String model;
    private String power;
    private int displacement;
    private String efficiency;

    public CarEngine(String model, String power, int displacement, String efficiency) {
        this.model = model;
        this.power = power;
        this.displacement = displacement;
        this.efficiency = efficiency;
    }

    public CarEngine(String model, String power) {
        this.model = model;
        this.power = power;
        this.displacement = 0;
        this.efficiency = "n/a";
    }

    public CarEngine(String model, String power, String efficiency) {
        this.model = model;
        this.power = power;
        this.efficiency = efficiency;
        this.displacement = 0;
    }
    public CarEngine(String model, String power, int displacement) {
        this.model = model;
        this.power = power;
        this.efficiency = "n/a";
        this.displacement = displacement;
    }


    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getDisplacement() {
        return String.valueOf(displacement);
    }

    public void setDisplacement(String displacement) {
        this.displacement = Integer.parseInt(displacement);
    }

    public String getEfficiency() {
        return efficiency;
    }

    public void setEfficiency(String efficiency) {
        this.efficiency = efficiency;
    }
}
