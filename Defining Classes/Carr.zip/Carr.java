import java.util.List;
import java.util.Map;

public class Carr {
    private String model;
    private double fuelAmount;
    private double fuelCostFor1Km;
    private double distanceTravelled;

    public Carr(String model, double fuelAmount, double fuelCostFor1Km) {
        this.model = model;
        this.fuelAmount = fuelAmount;
        this.fuelCostFor1Km = fuelCostFor1Km;
        this.distanceTravelled = 0;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getFuelAmount() {
        return fuelAmount;
    }

    public void setFuelAmount(double fuelAmount) {
        this.fuelAmount = fuelAmount;
    }

    public double getFuelCostFor1Km() {
        return fuelCostFor1Km;
    }

    public void setFuelCostFor1Km(double fuelCostFor1Km) {
        this.fuelCostFor1Km = fuelCostFor1Km;
    }

    public double getDistanceTravelled() {
        return distanceTravelled;
    }

    public void setDistanceTravelled(double distanceTravelled) {
        this.distanceTravelled = distanceTravelled;
    }
    static void canMove(Map<String, List<Carr>> cars, String model, double amountOfKm) {
        if (cars.get(model).get(0).getFuelCostFor1Km() * amountOfKm <= cars.get(model).get(0).getFuelAmount()) {
            double fuelUsed = cars.get(model).get(0).getFuelAmount() - cars.get(model).get(0).getFuelCostFor1Km() * amountOfKm;
            cars.get(model).get(0).setFuelAmount(fuelUsed);
            double distanceTravelled = cars.get(model).get(0).getDistanceTravelled() + amountOfKm;
            cars.get(model).get(0).setDistanceTravelled(distanceTravelled);
        } else {
            System.out.println("Insufficient fuel for the drive");
        }
    }
}
