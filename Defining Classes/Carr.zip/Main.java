import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Map<String, List<Carr>> cars = new LinkedHashMap<>();

        // input: "<Model> <FuelAmount> <FuelCostFor1km>"

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            String[] input = reader.readLine().split("\\s+");

            String model = input[0];
            double fuelAmount = Double.parseDouble(input[1]);
            double fuelCostFor1Km = Double.parseDouble(input[2]);

            cars.put(model, new ArrayList<>());
            cars.get(model).add(new Carr(model, fuelAmount, fuelCostFor1Km));
        }
        // until End command: "Drive <CarModel> <amountOfKm>"

        String command = reader.readLine();
        while (!command.equals("End")) {

            String[] commandData = command.split("\\s+");

            String model = commandData[1];
            double amountOfKm = Double.parseDouble(commandData[2]);

            Carr.canMove(cars, model, amountOfKm);
            command = reader.readLine();
        }
        cars.forEach((k, v) -> {
            System.out.printf("%s %.2f %.0f%n", k, v.get(0).getFuelAmount(), v.get(0).getDistanceTravelled());
        });
    }
}
