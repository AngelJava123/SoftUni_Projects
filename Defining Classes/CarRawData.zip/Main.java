import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Map<String, CarRawData> fragile = new LinkedHashMap<>();
        Map<String, CarRawData> flammable = new LinkedHashMap<>();

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            String[] input = reader.readLine().split("\\s+");

            String model = input[0];
            int engineSpeed = Integer.parseInt(input[1]);
            int enginePower = Integer.parseInt(input[2]);
            int cargoWeight = Integer.parseInt(input[3]);
            String cargoType = input[4];
            double tirePressure1 = Double.parseDouble(input[5]);
            int tireAge1 = Integer.parseInt(input[6]);
            double tirePressure2 = Double.parseDouble(input[7]);
            int tireAge2 = Integer.parseInt(input[8]);
            double tirePressure3 = Double.parseDouble(input[9]);
            int tireAge3 = Integer.parseInt(input[10]);
            double tirePressure4 = Double.parseDouble(input[11]);
            int tireAge4 = Integer.parseInt(input[12]);
            double tirePressureAvg = (tirePressure1 + tirePressure2 + tirePressure3 + tirePressure4) / 4;

            List<Double> tires = new ArrayList<>(List.of(tirePressure1, tirePressure2, tirePressure3, tirePressure4));
            List<Integer> tireAge = new ArrayList<>(List.of(tireAge1, tireAge2, tireAge3, tireAge4));
            carsParameters(fragile, flammable, model, engineSpeed, enginePower, cargoWeight, cargoType, tirePressureAvg, tires, tireAge);
        }
        String command = reader.readLine();

        if (command.equals("fragile")) {
            fragile.forEach((k, v) -> {
                AtomicBoolean yes = new AtomicBoolean(true);
                v.getTires().stream().takeWhile(value -> yes.get()).forEach(value -> {
                    if (value < 1) {
                        System.out.println(k);
                        yes.set(false);
                    }
                });
            });
        } else {
            flammable.forEach((k, v) -> {
                if (v.getEnginePower() > 250) {
                    System.out.println(k);
                }
            });
        }
    }

    private static void carsParameters(Map<String, CarRawData> fragile, Map<String, CarRawData> flammable,
                                       String model, int engineSpeed, int enginePower, int cargoWeight, String cargoType,
                                       double tirePressureAvg, List<Double> tires, List<Integer> tireAge) {
        if (cargoType.equals("fragile")) {
            fragile.put(model, new CarRawData(model, cargoType, cargoWeight, enginePower,
                    engineSpeed, tireAge, tires, tirePressureAvg));
        } else {
            flammable.put(model, new CarRawData(model, cargoType, cargoWeight, enginePower,
                    engineSpeed, tireAge, tires, tirePressureAvg));
        }
    }
}
