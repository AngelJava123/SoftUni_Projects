import java.util.List;

public class CarRawData {
    private String model;
    private String CargoType;
    private int cargoWeight;
    private int EnginePower;
    private int EngineSpeed;
    private List<Integer> tireAge;
    private List<Double> tires;
    private double TirePressure;

    public CarRawData(String model, String cargoType, int cargoWeight, int enginePower, int engineSpeed,
                      List<Integer> tireAge, List<Double> tires, double tirePressure) {
        this.model = model;
        CargoType = cargoType;
        this.cargoWeight = cargoWeight;
        EnginePower = enginePower;
        EngineSpeed = engineSpeed;
        this.tireAge = tireAge;
        this.tires = tires;
        TirePressure = tirePressure;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getCargoType() {
        return CargoType;
    }

    public void setCargoType(String cargoType) {
        CargoType = cargoType;
    }

    public int getCargoWeight() {
        return cargoWeight;
    }

    public void setCargoWeight(int cargoWeight) {
        this.cargoWeight = cargoWeight;
    }

    public int getEnginePower() {
        return EnginePower;
    }

    public void setEnginePower(int enginePower) {
        EnginePower = enginePower;
    }

    public int getEngineSpeed() {
        return EngineSpeed;
    }

    public void setEngineSpeed(int engineSpeed) {
        EngineSpeed = engineSpeed;
    }

    public List<Integer> getTireAge() {
        return tireAge;
    }

    public void setTireAge(List<Integer> tireAge) {
        this.tireAge = tireAge;
    }

    public List<Double> getTires() {
        return tires;
    }

    public void setTires(List<Double> tires) {
        this.tires = tires;
    }

    public double getTirePressure() {
        return TirePressure;
    }

    public void setTirePressure(double tirePressure) {
        TirePressure = tirePressure;
    }
}
