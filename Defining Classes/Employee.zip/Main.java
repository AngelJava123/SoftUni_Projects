import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Map<String, List<Employee>> employeeInfo = new LinkedHashMap<>();

        int n = Integer.parseInt(reader.readLine());

        while (n-- > 0) {
            String[] input = reader.readLine().split("\\s+");

            String name = input[0];
            double salary = Double.parseDouble(input[1]);
            String position = input[2];
            String department = input[3];

            if (input.length == 4) {
                Employee employee = new Employee(name, salary, position, department);
                if (!employeeInfo.containsKey(department)) {
                    employeeInfo.put(department, new ArrayList<>());
                }
                employeeInfo.get(department).add(employee);
            } else if (input.length == 5) {
                if (input[4].contains(".")) {
                    String email = input[4];
                    Employee employee = new Employee(name, salary, position, department, email);
                    if (!employeeInfo.containsKey(department)) {
                        employeeInfo.put(department, new ArrayList<>());
                    }
                    employeeInfo.get(department).add(employee);
                } else {
                    int age = Integer.parseInt(input[4]);
                    Employee employee = new Employee(name, salary, position, department, age);
                    if (!employeeInfo.containsKey(department)) {
                        employeeInfo.put(department, new ArrayList<>());
                    }
                    employeeInfo.get(department).add(employee);
                }
            } else if (input.length == 6) {
                String email = input[4];
                int age = Integer.parseInt(input[5]);
                Employee employee = new Employee(name, salary, position, department, email, age);
                if (!employeeInfo.containsKey(department)) {
                    employeeInfo.put(department, new ArrayList<>());
                }
                employeeInfo.get(department).add(employee);
            }
        }
        String finalDepartment = "";
        int valueSalary = Integer.MIN_VALUE;
        for (Map.Entry<String, List<Employee>> stringListEntry : employeeInfo.entrySet()) {
            int sum = 0;
            for (Employee values : stringListEntry.getValue()) {

                sum += values.getSalary();
            }
            if (sum > valueSalary) {
                valueSalary = sum;
                finalDepartment = stringListEntry.getKey();
            }
        }
        Map<Double, List<String>> result = new TreeMap<>();
        System.out.println("Highest Average Salary: " + finalDepartment);
        for (Map.Entry<String, List<Employee>> stringListEntry : employeeInfo.entrySet()) {
            for (Employee values : stringListEntry.getValue()) {

                if (stringListEntry.getKey().equals(finalDepartment)) {
                    result.put(values.getSalary(), new ArrayList<>());
                    result.get(values.getSalary()).add(String.format("%s %.2f %s %d", values.getName(),
                            values.getSalary(), values.getEmail(), values.getAge()));
                }
            }
        }
        result.entrySet().stream().sorted((e1, e2) -> {
            double comparingResult = e2.getKey().compareTo(e1.getKey());
            return (int) comparingResult;
        }).forEach((k) -> {
            System.out.println(k.getValue().toString().replaceAll("\\[", "").
                    replaceAll("]", ""));
        });
    }
}
