package bakery;

import java.util.ArrayList;
import java.util.List;

public class Bakery {
    private String name;
    private int capacity;
    private List<Employee> employees;

    public Bakery(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.employees = new ArrayList<>();
    }

    //•	Method add(Employee employee) – adds an entity to the data if there is room for him/her.
    public void add(Employee employee) {
        if (employees.size() < capacity) {
            employees.add(employee);
        }
    }

    //•	Method remove(String name) – removes an employee by given name, if such exists, and returns bool.
    public boolean remove(String name) {
        for (Employee employee: employees) {
            if (employee.getName().equals(name)) {
                employees.remove(employee);
                return true;
            }
        }
        return false;
    }

    //•	Method getOldestEmployee() – returns the oldest employee.
    public Employee getOldestEmployee() {
        Employee employee = null;
        int oldest = Integer.MIN_VALUE;

        for (Employee employee1: employees) {
            if (employee1.getAge() > oldest) {
                employee = employee1;
                oldest = employee1.getAge();
            }
        }
        return employee;
    }

    //•	Method getEmployee(string name) – returns the employee with the given name.
    public Employee getEmployee(String name) {
        Employee employee = null;

        for (Employee employee1: employees) {
            if (employee1.getName().equals(name)) {
                employee = employee1;
                break;
            }
        }
        return employee;
    }

    //•	Getter getCount() – returns the number of employees.
    public int getCount() {
        return employees.size();
    }
    public String report() {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("Employees working at Bakery %s:", name)).append(System.lineSeparator());

        for (Employee employee: employees) {
            sb.append(employee).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }
}
