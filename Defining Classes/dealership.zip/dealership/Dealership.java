package dealership;

import java.util.ArrayList;
import java.util.List;

public class Dealership {
    private String name;
    private int capacity;
    private List<Car> data;

    public Dealership(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    //•	Method add(Car car) – adds an entity to the data if there is an empty cell for the car.
    public void add(Car car) {
        if (data.size() < capacity) {
            data.add(car);
        }
    }

    //•	Method buy(String manufacturer, String model) – removes the car by given manufacturer and model,
    // if such exists, and returns boolean.
    public boolean buy(String manufacturer, String model) {

        for (Car car : data) {
            if (car.getManufacturer().equals(manufacturer) && car.getModel().equals(model)) {
                data.remove(car);
                return true;
            }
        }
        return false;
    }

    //•	Method getLatestCar() – returns the latest car (by year) or null if have no cars.
    public Car getLatestCar() {
        Car carToReturn = null;
        int latest = Integer.MIN_VALUE;

        for (Car car : data) {
            if (car.getYear() > latest) {
                carToReturn = car;
                latest = car.getYear();
            }
        }
        return carToReturn;
    }

    //•	Method getCar(String manufacturer, String model) – returns the car with the given manufacturer and
    // model or null if there is no such car.
    public Car getCar(String manufacturer, String model) {
        Car carToPass = null;

        for (Car car : data) {
            if (car.getManufacturer().equals(manufacturer) && car.getModel().equals(model)) {
                carToPass = car;
            }
        }
        return carToPass;
    }

    //•	Getter getCount() – returns the number of cars.
    public int getCount() {
        return data.size();
    }

    public String getStatistics() {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("The cars are in a car dealership %s:", name)).append(System.lineSeparator());

        for (Car car : data) {
            sb.append(car).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }
}
