package rabbits;

import java.util.ArrayList;
import java.util.List;

public class Cage {
    private String name;
    private int capacity;
    private List<Rabbit> data;

    public Cage(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void add(Rabbit rabbit) {
        if (data.size() < capacity) {
            data.add(rabbit);
        }
    }

    public boolean removeRabbit(String name) {
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getName().equals(name)) {
                data.remove(i);
                return true;
            }
        }
        return false;
    }

    public void removeSpecies(String species) {
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getSpecies().equals(species)) {
                data.remove(data.get(i));
            }
        }
    }

    public Rabbit sellRabbit(String name) {
        Rabbit rabbitToReturn = null;

        for (Rabbit rabbit : data) {
            if (name.equals(rabbit.getName())) {
                rabbitToReturn = rabbit;
                rabbit.setAvailable(false);
                break;
            }
        }
        return rabbitToReturn;
    }

    public List<Rabbit> sellRabbitBySpecies(String species) {
        List<Rabbit> soldRabits = new ArrayList<>();

        for (Rabbit rabbit : data) {
            if (rabbit.getSpecies().equals(species)) {
                soldRabits.add(rabbit);
                rabbit.setAvailable(false);
            }
        }
        return soldRabits;
    }

    public int count() {
        return data.size();
    }

    public String report() {
        StringBuilder builder = new StringBuilder();

        builder.append(String.format("Rabbits available at %s:%n", this.getName()));

        for (Rabbit rabbit : data) {
            if (rabbit.isAvailable()) {
                builder.append(rabbit).append(System.lineSeparator());
            }
        }
        return builder.toString().trim();
    }
}
