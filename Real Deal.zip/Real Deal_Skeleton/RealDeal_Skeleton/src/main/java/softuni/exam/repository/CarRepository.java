package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.Car;

import java.util.Optional;
import java.util.Set;

@Repository
public interface CarRepository extends JpaRepository<Car, Integer> {

    Optional<Car> findByMake(String make);

    @Query("SELECT c FROM Car c JOIN c.pictures p ORDER BY SIZE(c.pictures) DESC , c.make")
    Set<Car> findAllCarsOrderByPicturesAndOrderByMake();
}
