package softuni.exam.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ImportPicturesDto;
import softuni.exam.models.entity.Car;
import softuni.exam.models.entity.Picture;
import softuni.exam.repository.CarRepository;
import softuni.exam.repository.PictureRepository;
import softuni.exam.service.PictureService;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class PictureServiceImpl implements PictureService {
    private final Path path = Path.of("RealDeal_Skeleton\\src\\main\\resources\\files\\json\\pictures.json");

    private final PictureRepository pictureRepository;
    private final CarRepository carRepository;
    private final Gson gson;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public PictureServiceImpl(PictureRepository PictureRepository, CarRepository carRepository) {
        this.pictureRepository = PictureRepository;
        this.carRepository = carRepository;

        this.gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd HH:mm:ss")
                .setPrettyPrinting()
                .create();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.pictureRepository.count() > 0;
    }

    @Override
    public String readPicturesFromFile() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importPictures() throws IOException {

        String json = this.readPicturesFromFile();

        ImportPicturesDto[] picturesDtos = this.gson.fromJson(json, ImportPicturesDto[].class);

        return Arrays.stream(picturesDtos)
                .map(this::importPicture)
                .collect(Collectors.joining("\n"));

    }

    private String importPicture(ImportPicturesDto importPicturesDto) {
        Set<ConstraintViolation<ImportPicturesDto>> errors =
                this.validator.validate(importPicturesDto);

        if (!errors.isEmpty()) {
            return "Invalid picture";
        }

        Optional<Car> car = this.carRepository.findById(importPicturesDto.getCar());

        Picture picture = this.modelMapper.map(importPicturesDto, Picture.class);

        picture.setCars(car.get());

        this.pictureRepository.save(picture);

        return "Successfully import picture - " + picture.getName();
    }
}
