package softuni.exam.models.dto;

import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.util.Date;

public class ImportCarsDto {

    @Size(min = 2, max = 20)
    private String make;

    @Size(min = 2, max = 20)
    private String model;

    @Positive
    private Integer kilometers;

    private Date registeredOn;

    public ImportCarsDto() {
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public Integer getKilometers() {
        return kilometers;
    }

    public Date getRegisteredOn() {
        return registeredOn;
    }
}
