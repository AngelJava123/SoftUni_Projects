package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ImportSellersDto;
import softuni.exam.models.dto.SellerDataDto;
import softuni.exam.models.entity.Seller;
import softuni.exam.repository.SellerRepository;
import softuni.exam.service.SellerService;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class SellerServiceImpl implements SellerService {
    private final Path path = Path.of("RealDeal_Skeleton\\src\\main\\resources\\files\\xml\\sellers.xml");

    private final SellerRepository sellerRepository;
    private final Unmarshaller unmarshaller;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public SellerServiceImpl(SellerRepository sellerRepository) throws JAXBException {
        this.sellerRepository = sellerRepository;

        JAXBContext context = JAXBContext.newInstance(ImportSellersDto.class);
        this.unmarshaller = context.createUnmarshaller();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.sellerRepository.count() > 0;
    }

    @Override
    public String readSellersFromFile() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importSellers() throws IOException, JAXBException {
        ImportSellersDto sellersDto = (ImportSellersDto) this.unmarshaller.unmarshal(
                new FileReader(path.toAbsolutePath().toString()));

        return sellersDto
                .getSellers()
                .stream()
                .map(this::importSeller)
                .collect(Collectors.joining("\n"));

    }

    private String importSeller(SellerDataDto sellerDataDto) {
        Set<ConstraintViolation<SellerDataDto>> errors =
                this.validator.validate(sellerDataDto);

        if (!errors.isEmpty()) {
            return "Invalid seller";
        }

        Seller seller = this.modelMapper.map(sellerDataDto, Seller.class);

        this.sellerRepository.save(seller);

        return "Successfully import seller " + seller.getFirstName() + " - " + seller.getEmail();
    }
}
