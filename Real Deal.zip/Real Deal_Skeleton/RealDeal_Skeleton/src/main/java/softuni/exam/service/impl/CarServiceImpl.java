package softuni.exam.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ImportCarsDto;
import softuni.exam.models.entity.Car;
import softuni.exam.repository.CarRepository;
import softuni.exam.service.CarService;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {
    private final Path path = Path.of("RealDeal_Skeleton\\src\\main\\resources\\files\\json\\cars.json");

    private final CarRepository carRepository;
    private final Gson gson;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public CarServiceImpl(CarRepository carRepository) {
        this.carRepository = carRepository;

        this.gson = new GsonBuilder()
                .setDateFormat("dd/MM/yyyy")
                .setPrettyPrinting()
                .create();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();
    }

    @Override
    public boolean areImported() {
        return this.carRepository.count() > 0;
    }

    @Override
    public String readCarsFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importCars() throws IOException {
        String json = this.readCarsFileContent();

        ImportCarsDto[] carsDtos = this.gson.fromJson(json, ImportCarsDto[].class);

        return Arrays.stream(carsDtos)
                .map(this::importCar)
                .collect(Collectors.joining("\n"));
    }

    private String importCar(ImportCarsDto importCarsDto) {
        Set<ConstraintViolation<ImportCarsDto>> errors =
                this.validator.validate(importCarsDto);

        if (!errors.isEmpty()) {
            return "Invalid car";
        }

        Car car = this.modelMapper.map(importCarsDto, Car.class);
        this.carRepository.save(car);

        return "Successfully imported car " + car.getMake() + " " + car.getModel();

    }

    @Override
    @Transactional
    public String getCarsOrderByPicturesCountThenByMake() {

        Set<Car> cars = this.carRepository.findAllCarsOrderByPicturesAndOrderByMake();

        StringBuilder builder = new StringBuilder();

        for (Car car : cars) {
            builder.append(car.toString()).append(System.lineSeparator());
        }
        return builder.toString().trim();
    }
}
