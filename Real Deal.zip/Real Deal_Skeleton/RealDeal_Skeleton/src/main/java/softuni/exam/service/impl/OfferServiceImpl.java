package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ImportOffersDto;
import softuni.exam.models.dto.OfferDataDto;
import softuni.exam.models.entity.Car;
import softuni.exam.models.entity.Offer;
import softuni.exam.models.entity.Seller;
import softuni.exam.repository.CarRepository;
import softuni.exam.repository.OfferRepository;
import softuni.exam.repository.SellerRepository;
import softuni.exam.service.OfferService;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class OfferServiceImpl implements OfferService {
    private final Path path = Path.of("RealDeal_Skeleton\\src\\main\\resources\\files\\xml\\offers.xml");

    private final OfferRepository offerRepository;
    private final CarRepository carRepository;
    private final SellerRepository sellerRepository;
    private final Unmarshaller unmarshaller;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @Autowired
    public OfferServiceImpl(OfferRepository offerRepository, CarRepository carRepository, SellerRepository sellerRepository) throws JAXBException {
        this.offerRepository = offerRepository;
        this.carRepository = carRepository;
        this.sellerRepository = sellerRepository;

        JAXBContext context = JAXBContext.newInstance(ImportOffersDto.class);
        this.unmarshaller = context.createUnmarshaller();

        this.validator = Validation
                .buildDefaultValidatorFactory()
                .getValidator();

        this.modelMapper = new ModelMapper();

        this.modelMapper.addConverter(ctx -> LocalDateTime.parse(ctx.getSource(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                String.class, LocalDateTime.class);
    }

    @Override
    public boolean areImported() {
        return this.offerRepository.count() > 0;
    }

    @Override
    public String readOffersFileContent() throws IOException {
        return Files.readString(path);
    }

    @Override
    public String importOffers() throws IOException, JAXBException {
        ImportOffersDto offersDto = (ImportOffersDto) this.unmarshaller.unmarshal(
                new FileReader(path.toAbsolutePath().toString()));

        return offersDto
                .getOffers()
                .stream()
                .map(this::importOffer)
                .collect(Collectors.joining("\n"));
    }

    private String importOffer(OfferDataDto offerDataDto) {
        Set<ConstraintViolation<OfferDataDto>> errors =
                this.validator.validate(offerDataDto);

        if (!errors.isEmpty()) {
            return "Invalid offer";
        }

        Optional<Car> car = this.carRepository.findById(offerDataDto.getCar().getId());
        Optional<Seller> seller = this.sellerRepository.findById(offerDataDto.getSeller().getId());

        Offer offer = this.modelMapper.map(offerDataDto, Offer.class);

        offer.setCars(car.get());
        offer.setSellers(seller.get());

        this.offerRepository.save(offer);

        return "Successfully import offer " + offer.getAddedOn() + " - " +  offer.getHasGoldStatus();
    }
}
