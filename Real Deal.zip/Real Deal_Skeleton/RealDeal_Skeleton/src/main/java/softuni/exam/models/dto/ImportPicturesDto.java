package softuni.exam.models.dto;

import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.Date;

public class ImportPicturesDto {

    @Size(min = 2, max = 20)
    private String name;

    private Date dateAndTime;

    private Integer car;

    public ImportPicturesDto() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDateAndTime() {
        return dateAndTime;
    }

    public void setDateAndTime(Date dateAndTime) {
        this.dateAndTime = dateAndTime;
    }

    public Integer getCar() {
        return car;
    }

    public void setCar(Integer car) {
        this.car = car;
    }
}
