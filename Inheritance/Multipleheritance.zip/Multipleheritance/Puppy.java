package Multipleheritance;

public class Puppy extends Dog {

    public void weep() {
        System.out.println("weeping...");
    }
}
