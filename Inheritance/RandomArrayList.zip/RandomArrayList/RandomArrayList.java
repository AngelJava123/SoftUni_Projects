package RandomArrayList;

import java.util.ArrayList;
import java.util.Random;

public class RandomArrayList<T> extends ArrayList<T> {

    public T getRandomElement() {
        int end = super.size();
        Random random = new Random();
        int randIndex = random.nextInt(end);
        return remove(randIndex);
    }
}
