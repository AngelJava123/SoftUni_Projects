package animals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Animal> animals = new ArrayList<>();

        String animalType = reader.readLine();
        while (!animalType.equals("Beast!")) {

            String[] data = reader.readLine().split(" ");

            String name = data[0];
            int age = Integer.parseInt(data[1]);
            String gender = data[2];

            switch (animalType) {
                case "Cat":
                    try {
                        Cat cat = new Cat(name, age, gender);
                        animals.add(cat);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "Dog":
                    try {
                        Dog dog = new Dog(name, age, gender);
                        animals.add(dog);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "Frog":
                    try {
                        Frog frog = new Frog(name, age, gender);
                        animals.add(frog);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "Kitten":
                    try {
                        Kitten kitten = new Kitten(name, age);
                        animals.add(kitten);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "Tomcat":
                    try {
                        Tomcat tomcat = new Tomcat(name, age);
                        animals.add(tomcat);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
            }
            animalType = reader.readLine();
        }

        for (Animal animal : animals) {
            System.out.println(animal.toString());
        }
    }
}
